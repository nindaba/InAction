package jc;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;

public class confirm_person implements Initializable {
  @FXML
  private Label name;
  
  Room_record record;
  
  Base base;
  
  String title;
  
  public void initialize(URL url, ResourceBundle rb) {}
  
  @FXML
  private void remove(MouseEvent event) {
    this.base.Selected_record.remove(this.record);
    this.base.add_to_confirm_box(this.title);
  }
  
  public void init(String n, Room_record rc, Base bs, String tit) {
    this.record = rc;
    this.name.setText(n);
    this.base = bs;
    this.title = tit;
  }
}
