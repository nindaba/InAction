package jc;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXCheckBox;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXProgressBar;
import com.jfoenix.controls.JFXTabPane;
import com.jfoenix.controls.JFXTextField;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperPrintManager;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.export.JRPdfExporterParameter;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

public class Base implements Initializable {
  public PieChart Pie_Company;
  
  @FXML
  private AnchorPane Company_Client_chooser;
  
  @FXML
  private JFXTextField Company_Client_chooser_search;
  
  @FXML
  private VBox Company_Client_chooser_box;
  
  @FXML
  private AnchorPane Account_info;
  
  @FXML
  private JFXTextField Account_info_name;
  
  @FXML
  private JFXPasswordField Account_info_current_password;
  
  @FXML
  private JFXPasswordField Account_info_new_password;
  
  @FXML
  private JFXPasswordField Account_info_password;
  
  @FXML
  private JFXTextField Account_info_username;
  
  @FXML
  private JFXTextField Client_details_name;
  
  @FXML
  private JFXTextField Client_details_phone;
  
  @FXML
  private JFXTextField Client_details_identity;
  
  @FXML
  private JFXTextField Client_details_province_country;
  
  @FXML
  private AnchorPane Change_date;
  
  public JFXDatePicker Change_date_new_from;
  
  public JFXDatePicker Change_date_new_to;
  
  @FXML
  private Label Change_date_new_nights;
  
  public TextField Change_date_room_price;
  
  @FXML
  private Label Change_date_total_cost;
  
  public JFXCheckBox Change_date_payed;
  
  @FXML
  JFXTabPane Tabs;
  
  @FXML
  VBox room_tab_box;
  
  @FXML
  private JFXTextField search;
  
  public VBox client_tab_box;
  
  @FXML
  private AnchorPane Login;
  
  @FXML
  private JFXPasswordField Login_password;
  
  @FXML
  private JFXTextField Login_username;
  
  @FXML
  private StackPane Stack;
  
  public Label Room_tab_name_holder;
  
  @FXML
  AnchorPane load;
  
  @FXML
  public JFXProgressBar load_show;
  
  @FXML
  private AnchorPane new_company;
  
  @FXML
  private JFXTextField new_company_name;
  
  @FXML
  private AnchorPane Room_tab_conf;
  
  @FXML
  private JFXCheckBox Conf_payed;
  
  @FXML
  private Label Conf_name;
  
  @FXML
  private Label Conf_phone;
  
  @FXML
  private Label conf_id;
  
  @FXML
  private Label Conf_province;
  
  @FXML
  private Label Conf_from;
  
  @FXML
  private Label Conf_room;
  
  @FXML
  private Label Conf_nights;
  
  @FXML
  private Label Conf_totalcost;
  
  @FXML
  private Label Conf_price;
  
  @FXML
  private Label Conf_to;
  
  @FXML
  private Label Conf_company;
  
  @FXML
  private AnchorPane new_side;
  
  @FXML
  private JFXTextField side_room_name;
  
  @FXML
  private JFXTextField side_room_price;
  
  @FXML
  private AnchorPane new_client;
  
  @FXML
  private AnchorPane confirm;
  
  @FXML
  private Label confirm_number;
  
  @FXML
  private VBox confirm_box;
  
  @FXML
  Label parts;
  
  public JFXDatePicker tab_from;
  
  public JFXDatePicker tab_to;
  
  public ObservableList<PieChart.Data> Comp_pay;
  
  @FXML
  private Label Change_date_name;
  
  private Label from_indicator;
  
  private Label to_indicator;
  
  @FXML
  private Tab firstab;
  
  @FXML
  private Tab sectab;
  
  public ArrayList<companies_jr> firstJr = new ArrayList<>();
  
  public ArrayList<Room_record> secJr = new ArrayList<>();
  
  public ArrayList<Room_record> thirdJr = new ArrayList<>();
  
  public Map<String, Parent> clients_company_search = new HashMap<>();
  
  public Map<String, Parent>[] clients_company_report_search = (Map<String, Parent>[])new HashMap[3];
  
  @FXML
  private Label comp_clie_tit;
  
  @FXML
  private JFXButton Mark_payed;
  
  @FXML
  private JFXButton done_conf;
    @FXML
    private JFXTextField new_company_short;
    @FXML
    private JFXTextField Client_details_nationality;
    @FXML
    private JFXTextField Client_details_province_sex;
    @FXML
    private JFXDatePicker Client_details_age;
    @FXML
    private Label conf_age;
    @FXML
    private Label conf_sex;
    @FXML
    private Label conf_nationality;
    @FXML
    private AnchorPane Export_pane;
    private Label export_date;
    @FXML
    private JFXDatePicker export_date_from;
    @FXML
    private JFXDatePicker export_date_to;
    @FXML
    private JFXCheckBox Conf_cash;
    @FXML
    private JFXTextField side_room_otherprice;
    private String otherprice ="0";
    public JFXCheckBox Change_date_cash;
    @FXML
    private AnchorPane AddDepenses;
    @FXML
    private Label comp_clie_tit11;
    @FXML
    private JFXTextField depenceDescr;
    @FXML
    private JFXTextField depenceMoney;
    @FXML
    private JFXDatePicker depenceDate;
    @FXML
    private AnchorPane Depenses;
    @FXML
    private Label comp_clie_tit1;
    @FXML
    private VBox depenceBox;
    @FXML
    private JFXDatePicker depenceFrom;
    @FXML
    private JFXDatePicker depenceTo;
    @FXML
    private Label comp_clie_tit12;
    @FXML
    private Label comp_clie_tit13;
    @FXML
    private Label comp_clie_tit14;
    @FXML
    private JFXButton done_conf1;
    @FXML
    private JFXTextField newCompanyResidence;
    @FXML
    private JFXTextField new_companyNif;
    @FXML
    private Tab thirdtab;
    public  VBox seminarBox;
    @FXML
    private AnchorPane AddSeminar;
    @FXML
    private Label comp_clie_tit111;
    @FXML
    private JFXDatePicker AddSeminarDate;
    @FXML
    private JFXComboBox<String> AddSeminarCombo;
    public JFXComboBox<String> hotelCombo;
    @FXML
    private JFXTextField Account_info_service;
    @FXML
    private JFXButton addMod;
    @FXML
    private GridPane depenceTitles;
    @FXML
    private JFXButton newButton;
    @FXML
    private JFXCheckBox depenceShowGlobal;
    @FXML
    private JFXCheckBox depenceCash;
  
  public void initialize(URL url, ResourceBundle rb) {
      Tabs.getSelectionModel().selectedIndexProperty().addListener((obs,oldtab,index)->{
        if (index.intValue() == 0) {
            if(this.tab_from.getValue().compareTo(this.tab_to.getValue()) < 0 ){
                this.data.room_tab_load(this, (LocalDate)this.tab_from.getValue(), (LocalDate)this.tab_to.getValue());
            }else{
                try {
                    room_tab_box.getChildren().clear();
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/fx/vide.fxml"));
                    Node root = loader.load();
                    vide vd = loader.getController();
                    vd.init("Vide de " + tab_from.getValue().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) + " a " + tab_to.getValue().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
                    room_tab_box.getChildren().add(root);
                } catch (Exception iO)
                {
                    iO.printStackTrace();
                }
            }
        } else if (index.intValue() == 1){
          if(this.tab_from.getValue().compareTo(this.tab_to.getValue()) <= 0 ){
            this.data.client_tab_load(this, (LocalDate)this.tab_from.getValue(), (LocalDate)this.tab_to.getValue());
          }else{
                try {
                    client_tab_box.getChildren().clear();
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/fx/vide.fxml"));
                    Node root = loader.load();
                    vide vd = loader.getController();
                    vd.init("Vide de " + tab_from.getValue().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) + " a " + tab_to.getValue().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
                    client_tab_box.getChildren().add(root);
                } catch (Exception iO)
                {
                    iO.printStackTrace();
                }
            }
        } else{
            if(this.tab_from.getValue().compareTo(this.tab_to.getValue()) < 0 ){
                this.data.LoadSemina(this, (LocalDate)this.tab_from.getValue(), (LocalDate)this.tab_to.getValue());
            }else{
                try {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/fx/vide.fxml"));
                    Node root = loader.load();
                    vide vd = loader.getController();
                    vd.init("Vide de " + tab_from.getValue().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) + " a " + tab_to.getValue().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
                    seminarBox.getChildren().clear();
                    seminarBox.getChildren().add(root);
                } catch (Exception iO)
                {
                    iO.printStackTrace();
                }
            }
        }
    });
    this.clients_company_report_search[0] = new HashMap<>();
    this.clients_company_report_search[1] = new HashMap<>();
    this.clients_company_report_search[2] = new HashMap<>();
    this.Tabs.toFront();
    this.load.toFront();
    setDisable(Boolean.valueOf(true));
    this.Comp_pay = FXCollections.observableArrayList();
    this.Pie_Company.setData(this.Comp_pay);
    this.Pie_Company.setStartAngle(90.0D);
    this.tab_from.setValue(LocalDate.now());
    this.Client_details_age.setValue(LocalDate.now());
    this.tab_to.setValue(LocalDate.now().plusDays(1L));
    depenceFrom.setValue(tab_from.getValue());
    depenceTo.setValue(tab_to.getValue());
    ObservableList<String> HTL = FXCollections.observableArrayList();
    HTL.add("CIZANYE 1");
    HTL.add("CIZANYE 2");
    hotelCombo.setItems(HTL);
    hotelCombo.setValue("CIZANYE 1");
    Task starter = new Task() {
        protected Object call() {
          try {
            updateMessage("Waiting");
            Map<String, Object> parameters = new HashMap<>();
            parameters.put("ciz",Base.this.hotelCombo.getValue());
            InputStream input = getClass().getResourceAsStream("MoreInOne.jasper");
            //JasperDesign jasperDesign = JRXmlLoader.load(input);
            //JasperReport jasperReport = JasperCompileManager.compileReport(jasperDesign);
            Base.this.jasperPrint = JasperFillManager.fillReport(input, parameters, (JRDataSource)new JREmptyDataSource());
            data.setAccountOff();
            updateMessage("Fin");
            Platform.runLater(new Runnable() {
                  public void run() {
                    Base.this.Tabs.toFront();
                    Base.this.Login.toFront();
                  }
                });
          } catch (Exception ex) {
            ex.printStackTrace();
          } 
          return Boolean.valueOf(true);
        }
      };
    this.parts.textProperty().unbind();
    this.parts.textProperty().bind(starter.messageProperty());
    this.load_show.progressProperty().unbind();
    this.load_show.progressProperty().bind(starter.progressProperty());
    (new Thread(starter)).start();
    
  }
  
  Map<String, String> rooms = new HashMap<>();
  
  public ArrayList<Room_record> Selected_record = new ArrayList<>();
  
  public String bookid;
  
  @FXML
  private void Account_info_delete_account(ActionEvent event) {
    this.Account_info_current_password.setStyle("-fx-text-fill: #dad7d7;-fx-prompt-text-fill: #dad7d7");
    Boolean incorrect = this.data.Delete_password(this.Room_tab_name_holder.getText(), this.Account_info_current_password.getText(), this.Account_info_new_password.getText());
    if (!incorrect.booleanValue()) {
      this.Account_info_current_password.setStyle("-fx-text-fill: #f18080;-fx-prompt-text-fill: #f18080");
    } else {
      close_windows();
    } 
  }
  
  @FXML
  private void Account_info_change_password(ActionEvent event) {
    this.Account_info_current_password.setStyle("-fx-text-fill: #dad7d7;-fx-prompt-text-fill: #dad7d7");
    Boolean incorrect = this.data.Change_password(this.Room_tab_name_holder.getText(), this.Account_info_current_password.getText(), this.Account_info_new_password.getText());
    if (!incorrect.booleanValue()) {
      this.Account_info_current_password.setStyle("-fx-text-fill: #f18080;-fx-prompt-text-fill: #f18080");
    } else {
      setDisable(Boolean.valueOf(true));
      this.Login.toFront();
    } 
  }
  
  @FXML
  private void Account_info_create(ActionEvent event) {
    this.Account_info_username.setStyle("-fx-text-fill: #dad7d7;-fx-prompt-text-fill: #dad7d7");
    if(this.Account_info_name.getText().equals("")){
        Account_info_name.setStyle("-fx-text-fill: #f18080;-fx-prompt-text-fill: #f18080");
    }
    else if(this.Account_info_service.getText().equals("")){
        this.Account_info_service.setStyle("-fx-text-fill: #f18080;-fx-prompt-text-fill: #f18080");
    }
    else if(this.Account_info_username.getText().equals("")){
        this.Account_info_username.setStyle("-fx-text-fill: #f18080;-fx-prompt-text-fill: #f18080");
    }
    else if(this.Account_info_password.getText().equals("")){
        this.Account_info_password.setStyle("-fx-text-fill: #f18080;-fx-prompt-text-fill: #f18080");
    }
    else if (this.data.Create_account(this.Account_info_name.getText(),this.Account_info_service.getText(), this.Account_info_username.getText(), this.Account_info_password.getText())) {
      this.Account_info_username.setStyle("-fx-text-fill: #f18080;-fx-prompt-text-fill: #f18080");
    } else {
      close_windows();
    } 
  }
  
  @FXML
  private void close_windows() {
    setDisable(Boolean.valueOf(false));
    this.Tabs.toFront();
    this.Conf_payed.setVisible(true);
    this.done_conf.setVisible(true);
    this.comp_clie_tit.setText("Companies");
  }
  
  public Integer Change_for = Integer.valueOf(0);
  
  File location;
  
  @FXML
  private void Change_date_change(ActionEvent event) {
    if (this.changer.booleanValue()) {
      this.data.changeDates(this);
      DisplaynextChange();
      this.Change_date_new_from.setStyle("-fx-mid-text-color:#bfc9bf");
      this.Change_date_new_to.setStyle("-fx-mid-text-color:#bfc9bf");
    } 
  }
  
  @FXML
  private void room_tab_account_info(MouseEvent event) {
    this.Account_info.toFront();
    setDisable(Boolean.valueOf(true));
  }
  
  @FXML
  private void room_tab_paycheque(ActionEvent event) {
    Boolean selected = add_to_confirm_box("Facture Pour");
    if (selected.booleanValue()) {
      setDisable(Boolean.valueOf(true));
      this.confirm.toFront();
      this.mode = "paycheque";
    } 
  }
  
  @FXML
  private void room_tab_remove(ActionEvent event) {
    Boolean selected = add_to_confirm_box("Suppressionb de ");
    if (selected.booleanValue()) {
      setDisable(Boolean.valueOf(true));
      this.confirm.toFront();
      this.mode = "remove";
    } 
  }
  
  @FXML
  private void room_tab_change_date(ActionEvent event) {
    Boolean selected = add_to_confirm_box("Changer pour");
    if (selected.booleanValue()) {
      setDisable(Boolean.valueOf(true));
      this.confirm.toFront();
      this.mode = "date";
    } 
  }
  
  @FXML
  private void room_tab_export(ActionEvent event) {
        this.setDisable(true);
        Export_pane.toFront();
        export_date_from.setValue(Base.this.tab_from.getValue());
        export_date_to.setValue(Base.this.tab_to.getValue());
  }
  
  @FXML
  private void client_tab_search_letter(KeyEvent event) {
    String s = this.search.getText().toLowerCase();
    VBox b = new VBox();
    this.client_tab_box.getChildren().clear();
    b.getChildren().add(this.clients_company_report_search[this.client_position.intValue()].get("nizi6."));
    for (Map.Entry<String, Parent> entrySet : this.clients_company_report_search[this.client_position.intValue()].entrySet()) {
      String key = entrySet.getKey();
      Parent value = entrySet.getValue();
      if ((key.contains(s) || s.equals("")) && !key.contains("nizi6."))
        b.getChildren().add(value); 
    } 
    this.client_tab_box.getChildren().add(b);
  }
  
  @FXML
  private void client_tab_export(ActionEvent event) {
    this.load.toFront();
    setDisable(Boolean.valueOf(true));
    Task Export_records = new Task() {
        protected Object call() {
          try {
            final JRPdfExporter exporter = new JRPdfExporter();
            ArrayList<JasperPrint> papers = new ArrayList<>();
            String key_as_date = ((LocalDate)Base.this.tab_from.getValue()).format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
            updateMessage("Writing");
            JRBeanCollectionDataSource clients = null;
            InputStream input = getClass().getResourceAsStream("companies.jasper");
            Map<String, Object> parameters = new HashMap<>();
            if (Base.this.client_position.intValue() == 0) {
              clients = new JRBeanCollectionDataSource(Base.this.firstJr);
              parameters.put("total_payed", ((String[])Base.this.bottom.get(0))[0]);
              parameters.put("unpayed", ((String[])Base.this.bottom.get(0))[1]);
              parameters.put("total", ((String[])Base.this.bottom.get(0))[2]);
              input = getClass().getResourceAsStream("companies.jasper");
            } else if (Base.this.client_position.intValue() == 1) {
              clients = new JRBeanCollectionDataSource(Base.this.secJr);
              parameters.put("total_payed", ((String[])Base.this.bottom.get(1))[0]);
              parameters.put("unpayed", ((String[])Base.this.bottom.get(1))[1]);
              parameters.put("total", ((String[])Base.this.bottom.get(1))[2]);
              parameters.put("name", Base.this.Current_Comp);
              input = getClass().getResourceAsStream("company.jasper");
            } else if (Base.this.client_position.intValue() == 2) {
              clients = new JRBeanCollectionDataSource(Base.this.thirdJr);
              parameters.put("total_payed", ((String[])Base.this.bottom.get(2))[0]);
              parameters.put("unpayed", ((String[])Base.this.bottom.get(2))[1]);
              parameters.put("total", ((String[])Base.this.bottom.get(2))[2]);
              parameters.put("name", Base.this.Current_Client);
              input = getClass().getResourceAsStream("client.jasper");
            } 
            parameters.put("image", getClass().getResourceAsStream("Image10m.png"));
            parameters.put("date", key_as_date);
            parameters.put("created", "Created by " + Base.this.Room_tab_name_holder.getText() + " le " + LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
            parameters.put("Clients_data", clients);
            //JasperDesign jasperDesign = JRXmlLoader.load(input);
            //JasperReport jasperReport = JasperCompileManager.compileReport(jasperDesign);
            Base.this.jasperPrint = JasperFillManager.fillReport(input, parameters, (JRDataSource)new JREmptyDataSource());
            papers.add(Base.this.jasperPrint);
            exporter.setParameter(JRPdfExporterParameter.JASPER_PRINT_LIST, papers);
            updateMessage("Saving");
            Platform.runLater(new Runnable() {
                  public void run() {
                    try {
                      FileChooser ch = new FileChooser();
                      File lc = new File(Base.this.data.getLocation("2"));
                      if (lc.exists())
                        ch.setInitialDirectory(lc); 
                      lc = ch.showSaveDialog(Base.this.confirm.getScene().getWindow());
                      Base.this.data.setLocation("2", lc.getParent());
                      lc = new File(lc.getPath() + ".pdf");
                      exporter.setParameter(JRPdfExporterParameter.OUTPUT_FILE, lc);
                      exporter.exportReport();
                    } catch (Exception exception) {
                      exception.printStackTrace();
                    } 
                    Base.this.setDisable(Boolean.valueOf(false));
                    Base.this.Tabs.toFront();
                  }
                });
          } catch (Exception exception) {
            exception.printStackTrace();
          } 
          return Boolean.valueOf(true);
        }
      };
    this.parts.textProperty().unbind();
    this.parts.textProperty().bind(Export_records.messageProperty());
    this.load_show.progressProperty().unbind();
    this.load_show.progressProperty().bind(Export_records.progressProperty());
    (new Thread(Export_records)).start();
  }
  
  @FXML
  private void Login_Login(ActionEvent event) {
    String Password = this.data.getPassword(this.Login_username.getText());
    this.Login_password.setStyle("-fx-text-fill: #dad7d7;-fx-prompt-text-fill: #dad7d7");
    this.Login_username.setStyle("-fx-text-fill: #dad7d7;-fx-prompt-text-fill: #dad7d7");
    if (Password.equals("Username_not_found")) {
      this.Login_username.setStyle("-fx-text-fill: #f18080;-fx-prompt-text-fill: #f18080");
    } else if (!Password.equals(this.Login_password.getText())) {
      this.Login_password.setStyle("-fx-text-fill: #f18080;-fx-prompt-text-fill: #f18080");
    } else {
      String name = this.data.turn_Online(this.Login_username.getText());
      this.Room_tab_name_holder.setText(name);
      this.Login_username.setText("");
      this.Login_password.setText("");
      tab_load();
    } 
  }
  
  Database data = new Database();
  
  String date;
  
  String price;
  
  String nights;
  
  String roomid;
  
  String compid;
  
  String clientid;
  
  @FXML
  private void Account_out(ActionEvent event) {
    this.Tabs.toFront();
    setDisable(Boolean.valueOf(true));
    data.setAccountOff();
    this.Login.toFront();
  }
  
  public void Add_client(String r, String d, String p, String n) {
    this.date = d;
    this.price = p;
    this.nights = n;
    this.roomid = r;
    setDisable(Boolean.valueOf(true));
    this.Company_Client_chooser_box.getChildren().clear();
    this.Company_Client_chooser_box.getChildren().add(this.data.getCompanies(this));
    this.Company_Client_chooser.toFront();
    this.add_client = Boolean.valueOf(false);
  }
  
  public void getClients(String id) {
    this.compid = id;
    this.Company_Client_chooser_box.getChildren().clear();
    this.add_client = Boolean.valueOf(true);
    this.Company_Client_chooser_box.getChildren().add(this.data.getClients(this, id));
    this.comp_clie_tit.setText("Clients");
  }
  
  Boolean add_client = Boolean.valueOf(false);
  
  LocalDate from_side;
  
  String mode;
  
  String ids;
  
    @FXML
  public void client_company_add() {
    if (this.add_client.booleanValue()) {
      this.Company_Client_chooser.toBack();
      this.new_client.toFront();
      this.add_client = Boolean.valueOf(false);
    } else {
      this.Company_Client_chooser.toBack();
      this.new_company.toFront();
      this.add_client = Boolean.valueOf(true);
      sembook = false;
    } 
  }
  
    @FXML
  public void add_new_company() {
    addCompany();
  }
  Confirm_book book;
  public void confBooked(String cl) {
    this.comp_clie_tit.setText("Organisation");
    this.clientid = cl;
    book = this.data.getConf(this,this.compid, this.clientid, this.roomid, this.date, this.price, this.nights);
    this.Conf_name.setText(book.getName());
    this.Conf_phone.setText(book.getPhone());
    this.conf_nationality.setText(book.getNationality());
    this.conf_age.setText(book.getAge());
    this.conf_sex.setText(book.getSex());
    this.conf_id.setText(book.getId());
    this.Conf_province.setText(book.getProvince());
    this.Conf_from.setText(LocalDate.parse(book.getFrom()).format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
    this.Conf_room.setText(book.getRoom());
    this.Conf_nights.setText(book.getNights());
    this.Conf_totalcost.setText(book.getTotalcost());
    this.Conf_price.setText(book.getPrice());
    this.Conf_to.setText(LocalDate.parse(book.getTo()).format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
    this.Conf_company.setText(book.getCompFull());
    this.Room_tab_conf.toFront();
  }
  
  @FXML
  private void Conf_add(ActionEvent event) {
    Boolean payed = Boolean.valueOf(this.Conf_payed.isSelected());
    Boolean cash = this.Conf_cash.isSelected();
    this.data.book(this,this.clientid, this.roomid, this.compid, this.date, LocalDate.parse(this.date).plusDays(Integer.parseInt(this.nights)).toString(), this.price, payed.toString(),cash.toString(),otherprice);
    otherprice ="0";
    tab_load();
  }
  
  public void add_side(LocalDate from) {
    this.from_side = from;
    setDisable(Boolean.valueOf(true));
    this.new_side.toFront();
  }
  
  @FXML
  private void add_side_room(ActionEvent event) {
    Boolean valid = true;
    this.side_room_name.setStyle("-fx-text-fill: #dad7d7;-fx-prompt-text-fill: #dad7d7");
    if(this.side_room_name.getText().equals("") && !this.data.chech_side(this,this.side_room_name.getText(), this.from_side, (LocalDate)this.tab_to.getValue())){
        this.side_room_name.setStyle("-fx-text-fill: #f18080;-fx-prompt-text-fill: #f18080");
        valid = false;
    }
    if(this.side_room_price.getText().equals("")){
        
        this.side_room_price.setStyle("-fx-text-fill: #f18080;-fx-prompt-text-fill: #f18080");
        valid = false;
    }
    try {
            Integer p = Integer.parseInt(this.side_room_price.getText());
        } catch (NumberFormatException numberFormatException) {
            this.side_room_price.setStyle("-fx-text-fill: #f18080;-fx-prompt-text-fill: #f18080");
            valid = false;
        }
    try {
            Integer p = Integer.parseInt(this.side_room_otherprice.getText());
        } catch (NumberFormatException numberFormatException) {
            this.side_room_otherprice.setStyle("-fx-text-fill: #f18080;-fx-prompt-text-fill: #f18080");
        valid = false;
        }
    if(this.side_room_otherprice.getText().equals("")){
        
        this.side_room_otherprice.setStyle("-fx-text-fill: #f18080;-fx-prompt-text-fill: #f18080");
        valid = false;
    }
    if (valid.booleanValue()) {
      this.date = this.from_side.toString();
      this.price = this.side_room_price.getText();
      this.otherprice = this.side_room_otherprice.getText();
      this.nights = this.data.getDays(this.from_side, (LocalDate)this.tab_to.getValue()).toString();
      this.roomid = this.side_room_name.getText();
      this.Company_Client_chooser_box.getChildren().clear();
      this.Company_Client_chooser_box.getChildren().add(this.data.getCompanies(this));
      this.Company_Client_chooser.toFront();
    } 
  }
  
  @FXML
  private void add_new_client(ActionEvent event) {
        this.Client_details_name.setStyle("-fx-text-fill: #dad7d7;-fx-prompt-text-fill: #dad7d7");
        this.Client_details_phone.setStyle("-fx-text-fill: #dad7d7;-fx-prompt-text-fill: #dad7d7");
        this.Client_details_identity.setStyle("-fx-text-fill: #dad7d7;-fx-prompt-text-fill: #dad7d7");
        this.Client_details_province_country.setStyle("-fx-text-fill: #dad7d7;-fx-prompt-text-fill: #dad7d7");
        this.Client_details_nationality.setStyle("-fx-text-fill: #dad7d7;-fx-prompt-text-fill: #dad7d7");
        this.Client_details_province_sex.setStyle("-fx-text-fill: #dad7d7;-fx-prompt-text-fill: #dad7d7");
        if (this.Client_details_name.getText().equals("")) {
            this.Client_details_name.setStyle("-fx-text-fill: #f18080;-fx-prompt-text-fill: #f18080");
        } else if (this.Client_details_phone.getText().equals("")) {
            this.Client_details_phone.setStyle("-fx-text-fill: #f18080;-fx-prompt-text-fill: #f18080");
        } else if (this.Client_details_identity.getText().equals("")) {
            this.Client_details_identity.setStyle("-fx-text-fill: #f18080;-fx-prompt-text-fill: #f18080");
        } else if (this.Client_details_province_country.getText().equals("")) {
            this.Client_details_province_country.setStyle("-fx-text-fill: #f18080;-fx-prompt-text-fill: #f18080");
        } else if (this.Client_details_province_sex.getText().equals("")) {
            this.Client_details_province_sex.setStyle("-fx-text-fill: #f18080;-fx-prompt-text-fill: #f18080");
        } else if (this.Client_details_nationality.getText().equals("")) {
            this.Client_details_nationality.setStyle("-fx-text-fill: #f18080;-fx-prompt-text-fill: #f18080");
        } else {
            if (addMod.getText().equals("Ajoute")) {
                String id = this.data.addClient(this.compid, this.Client_details_name.getText(), this.Client_details_phone.getText(), this.Client_details_identity.getText(), this.Client_details_province_country.getText(), this.Client_details_nationality.getText(), this.Client_details_province_sex.getText(), this.Client_details_age.getValue().toString());
                confBooked(id);
            } else {
                this.data.modifyClient(this,Selected_record.get(Change_for).getClientid(),this.compid, this.Client_details_name.getText(), this.Client_details_phone.getText(), this.Client_details_identity.getText(), this.Client_details_province_country.getText(), this.Client_details_nationality.getText(), this.Client_details_province_sex.getText(), this.Client_details_age.getValue().toString(),Selected_record.get(Change_for).getBookid());
                addMod.setText("Ajoute");
                Change_for--;
                Change_date_name.setText(Client_details_name.getText());
                DisplaynextChange();
            }
            
        }
  }
  
  public Boolean add_to_confirm_box(String title) {
    try {
      this.ids = "";
      this.confirm_box.getChildren().clear();
      Integer size = Integer.valueOf(this.Selected_record.size());
      if (size.intValue() > 1) {
        this.confirm_number.setText(title + " " + size.toString() + "  personnes");
      } else if (size.intValue() == 1) {
        this.confirm_number.setText(title + " " + size.toString() + "  personne");
      } else {
        return Boolean.valueOf(false);
      } 
      for (Room_record rc : this.Selected_record) {
        this.ids += rc.getBookid() + ",";
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fx/confirm_person.fxml"));
        Parent root = loader.<Parent>load();
        confirm_person cont = loader.<confirm_person>getController();
        cont.init(rc.getName(), rc, this, title);
        this.confirm_box.getChildren().add(root);
      } 
    } catch (Exception x) {
      x.printStackTrace();
    } 
    return Boolean.valueOf(true);
  }
  
  @FXML
  private void confermed_next(ActionEvent event) {
    switch (this.mode) {
      case "paycheque":
        try {
          HashMap<String,Room_record> reg = new HashMap();
          ArrayList<TrancheGlobal.Facture> mFacture = new ArrayList();
          Map<String, Integer> Companies = new HashMap<>();
          for (Room_record sl : this.Selected_record) {
              TrancheGlobal.Facture fact;
              if(Companies.containsKey(sl.getCompFull())){
                  fact = mFacture.get(Companies.get(sl.getCompFull()));
                  fact.setFact(sl);
                  mFacture.set(Companies.get(sl.getCompFull()), fact);
              }
              else {
                  if(sl.getCompFull().toLowerCase().equals("prive")){
                    Companies.put(sl.getName(), Companies.size());
                    fact = new TrancheGlobal.Facture();
                    fact.setFact(sl);
                    fact.setMont(sl.getCash());
                    fact.setName(sl.getName());
                    HashMap<String,String> us = data.getOnline();
                    fact.setServer(us.get("server"));
                    fact.setService(us.get("service"));
                    fact.setNif(sl.getNif());
                    fact.setResi(sl.getRes());
                    fact.setFactN(this.data.getFact());
                    fact.setDateTime(sl.getDateout());
                    mFacture.add(fact);
                }
                else{
                    Companies.put(sl.getCompFull(), Companies.size());
                    fact = new TrancheGlobal.Facture();
                    fact.setFact(sl);
                    fact.setMont(sl.getCash());
                    fact.setName(sl.getCompFull());
                    HashMap<String,String> us = data.getOnline();
                    fact.setServer(us.get("server"));
                    fact.setService(us.get("service"));
                    fact.setNif(sl.getNif());
                    fact.setResi(sl.getRes());
                    fact.setFactN(this.data.getFact());
                    fact.setDateTime(sl.getDateout());
                    mFacture.add(fact);
                }
          }
              reg.put(fact.getFactN(), sl);
          } 
          JRPdfExporter jRPdfExporter = new JRPdfExporter();
          Dictionary dc = new Dictionary();
          Map<String, Object> parameters = new HashMap<>();
          InputStream input = getClass().getResourceAsStream("Facture.jasper");
          //JasperDesign jasperDesign = JRXmlLoader.load(input);
          //JasperReport jasperReport = JasperCompileManager.compileReport(jasperDesign);
          this.jasperPrint = JasperFillManager.fillReport(input, parameters, new JRBeanCollectionDataSource(mFacture));
          if(JasperPrintManager.printReport(jasperPrint,true)){
              data.saveClientF(this, reg);
          }
        } catch (Exception exception) {
          exception.printStackTrace();
        } 
        tab_load();
        break;
      case "remove":
        try {
          String reids = this.ids.substring(0, this.ids.length() - 1);
          this.data.remove(this,reids);
        } catch (Exception x) {
          close_windows();
        } 
        tab_load();
        break;
      case "date":
        DisplaynextChange();
        break;
    } 
  }
  
  Map<String, Integer[]> day_totals = (Map)new HashMap<>();
  
  ArrayList<List> Day_array;
  
  public void addDay_export(Day_record r, String d, Integer[] t, ArrayList<Room_record> day_rec) {
    this.day_totals.put(d, t);
    this.date_set.add(d);
    this.Day_array.add(day_rec);
  }
  
  ArrayList<String> date_set = new ArrayList<>();
  
  @FXML
  private void closeall(ActionEvent event) {
    Stage stage = (Stage)this.tab_from.getScene().getWindow();
    data.setAccountOff();
    stage.close();
  }
  
  @FXML
  private void minimize(ActionEvent event) {
    Stage stage = (Stage)this.tab_from.getScene().getWindow();
    stage.setIconified(true);
  }
  
    @FXML
  public void tab_load() {
      Integer index = Integer.valueOf(this.Tabs.getSelectionModel().getSelectedIndex());
      
        if (index.intValue() == 0) {
            if(this.tab_from.getValue().compareTo(this.tab_to.getValue()) < 0 ){
                this.data.room_tab_load(this, (LocalDate)this.tab_from.getValue(), (LocalDate)this.tab_to.getValue());
            }else{
                try {
                    room_tab_box.getChildren().clear();
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/fx/vide.fxml"));
                    Node root = loader.load();
                    vide vd = loader.getController();
                    vd.init("Vide de " + tab_from.getValue().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) + " a " + tab_to.getValue().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
                    room_tab_box.getChildren().add(root);
                } catch (Exception iO)
                {
                    iO.printStackTrace();
                }
            }
        } else if (index.intValue() == 1){
          if(this.tab_from.getValue().compareTo(this.tab_to.getValue()) <= 0 ){
            this.data.client_tab_load(this, (LocalDate)this.tab_from.getValue(), (LocalDate)this.tab_to.getValue());
          }else{
                try {
                    client_tab_box.getChildren().clear();
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/fx/vide.fxml"));
                    Node root = loader.load();
                    vide vd = loader.getController();
                    vd.init("Vide de " + tab_from.getValue().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) + " a " + tab_to.getValue().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
                    client_tab_box.getChildren().add(root);
                } catch (Exception iO)
                {
                    iO.printStackTrace();
                }
            }
        } else{
            if(this.tab_from.getValue().compareTo(this.tab_to.getValue()) < 0 ){
                this.data.LoadSemina(this, (LocalDate)this.tab_from.getValue(), (LocalDate)this.tab_to.getValue());
            }else{
                try {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/fx/vide.fxml"));
                    Node root = loader.load();
                    vide vd = loader.getController();
                    vd.init("Vide de " + tab_from.getValue().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) + " a " + tab_to.getValue().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
                    seminarBox.getChildren().clear();
                    seminarBox.getChildren().add(root);
                } catch (Exception iO)
                {
                    iO.printStackTrace();
                }
            }
        }
      
  }
  
  public void setDisable(Boolean cond) {
    this.hotelCombo.setDisable(cond);
    this.Tabs.setDisable(cond.booleanValue());
    this.tab_from.setDisable(cond.booleanValue());
    this.tab_to.setDisable(cond.booleanValue());
    this.Room_tab_name_holder.setDisable(cond.booleanValue());
  }
  
  @FXML
  private void client_tab_print(ActionEvent event) {
    this.load.toFront();
    setDisable(Boolean.valueOf(true));
    Task Export_records = new Task() {
        protected Object call() {
          try {
            String key_as_date = ((LocalDate)Base.this.tab_from.getValue()).format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
            updateMessage("Writing");
            JRBeanCollectionDataSource clients = null;
            InputStream input = getClass().getResourceAsStream("companies.jasper");
            Map<String, Object> parameters = new HashMap<>();
            parameters.put("ciz", hotelCombo.getValue());
            if (Base.this.client_position.intValue() == 0) {
              clients = new JRBeanCollectionDataSource(Base.this.firstJr);
              parameters.put("total_payed", ((String[])Base.this.bottom.get(0))[0]);
              parameters.put("unpayed", ((String[])Base.this.bottom.get(0))[1]);
              parameters.put("total", ((String[])Base.this.bottom.get(0))[2]);
              input = getClass().getResourceAsStream("companies.jasper");
            } else if (Base.this.client_position.intValue() == 1) {
              clients = new JRBeanCollectionDataSource(Base.this.secJr);
              parameters.put("total_payed", ((String[])Base.this.bottom.get(1))[0]);
              parameters.put("unpayed", ((String[])Base.this.bottom.get(1))[1]);
              parameters.put("total", ((String[])Base.this.bottom.get(1))[2]);
              parameters.put("name", Base.this.Current_Comp);
              input = getClass().getResourceAsStream("company.jasper");
            } else if (Base.this.client_position.intValue() == 2) {
              clients = new JRBeanCollectionDataSource(Base.this.thirdJr);
              parameters.put("total_payed", ((String[])Base.this.bottom.get(2))[0]);
              parameters.put("unpayed", ((String[])Base.this.bottom.get(2))[1]);
              parameters.put("total", ((String[])Base.this.bottom.get(2))[2]);
              parameters.put("name", Base.this.Current_Client);
              input = getClass().getResourceAsStream("client.jasper");
            } 
            parameters.put("date", key_as_date);
            parameters.put("created", "Created by " + Base.this.Room_tab_name_holder.getText() + " le " + LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
            parameters.put("Clients_data", clients);
            //JasperDesign jasperDesign = JRXmlLoader.load(input);
            //JasperReport jasperReport = JasperCompileManager.compileReport(jasperDesign);
            Base.this.jasperPrint = JasperFillManager.fillReport(input, parameters, (JRDataSource)new JREmptyDataSource());
            JasperPrintManager.printReport(Base.this.jasperPrint, true);
            Platform.runLater(new Runnable() {
                  public void run() {
                    Base.this.setDisable(Boolean.valueOf(false));
                    Base.this.Tabs.toFront();
                  }
                });
          } catch (Exception exception) {
            exception.printStackTrace();
          } 
          return Boolean.valueOf(true);
        }
      };
    this.parts.textProperty().unbind();
    this.parts.textProperty().bind(Export_records.messageProperty());
    this.load_show.progressProperty().unbind();
    this.load_show.progressProperty().bind(Export_records.progressProperty());
    (new Thread(Export_records)).start();
  }
  
  ArrayList<VBox> back_box = new ArrayList<>();
  
  @FXML
  private void client_tab_back(ActionEvent event) {
    if (this.client_position.intValue() > 0) {
      this.pay_selected.clear();
      Integer integer1 = this.client_position, integer2 = this.client_position = Integer.valueOf(this.client_position.intValue() - 1);
      this.client_tab_box.getChildren().clear();
      this.client_tab_box.getChildren().add(this.back_box.get(this.client_position.intValue()));
    } 
  }
  
  public Integer client_position = Integer.valueOf(0);
  
  public void PieShow() {
    this.Pie_Company.setData(this.Comp_pay);
  }
  
  @FXML
  public void Check_on_from() {
    Integer av = this.data.getAvailability_for_Change(this,(LocalDate)this.Change_date_new_from.getValue(), LocalDate.parse(((Room_record)this.Selected_record.get(this.Change_for.intValue())).getUdatein()), ((Room_record)this.Selected_record.get(this.Change_for.intValue())).getRoomid());
    if (av.intValue() < 0) {
      this.Change_date_new_from.setStyle("-fx-mid-text-color:#de6850");
      this.changer = Boolean.valueOf(false);
    } else {
      this.Change_date_new_from.setStyle("-fx-mid-text-color:#bfc9bf");
      Integer dys = this.data.getDays((LocalDate)this.Change_date_new_from.getValue(), (LocalDate)this.Change_date_new_to.getValue());
      Integer tot = Integer.valueOf(((Room_record)this.Selected_record.get(this.Change_for.intValue())).getPrice().intValue() * dys.intValue());
      this.Change_date_new_nights.setText(dys.toString());
      this.Change_date_total_cost.setText(this.data.French_numbers(tot.toString()));
      this.changer = Boolean.valueOf(true);
    } 
  }
  
  @FXML
  public void Check_on_to() {
    if (this.data.getAvailability_for_Change(this,LocalDate.parse(((Room_record)this.Selected_record.get(this.Change_for.intValue())).getUdateout()), (LocalDate)this.Change_date_new_to.getValue(), ((Room_record)this.Selected_record.get(this.Change_for.intValue())).getRoomid()).intValue() < 0) {
      this.Change_date_new_to.setStyle("-fx-mid-text-color:#de6850");
      this.changer = Boolean.valueOf(false);
    } else {
      this.Change_date_new_to.setStyle("-fx-mid-text-color:#bfc9bf");
      Integer dys = this.data.getDays((LocalDate)this.Change_date_new_from.getValue(), (LocalDate)this.Change_date_new_to.getValue());
      Integer tot = Integer.valueOf(((Room_record)this.Selected_record.get(this.Change_for.intValue())).getPrice().intValue() * dys.intValue());
      this.Change_date_new_nights.setText(dys.toString());
      this.Change_date_total_cost.setText(this.data.French_numbers(tot.toString()));
      this.changer = Boolean.valueOf(true);
    } 
  }
  
  @FXML
  private void calculate(KeyEvent event) {
    try {
      Integer pr = Integer.valueOf(Integer.parseInt(this.Change_date_room_price.getText()));
      Integer dys = this.data.getDays((LocalDate)this.Change_date_new_from.getValue(), (LocalDate)this.Change_date_new_to.getValue());
      Integer tot = Integer.valueOf(pr.intValue() * dys.intValue());
      this.Change_date_total_cost.setText(this.data.French_numbers(tot.toString()));
    } catch (Exception ex) {
      this.Change_date_room_price.setStyle("-fx-text-fill:#de6850;-fx-background-color: linear-gradient( from 25% 0% to 100% 150% ,#49505a,#434953);");
      this.changer = Boolean.valueOf(false);
    } 
  }
  
  Boolean changer = Boolean.valueOf(true);
  
  @FXML
  private void close_change(ActionEvent event) {
    DisplaynextChange();
  }
  
  private void DisplaynextChange() {
    Integer integer1 = this.Change_for, integer2 = this.Change_for = Integer.valueOf(this.Change_for.intValue() + 1);
    if (this.Change_for.intValue() < this.Selected_record.size()) {
      close_windows();
      setDisable(Boolean.valueOf(true));
      this.Change_date.toFront();
      Room_record rc = this.Selected_record.get(this.Change_for.intValue());
      this.bookid = rc.getBookid();
      this.Change_date_new_from.setValue(LocalDate.parse(rc.getUdatein()));
      this.Change_date_new_to.setValue(LocalDate.parse(rc.getUdateout()));
      this.Change_date_name.setText(rc.getName());
      this.Change_date_room_price.setText(rc.getPrice().toString());
      this.Change_date_total_cost.setText(this.data.French_numbers(rc.getTotal_cost().toString()));
      if (rc.getPayed().equals("true"))
        this.Change_date_payed.setSelected(true); 
      if (rc.getCash().equals("true"))
        this.Change_date_cash.setSelected(true);
    } else {
      close_windows();
      tab_load();
      this.Change_for = Integer.valueOf(-1);
    } 
  }
  
  @FXML
  private void search_clients_company(KeyEvent event) {
    String s = this.Company_Client_chooser_search.getText().toLowerCase();
    this.Company_Client_chooser_box.getChildren().clear();
    for (Map.Entry<String, Parent> entrySet : this.clients_company_search.entrySet()) {
      String key = entrySet.getKey();
      Parent value = entrySet.getValue();
      if (key.contains(s) || s.equals(""))
        this.Company_Client_chooser_box.getChildren().add(value); 
    } 
  }
  
  public ArrayList<String[]> bottom = (ArrayList)new ArrayList<>();
  
  JasperPrint jasperPrint;
  
  public String Current_Comp;
  
  public String Current_Client;
  
  public ArrayList<String> pay_selected = new ArrayList<>();
  
  @FXML
  private void Selected_payed(ActionEvent event) {
    this.data.pay(this);
  }
  
  public void show(Room_record book) {
    this.book = new Confirm_book(book.getCompid(),book.getClientid(),book.getBookid(),book.getCompany(),book.getName(),book.getPhone(),book.getIdentity(),book.getProvince(),book.getRoom(),book.getPrice().toString(),book.getDatein(),book.getDateout(),book.getDays().toString(),book.getNationality(),book.getAge(),book.getSex(),book.getCompFull());
    this.Room_tab_conf.toFront();
    setDisable(Boolean.valueOf(true));
    this.Conf_payed.setVisible(false);
    this.done_conf.setVisible(false);
    this.Conf_name.setText(book.getName());
    this.conf_nationality.setText(book.getNationality());
    this.conf_age.setText(book.getAge());
    this.conf_sex.setText(book.getSex());
    this.Conf_phone.setText(book.getPhone());
    this.Conf_province.setText(book.getProvince());
    this.Conf_from.setText(book.getDatein());
    this.Conf_room.setText(book.getRoom());
    this.Conf_nights.setText(book.getDays().toString());
    this.Conf_totalcost.setText(book.getTotal_cost().toString());
    this.Conf_price.setText(book.getPrice().toString());
    this.Conf_to.setText(book.getDateout());
    this.Conf_company.setText(book.getCompany());
    this.Room_tab_conf.toFront();
  }
    @FXML
  public void toArthur()
    {
        notify("Program","Problem at green Hills");
    }
        public void notify(String s,String m)
    {
        Task ts = new Task(){
            protected Object call(){
                // Sending email from gmail
                String host = "smtp.gmail.com";

                // Port of SMTP
                String port = "465";

                Properties properties = new Properties();

                properties.put("mail.smtp.socketFactory.port", port);
                properties.put("mail.smtp.socketFactory.class","javax.net.ssl.SSLSocketFactory");
                properties.put("mail.smtp.auth", "true");
                properties.put("mail.smtp.ssl", "true");
                properties.put("mail.smtp.host", host);
                properties.put("mail.smtp.port", port);

                // Create session object passing properties and authenticator instance
                Session session = Session.getDefaultInstance(properties, null);
                session.setDebug(true);

                try
                {
                    // Create MimeMessage object
                    MimeMessage msg = new MimeMessage(session);
                    msg.setSubject(s);                
                    msg.setText(m, "ISO-8859-1");
                    msg.setSentDate(new Date());
                    msg.setHeader("content-Type", "text/html;charset=\"ISO-8859-1\"");
                    msg.addRecipient(Message.RecipientType.TO, new InternetAddress("arthurninda@gmail.com"));
                    msg.saveChanges();

                    // Send email.
                    Transport transport = session.getTransport("smtp");
                    transport.connect(host,"arthurninda@gmail.com", "1999arthur");
                    transport.sendMessage(msg, msg.getAllRecipients());
        //            Transport.send(message);
                    transport.close();
                } catch (MessagingException me)
                {
                    me.printStackTrace();
                }
                return true;
            }
        };
        new Thread(ts).start();
    }

    @FXML
    private void Police_report(ActionEvent event) {
        LocalDate Tf = export_date_from.getValue();
        LocalDate Tt = export_date_to.getValue();
        try{
            InputStream input = getClass().getResourceAsStream("Police.jasper");
            Map<String, Object> parameters = new HashMap<>();
            parameters.put("ciz","CIZANYE");
            //JasperDesign jasperDesign = JRXmlLoader.load(input);
            //JasperReport jasperReport = JasperCompileManager.compileReport(jasperDesign);
            Base.this.jasperPrint = JasperFillManager.fillReport(input, parameters,new JRBeanCollectionDataSource(data.getPolice(this,Tf,Tt)));
            JRPdfExporter exporter = new JRPdfExporter();
            exporter.setParameter(JRPdfExporterParameter.JASPER_PRINT, jasperPrint);
            FileChooser ch = new FileChooser();
            File lc = ch.showSaveDialog(Base.this.confirm.getScene().getWindow());
            lc = new File(lc.getPath() + ".pdf");
            exporter.setParameter(JRPdfExporterParameter.OUTPUT_FILE, lc);
            exporter.exportReport(); 
          } catch (Exception exception) {
            exception.printStackTrace();
          } 
    }

    @FXML
    private void trache_report(ActionEvent event) {
        LocalDate Tf = export_date_from.getValue();
        LocalDate Tt = export_date_to.getValue();
        try{
            InputStream input = getClass().getResourceAsStream("Tranche_Global"+this.getHot()+".jasper");
            Map<String, Object> parameters = new HashMap<>();
            parameters.put("ciz", hotelCombo.getValue());
            //JasperDesign jasperDesign = JRXmlLoader.load(input);
            //JasperReport jasperReport = JasperCompileManager.compileReport(jasperDesign);
            Base.this.jasperPrint = JasperFillManager.fillReport(input, parameters,new JRBeanCollectionDataSource(data.getTrancheGlobal(Tf,Tt,this)));
            JRPdfExporter exporter = new JRPdfExporter();
            exporter.setParameter(JRPdfExporterParameter.JASPER_PRINT, jasperPrint);
            FileChooser ch = new FileChooser();
            File lc = ch.showSaveDialog(Base.this.confirm.getScene().getWindow());
            lc = new File(lc.getPath() + ".pdf");
            exporter.setParameter(JRPdfExporterParameter.OUTPUT_FILE, lc);
            exporter.exportReport();    
          } catch (Exception exception) {
            exception.printStackTrace();
          } 
    }

    @FXML
    private void global(ActionEvent event) {
        LocalDate Tf = export_date_from.getValue();
        LocalDate Tt = export_date_to.getValue();
        try{
            InputStream input = getClass().getResourceAsStream("MoreInOne.jasper");
            Map<String, Object> parameters = new HashMap<>();
            //JasperDesign jasperDesign = JRXmlLoader.load(input);
            //JasperReport jasperReport = JasperCompileManager.compileReport(jasperDesign);
            Base.this.jasperPrint = JasperFillManager.fillReport(input, parameters,new JRBeanCollectionDataSource(data.getMonthGlobal(Tf,Tt,this)));
            JRPdfExporter exporter = new JRPdfExporter();
            exporter.setParameter(JRPdfExporterParameter.JASPER_PRINT, jasperPrint);
            FileChooser ch = new FileChooser();
            File lc = ch.showSaveDialog(Base.this.confirm.getScene().getWindow());
            lc = new File(lc.getPath() + ".pdf");
            exporter.setParameter(JRPdfExporterParameter.OUTPUT_FILE, lc);
            exporter.exportReport();     
          } catch (Exception exception) {
            exception.printStackTrace();
          } 
    }

    @FXML
    private void depenceAdd(ActionEvent event) {
        depenceDescr.setStyle("-fx-text-fill: #dad7d7;-fx-prompt-text-fill: #dad7d7");
        depenceMoney.setStyle("-fx-text-fill: #dad7d7;-fx-prompt-text-fill: #dad7d7");
        if(depenceDescr.getText().equals("")){
            depenceDescr.setStyle("-fx-text-fill: #f18080;-fx-prompt-text-fill: #f18080");
        }
        else{
            try{
                Boolean gl = depenceShowGlobal.isSelected(),ch = depenceCash.isSelected();
                Integer Mn= Integer.parseInt(depenceMoney.getText());
                data.InsetDepence(depenceDescr.getText(), depenceMoney.getText(), depenceDate.getValue().toString(), this,gl.toString(),ch.toString(),!depenceShowGlobal.isVisible());
                if(depenceShowGlobal.isVisible()){
                    getDepence();
                }else{
                    getVerssement();
                }
            }
            catch(Exception e){
                depenceMoney.setStyle("-fx-text-fill: #f18080;-fx-prompt-text-fill: #f18080");
            }
        }
    }

    @FXML
    private void depenceNew(ActionEvent event) {
        setDisable(true);
        Tabs.toFront();
        AddDepenses.toFront();
        depenceDate.setValue(LocalDate.now());
        if(comp_clie_tit1.getText().equals("Depenses")){
            depenceShowGlobal.setVisible(true);
            depenceCash.setVisible(true);
            comp_clie_tit11.setText("Depenses");
        }else{
            depenceShowGlobal.setVisible(false);
            depenceCash.setVisible(false);
            comp_clie_tit11.setText("Verssement");
        }
        depenceShowGlobal.setSelected(false);
        depenceCash.setSelected(false);
    }

    public void removeDepence(Node root) {
        depenceBox.getChildren().remove(root);
    }

    public void getDepence() {
        depenceShowGlobal.setVisible(true);
        Tabs.toFront();
        setDisable(true);
        Depenses.toFront();  
        comp_clie_tit1.setText("Depenses");
        comp_clie_tit12.setText("Depenses");
        data.getDepence(this,depenceFrom.getValue(),depenceTo.getValue(),false);
    }
    public void setDBox(Node n){
        depenceBox.getChildren().add(n);
    }

    public void clearDBox() {
        depenceBox.getChildren().clear();
    }

    @FXML
    private void printDepences(ActionEvent event) {
        LocalDate Tf = export_date_from.getValue();
        LocalDate Tt = export_date_to.getValue();
        try{
            InputStream input = getClass().getResourceAsStream("MoreInOne.jasper");
            Map<String, Object> parameters = new HashMap<>();
            //JasperDesign jasperDesign = JRXmlLoader.load(input);
            //JasperReport jasperReport = JasperCompileManager.compileReport(jasperDesign);
            Base.this.jasperPrint = JasperFillManager.fillReport(input, parameters,new JRBeanCollectionDataSource(data.getTrancheDepence(Tf,Tt,this)));
            JRPdfExporter exporter = new JRPdfExporter();
            exporter.setParameter(JRPdfExporterParameter.JASPER_PRINT, jasperPrint);
            FileChooser ch = new FileChooser();
            File lc = ch.showSaveDialog(Base.this.confirm.getScene().getWindow());
            lc = new File(lc.getPath() + ".pdf");
            exporter.setParameter(JRPdfExporterParameter.OUTPUT_FILE, lc);
            exporter.exportReport();  
          } catch (Exception exception) {
            exception.printStackTrace();
          } 
    }

    @FXML
    private void Conf_print(ActionEvent event) {
        try{
            InputStream input = getClass().getResourceAsStream("Registration.jasper");
            Map<String, Object> pa = new HashMap<>();
            pa.put("server", Room_tab_name_holder.getText());
            pa.put("ciz",this.hotelCombo.getValue());
            ArrayList<Confirm_book> ar = new ArrayList();
            ar.add(book);
            //JasperDesign jasperDesign = JRXmlLoader.load(input);
            //JasperReport jasperReport = JasperCompileManager.compileReport(jasperDesign);
            Base.this.jasperPrint = JasperFillManager.fillReport(input, pa,new JRBeanCollectionDataSource(ar));
            JRPdfExporter exporter = new JRPdfExporter();
            exporter.setParameter(JRPdfExporterParameter.JASPER_PRINT, jasperPrint);
            FileChooser ch = new FileChooser();
            File lc = ch.showSaveDialog(Base.this.confirm.getScene().getWindow());
            lc = new File(lc.getPath() + ".pdf");
            exporter.setParameter(JRPdfExporterParameter.OUTPUT_FILE, lc);
            exporter.exportReport();  
          } catch (Exception exception) {
            exception.printStackTrace();
          } 
    }

    @FXML
    private void addSeminar(ActionEvent event) {
        setDisable(true);
        Tabs.toFront();
        AddSeminar.toFront();
        ObservableList<String> ob = data.getCompaniesForSem();
        AddSeminarCombo.setItems(ob);
        AddSeminarDate.setValue(LocalDate.now());
    }

    @FXML
    private void AddSeminarAdded(ActionEvent event) {
        if(!AddSeminarCombo.getValue().equals("")){
            data.addSemina(this,AddSeminarCombo.getValue(),AddSeminarDate.getValue());
        }
        
    }

    @FXML
    private void AddComp(ActionEvent event) {
        this.add_client = Boolean.valueOf(false);
        Tabs.toFront();
        this.new_company.toFront();
        sembook = true;
    }
    boolean sembook = false;
    private void addCompany() {
        this.new_company_name.setStyle("-fx-text-fill: #dad7d7;-fx-prompt-text-fill: #dad7d7");
        if (this.new_company_name.getText().equals("")) {
          this.new_company_name.setStyle("-fx-text-fill: #f18080;-fx-prompt-text-fill: #f18080");
        }else if (this.new_company_short.getText().equals("")) {
          this.new_company_short.setStyle("-fx-text-fill: #f18080;-fx-prompt-text-fill: #f18080");
        }
        else if (this.newCompanyResidence.getText().equals("")) {
          this.newCompanyResidence.setStyle("-fx-text-fill: #f18080;-fx-prompt-text-fill: #f18080");
        }
        else if (this.new_companyNif.getText().equals("")) {
          this.new_companyNif.setStyle("-fx-text-fill: #f18080;-fx-prompt-text-fill: #f18080");
        }
        else if (!sembook){
          String id = this.data.newCompany(this.new_company_name.getText(),new_company_short.getText(),new_companyNif.getText(),this.newCompanyResidence.getText());
          getClients(id);
          this.Company_Client_chooser.toFront();
        } else {
            String id = this.data.newCompany(this.new_company_name.getText(),new_company_short.getText(),new_companyNif.getText(),this.newCompanyResidence.getText());
            setDisable(true);
            Tabs.toFront();
            AddSeminar.toFront();
            ObservableList<String> ob = data.getCompaniesForSem();
            AddSeminarCombo.setItems(ob);
            AddSeminarCombo.setValue(new_company_short.getText());
            AddSeminarDate.setValue(LocalDate.now());
        }
    }

    public void printSeminar(seminaSecondTitle sm,ArrayList<seminarItem> sav) {
        try{
            InputStream input = getClass().getResourceAsStream("Semina.jasper");
            //JasperDesign jasperDesign = JRXmlLoader.load(input);
            //JasperReport jasperReport = JasperCompileManager.compileReport(jasperDesign);
            ArrayList<seminaSecondTitle> ar = new ArrayList();
            ar.add(sm);
            Base.this.jasperPrint = JasperFillManager.fillReport(input, new HashMap(),new JRBeanCollectionDataSource(ar));
            JRPdfExporter exporter = new JRPdfExporter();
            exporter.setParameter(JRPdfExporterParameter.JASPER_PRINT, jasperPrint);
            FileChooser ch = new FileChooser();
            File lc = ch.showSaveDialog(Base.this.confirm.getScene().getWindow());
            lc = new File(lc.getPath() + ".pdf");
            exporter.setParameter(JRPdfExporterParameter.OUTPUT_FILE, lc);
            exporter.exportReport(); 
            data.saveseminaF(sm.getFactN(), sm.Compid, sm.getDate(),sav);
          } catch (Exception exception) {
            exception.printStackTrace();
          } 
    }

    @FXML
    private void semina_tab_export(ActionEvent event) {
        String Tf = tab_from.getValue().toString();
        String Tt = tab_to.getValue().toString();
        try{
            InputStream input = getClass().getResourceAsStream("seminaReport.jasper");
            Map<String, Object> parameters = new HashMap<>();
            parameters.put("Total", new Database().getTotal(Tf, Tt));
            parameters.put("ciz",this.hotelCombo.getValue());
            //JasperDesign jasperDesign = JRXmlLoader.load(input);
            //JasperReport jasperReport = JasperCompileManager.compileReport(jasperDesign);
            Base.this.jasperPrint = JasperFillManager.fillReport(input, parameters,new JRBeanCollectionDataSource(data.getSReport(Tf,Tt)));
            JRPdfExporter exporter = new JRPdfExporter();
            exporter.setParameter(JRPdfExporterParameter.JASPER_PRINT, jasperPrint);
            FileChooser ch = new FileChooser();
            File lc = ch.showSaveDialog(Base.this.confirm.getScene().getWindow());
            lc = new File(lc.getPath() + ".pdf");
            exporter.setParameter(JRPdfExporterParameter.OUTPUT_FILE, lc);
            exporter.exportReport();   
          } catch (Exception exception) {
            exception.printStackTrace();
          } 
    }
    public char getHot(){
        String va = hotelCombo.getValue();
        return va.charAt(va.length()-1);
    }

    @FXML
    private void clientFactureH(ActionEvent event) {
        LocalDate Tf = export_date_from.getValue();
        LocalDate Tt = export_date_to.getValue();
        try{
            InputStream input = getClass().getResourceAsStream("Facture.jasper");
            Map<String, Object> parameters = new HashMap<>();
            //JasperDesign jasperDesign = JRXmlLoader.load(input);
            //JasperReport jasperReport = JasperCompileManager.compileReport(jasperDesign);
            Base.this.jasperPrint = JasperFillManager.fillReport(input, parameters,data.getFactureReport(this, Tf.toString(), Tt.toString()));
            JRPdfExporter exporter = new JRPdfExporter();
            exporter.setParameter(JRPdfExporterParameter.JASPER_PRINT, jasperPrint);
            FileChooser ch = new FileChooser();
            File lc = ch.showSaveDialog(Base.this.confirm.getScene().getWindow());
            lc = new File(lc.getPath() + ".pdf");
            exporter.setParameter(JRPdfExporterParameter.OUTPUT_FILE, lc);
            exporter.exportReport();     
          } catch (Exception exception) {
            exception.printStackTrace();
          } 
    }

    @FXML
    private void seminaFactureH(ActionEvent event) {
        try{
            InputStream input = getClass().getResourceAsStream("Semina.jasper");
            Map<String, Object> parameters = new HashMap<>();
            //JasperDesign jasperDesign = JRXmlLoader.load(input);
            //JasperReport jasperReport = JasperCompileManager.compileReport(jasperDesign);
            Base.this.jasperPrint = JasperFillManager.fillReport(input, parameters,new JRBeanCollectionDataSource(data.getSeminaFactureReport(tab_from.getValue(), tab_to.getValue())));
            JRPdfExporter exporter = new JRPdfExporter();
            exporter.setParameter(JRPdfExporterParameter.JASPER_PRINT, jasperPrint);
            FileChooser ch = new FileChooser();
            File lc = ch.showSaveDialog(Base.this.confirm.getScene().getWindow());
            lc = new File(lc.getPath() + ".pdf");
            exporter.setParameter(JRPdfExporterParameter.OUTPUT_FILE, lc);
            exporter.exportReport();    
          } catch (Exception exception) {
            exception.printStackTrace();
          } 
    }

    @FXML
    private void modifyClient(MouseEvent event) {
        this.Client_details_name.setText(Selected_record.get(Change_for).getName());
        this.Client_details_phone.setText(Selected_record.get(Change_for).getPhone());
        this.Client_details_identity.setText(Selected_record.get(Change_for).getIdentity());
        this.Client_details_province_country.setText(Selected_record.get(Change_for).getProvince());
        this.Client_details_nationality.setText(Selected_record.get(Change_for).getNationality());
        this.Client_details_province_sex.setText(Selected_record.get(Change_for).getSex());
        this.Client_details_age.setValue(data.getAge(Selected_record.get(Change_for).getClientid()));
        setDisable(true);
        new_client.toFront();
        addMod.setText("Modifier");
    }

    public void getVerssement() {
        depenceShowGlobal.setVisible(false);
        Tabs.toFront();
        setDisable(true);
        comp_clie_tit1.setText("Verssemnt");
        comp_clie_tit12.setText("Verssemnt");
        Depenses.toFront();        
        data.getDepence(this,depenceFrom.getValue(),depenceTo.getValue(),true);
    }

    @FXML
    private void getVD(ActionEvent event) {
        if(depenceShowGlobal.isVisible()){
            getDepence();
        }else{
            getVerssement();
        }
    }
    
}
