package jc;

import com.jfoenix.controls.JFXCheckBox;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.shape.Line;

public class Client_in_room implements Initializable {
  @FXML
  private Label identity;
  
  @FXML
  private Label province;
  
  @FXML
  private Label company;
  
  @FXML
  private Label price;
  
  @FXML
  private Label room_number;
  
  @FXML
  private Label name;
  
  @FXML
  private Label phone;
  
  @FXML
  private JFXCheckBox select;
  
  @FXML
  private Line room_line;
  
  Base base;
  
  Room_record record;
  
  public void initialize(URL url, ResourceBundle rb) {}
  
  public void init(Room_record rec, Base bs) {
    this.record = rec;
    this.base = bs;
    this.name.setText(rec.getName());
    this.room_number.setText(rec.getRoom());
    this.identity.setText(rec.getIdentity());
    this.province.setText(rec.getProvince());
    this.company.setText(rec.getCompany());
    this.price.setText(rec.getPrice().toString());
    this.phone.setText(rec.getPhone());
    if (rec.getPayed().equals("false"))
      this.room_line.setStyle("-fx-stroke:#ff4848"); 
  }
  
  @FXML
  private void add_to_selected(ActionEvent event) {
    if (this.select.isSelected()) {
      this.base.Selected_record.add(this.record);
      this.base.Change_for = Integer.valueOf(-1);
    } else {
      this.base.Selected_record.remove(this.record);
      Base base = this.base;
      Integer integer1 = base.Change_for, integer2 = base.Change_for = Integer.valueOf(base.Change_for.intValue() + 1);
    } 
  }
  
  @FXML
  private void show_confirm(MouseEvent event) {
    this.base.show(this.record);
  }
}
