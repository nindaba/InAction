package jc;

import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class Empty_room implements Initializable {
  @FXML
  private Label room_number;
  
  @FXML
  private TextField room_price;
  
  @FXML
  private Label room_nights;
  
  @FXML
  private Label room_from_date;
  
  String number;
  
  Base bs;
  
  public void initialize(URL url, ResourceBundle rb) {}
  
  @FXML
  private void add_client(ActionEvent event) {
    this.bs.Add_client(this.number, date, this.room_price.getText(), this.room_nights.getText());
  }
  String date;
  public void init(Base b, String n, String[] d) {
    this.bs = b;
    this.number = n;
    this.room_number.setText(d[2]);
    this.room_nights.setText(d[0]);
    date = d[1];
    this.room_from_date.setText(LocalDate.parse(d[1]).format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
    this.room_price.setText(d[3]);
  }
}
