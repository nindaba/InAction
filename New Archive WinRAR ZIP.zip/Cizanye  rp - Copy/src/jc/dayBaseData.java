/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jc;

import java.util.ArrayList;

/**
 *
 * @author Bosco
 */
public class dayBaseData {
    ArrayList<String> HRoomNumbers;
    ArrayList<String> ORoomNumbers;
    ArrayList<String> Money;
    ArrayList<String> CompMoney;
    public void dayBaseData(){
        
    }
    
}
