package jc;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

public class Company_header implements Initializable {
  @FXML
  private Label name;
  
  @FXML
  private Label payed;
  
  @FXML
  private Label un_payed;
  
  @FXML
  private Label total;
  
  public void initialize(URL url, ResourceBundle rb) {}
  
  public void init(String n, String p, String u, String t) {
    this.name.setText(n);
    this.payed.setText(p);
    this.un_payed.setText(u);
    this.total.setText(t);
  }
}
