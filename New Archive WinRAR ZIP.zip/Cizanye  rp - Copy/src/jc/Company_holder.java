package jc;

import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.chart.PieChart;

public class Company_holder {
  FXMLLoader loader;
  
  Parent root;
  
  Company comp_cont;
  
  Integer p;
  
  Integer u;
  
  Integer t;
  
  String name;
  
  Base base;
  
  Database data;
  
  Company_holder(String n) {
    this.data = new Database();
    this.loader = new FXMLLoader(getClass().getResource("/fx/Company.fxml"));
    this.name = n;
    this.p = Integer.valueOf(0);
    this.u = Integer.valueOf(0);
    this.t = Integer.valueOf(0);
    try {
      this.root = this.loader.<Parent>load();
    } catch (Exception ex) {
      ex.printStackTrace();
    } 
    this.comp_cont = this.loader.<Company>getController();
  }
  
  public void init(Base b, String c, String n, Integer payed, Integer un_payed, Integer total) {
    this.base = b;
    this.p = Integer.valueOf(this.p.intValue() + payed.intValue());
    this.u = Integer.valueOf(this.u.intValue() + un_payed.intValue());
    this.t = Integer.valueOf(this.t.intValue() + total.intValue());
    this.comp_cont.init(this.base, c, n, this.data.French_numbers(this.p.toString()), this.data.French_numbers(this.u.toString()), this.data.French_numbers(this.t.toString()));
  }
  
  public Parent getCompany() {
    Platform.runLater(new Runnable() {
          public void run() {
            Company_holder.this.base.Comp_pay.add(new PieChart.Data(Company_holder.this.name, Company_holder.this.t.intValue()));
          }
        });
    return this.root;
  }
  
  public companies_jr addJrList() {
    return new companies_jr(this.name, this.data.French_numbers(this.p.toString()), this.data.French_numbers(this.u.toString()), this.data.French_numbers(this.t.toString()));
  }
}
