package jc;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Confirm_book {
  private final String company;
  
  private final String name;
  
  private final String phone;
  
  private final String id;
  
  private final String province;
  
  private final String price;
  
  private final String from;
  
  private final String to;
  
  private final String nights;
  
  private final String totalcost;
  
  private final String room;
  
  private final String compid;
  
  private final String clientid;
  
  private final String roomid;
  private final String CompFull;
  
  private final String nationality;
  public final String french;
  private final String age;
  private final String sex;
  
  Confirm_book(String cpd, String clid, String rmid, String c, String n, String p, String i, String pr, String r, String pc, String f, String t, String ni,String nat,String age,String sex,String cf) {
    this.company = c;
    this.CompFull = cf;
    this.nationality = nat;
    this.age =age;
    this.sex = sex;
    this.name = n;
    this.phone = p;
    this.id = i;
    this.province = pr;
    this.room = r;
    this.price = pc;
    this.from = f;
    this.to = t;
    this.nights = ni;
    Integer tl = Integer.valueOf(Integer.parseInt(ni) * Integer.parseInt(pc));
    this.totalcost = tl.toString();
    this.compid = cpd;
    this.clientid = clid;
    this.roomid = rmid;
    Dictionary dc = new Dictionary();
    this.french = dc.Frech(totalcost);
  }
  public String getNous(){
      return french;
  }
  public String getCompany() {
    return this.company;
  }
  
  public String getName() {
    return this.name;
  }
  
  public String getPhone() {
    return this.phone;
  }
  public String getToDate(){
      try {
          return LocalDate.parse(to).format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
      } catch (Exception e) {
          return to;
      }
  }
   public String getFromDate(){
       try {
           return LocalDate.parse(from).format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
       } catch (Exception e) {
           return from;
       }
  }
  public String getId() {
    return this.id;
  }
  
  public String getProvince() {
    return this.province;
  }
  
  public String getRoom() {
    return this.room;
  }
  
  public String getPrice() {
    return this.price;
  }
  
  public String getFrom() {
    return this.from;
  }
  
  public String getTo() {
    return this.to;
  }
    public String getCompFull() {
    return this.CompFull;
  }
  
  public String getNationality() {
    return this.nationality;
  }
  
  public String getAge() {
    return this.age;
  }
  
  public String getSex() {
    return this.sex;
  }
  public String getNights() {
    return this.nights;
  }
  
  public String getTotalcost() {
    return this.totalcost;
  }
  
  public String getCompid() {
    return this.compid;
  }
  
  public String getClientid() {
    return this.clientid;
  }
  
  public String getRoomid() {
    return this.roomid;
  }
}
