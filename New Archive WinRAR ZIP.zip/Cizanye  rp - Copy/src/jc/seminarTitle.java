/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jc;

import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Line;

/**
 * FXML Controller class
 *
 * @author Bosco
 */
public class seminarTitle implements Initializable {

    @FXML
    private Line line2;
    @FXML
    private Label name;
    @FXML
    private Label date;
    @FXML
    private Label total;
    private String Odate;
    @FXML
    private VBox box;
    public void setDate(String d){
        Odate = d;
        date.setText(LocalDate.parse(d).format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
    }
    public void setName(String d){
        name.setText(d);
    }
    public String getDate(){
        return date.getText();
    }
    String Total;
    public void setTotal(String d){
        Total = d;
        total.setText(new Database().French_numbers(d));
    }
    private String compid;
    public String getCompid(){
        return compid;
    }
    public void setCompid(String s){
        compid = s;
    }
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void remove(ActionEvent event) {
        new Database().removeSeminaAll(compid, Odate);
        base.seminarBox.getChildren().remove(node);
    }
    private Node node;
    public void setIndex(Node i){
        node = i;
    }
    private Base base;
    public void setBase(Base bs) {
        base = bs;
    }

    public void getItems() {
        try {
            HashMap<Integer,ArrayList> items = new Database().getSItems(this,compid, Odate);
            ArrayList<Node> iNodes = items.get(0);
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fx/seminaSecondTitle.fxml"));
            Node nd = loader.load();
            seminaSecondTitle tt = loader.getController();
            this.setTotal(new Database().getTitleTotal(Odate,compid));
            tt.setItems(items.get(1),compid,base,Total,Odate);
            Node n0 = box.getChildren().get(0);
            box.getChildren().clear();
            box.getChildren().add(n0);
            box.getChildren().add(nd);
            box.getChildren().addAll(iNodes);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void removeI(Node node) {
        box.getChildren().remove(node);
    }
}
