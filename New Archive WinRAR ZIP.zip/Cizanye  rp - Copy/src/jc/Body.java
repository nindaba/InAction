package jc;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class Body extends Application {
  public void start(Stage stage) throws Exception {
    Parent root = FXMLLoader.<Parent>load(getClass().getResource("/fx/Base.fxml"));
    Scene scene = new Scene(root);
    stage.setScene(scene);
    stage.getIcons().add(new Image("/fx/icon.PNG"));
    stage.initStyle(StageStyle.UNDECORATED);
    stage.show();
  }
  
  public static void main(String[] args) {
    launch(args);
  }
}
