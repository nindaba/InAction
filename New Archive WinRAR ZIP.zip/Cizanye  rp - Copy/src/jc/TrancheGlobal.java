/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jc;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

/**
 *
 * @author Bosco
 */
public  class TrancheGlobal {
    public ArrayList<CompSumary> GetCompSumary(){
        return compMoney;
    }
    public ArrayList<HRooms> GetHRooms(){
        return cizanyeRooms;
    }
    public ArrayList<ORooms> GetORooms(){
        return othersRooms;
    }
    public void addCompSumary(CompSumary c){
        compMoney.add(c);
    }
    /**
     * @return the cizanyeRooms
     */
    public JRBeanCollectionDataSource getCizanyeRooms() {
        return new JRBeanCollectionDataSource(cizanyeRooms);
    }

    /**
     * @param cizanyeRooms the cizanyeRooms to set
     */
    public void setCizanyeRooms(HRooms cs) {
        this.cizanyeRooms.set(0,cs);
    }
    public void setCizanyeRooms1(HRooms cs) {
        this.cizanyeRooms.add(0,cs);
    }
    /**
     * @return the othersRooms
     */
    public JRBeanCollectionDataSource getOthersRooms() {
        return new JRBeanCollectionDataSource(othersRooms);
    }

    /**
     * @param othersRooms the othersRooms to set
     */
    public Boolean getOther(){
        return other;
    }
    private Boolean other = false;
    public void setOthersRooms(ORooms ms) {
        other = true;
        this.othersRooms.add(ms);
    }
    public ORooms GetORooms(Integer a){
        if ( a == othersRooms.size()) {
            setOthersRooms(new ORooms());
        }
        return this.othersRooms.get(a);
    }
    public void placeORooms(Integer a,ORooms r){
        this.othersRooms.set(a,r);
    }
    /**
     * @return the totals
     */
    public JRBeanCollectionDataSource getTotals() {
        return new JRBeanCollectionDataSource(totals);
    }

    /**
     * @param totals the totals to set
     */
    public void setTotals(ArrayList<Totals> totals) {
        this.totals = totals;
    }

    /**
     * @return the compMoney
     */
    public JRBeanCollectionDataSource getCompMoney() {
        return new JRBeanCollectionDataSource(compMoney);
    }

    /**
     * @param compMoney the compMoney to set
     */
    public void setCompMoney(CompSumary ney) {
        this.compMoney.add(ney);
    }
    public void SetComp(Integer ad,CompSumary cs){
        this.compMoney.set(ad, cs);
    }
    /**
     * @return the trancheSummary
     */
    public JRBeanCollectionDataSource getTrancheSummary() {
        return new JRBeanCollectionDataSource(trancheSummary);
    }

    /**
     * @param trancheSummary the trancheSummary to set
     */
    public void setTrancheSummary(ArrayList<Summary> trancheSummary) {
        this.trancheSummary = trancheSummary;
    }

    /**
     * @return the totalSummary
     */
    public JRBeanCollectionDataSource getTotalSummary() {
        return new JRBeanCollectionDataSource(totalSummary);
    }

    /**
     * @return the trancheNumber
     */
    public String getTrancheNumber() {
        return trancheNumber;
    }

    /**
     * @param trancheNumber the trancheNumber to set
     */
    public void setTrancheNumber(String trancheNumber) {
        this.trancheNumber = trancheNumber;
    }

    /**
     * @return the trancheDateRange
     */
    public String getTrancheDateRange() {
        return trancheDateRange;
    }

    /**
     * @param trancheDateRange the trancheDateRange to set
     */
    public void setTrancheDateRange(String trancheDateRange) {
        this.trancheDateRange = trancheDateRange;
    }

    /**
     * @return the fromDate
     */
    public String getFromDate() {
        return fromDate;
    }

    /**
     * @param fromDate the fromDate to set
     */
    public void setFromDate(String fromDate) {
        this.fromDate = fromDate;
    }

    /**
     * @return the toDate
     */
    public String getToDate() {
        return toDate;
    }

    /**
     * @param toDate the toDate to set
     */
    public void setToDate(String toDate) {
        this.toDate = toDate;
    }
    private ArrayList<HRooms> cizanyeRooms = new ArrayList();
    private ArrayList<ORooms> othersRooms = new ArrayList();
    private ArrayList<Totals> totals = new ArrayList();
    private ArrayList<CompSumary> compMoney = new ArrayList();
    private ArrayList<Summary> trancheSummary = new ArrayList();
    private ArrayList<Summary> totalSummary = new ArrayList();
    private String trancheNumber;
    private String trancheDateRange;
    private String fromDate;
    private String toDate;
    private String date;
    private Boolean trancheBand;
    private Boolean trancheTitle;
    public static class HRooms {


        /**
         * @return the aO1
         */
        public String getaO1() {
            return aO1;
        }

        /**
         * @param aO1 the aO1 to set
         */
        public void setaO1(String aO1) {
            this.aO1 = aO1;
        }

        /**
         * @return the aO2
         */
        public String getaO2() {
            return aO2;
        }

        /**
         * @param aO2 the aO2 to set
         */
        public void setaO2(String aO2) {
            this.aO2 = aO2;
        }

        /**
         * @return the aO3
         */
        public String getaO3() {
            return aO3;
        }

        /**
         * @param aO3 the aO3 to set
         */
        public void setaO3(String aO3) {
            this.aO3 = aO3;
        }

        /**
         * @return the aO4
         */
        public String getaO4() {
            return aO4;
        }

        /**
         * @param aO4 the aO4 to set
         */
        public void setaO4(String aO4) {
            this.aO4 = aO4;
        }

        /**
         * @return the aO5
         */
        public String getaO5() {
            return aO5;
        }

        /**
         * @param aO5 the aO5 to set
         */
        public void setaO5(String aO5) {
            this.aO5 = aO5;
        }

        /**
         * @return the aO6
         */
        public String getaO6() {
            return aO6;
        }

        /**
         * @param aO6 the aO6 to set
         */
        public void setaO6(String aO6) {
            this.aO6 = aO6;
        }

        /**
         * @return the aO7
         */
        public String getaO7() {
            return aO7;
        }

        /**
         * @param aO7 the aO7 to set
         */
        public void setaO7(String aO7) {
            this.aO7 = aO7;
        }

        /**
         * @return the aO8
         */
        public String getaO8() {
            return aO8;
        }

        /**
         * @param aO8 the aO8 to set
         */
        public void setaO8(String aO8) {
            this.aO8 = aO8;
        }

        /**
         * @return the aO9
         */
        public String getaO9() {
            return aO9;
        }

        /**
         * @param aO9 the aO9 to set
         */
        public void setaO9(String aO9) {
            this.aO9 = aO9;
        }

        /**
         * @return the a1O
         */
        public String getA1O() {
            return a1O;
        }

        /**
         * @param a1O the a1O to set
         */
        public void setA1O(String a1O) {
            this.a1O = a1O;
        }

        /**
         * @return the a11
         */
        public String getA11() {
            return a11;
        }

        /**
         * @param a11 the a11 to set
         */
        public void setA11(String a11) {
            this.a11 = a11;
        }

        /**
         * @return the bO1
         */
        public String getbO1() {
            return bO1;
        }

        /**
         * @param bO1 the bO1 to set
         */
        public void setbO1(String bO1) {
            this.bO1 = bO1;
        }

        /**
         * @return the bO2
         */
        public String getbO2() {
            return bO2;
        }

        /**
         * @param bO2 the bO2 to set
         */
        public void setbO2(String bO2) {
            this.bO2 = bO2;
        }

        /**
         * @return the bO3
         */
        public String getbO3() {
            return bO3;
        }

        /**
         * @param bO3 the bO3 to set
         */
        public void setbO3(String bO3) {
            this.bO3 = bO3;
        }

        /**
         * @return the bO4
         */
        public String getbO4() {
            return bO4;
        }

        /**
         * @param bO4 the bO4 to set
         */
        public void setbO4(String bO4) {
            this.bO4 = bO4;
        }
        private String aO1;
        private String aO2;
        private String aO3;
        private String aO4;
        private String aO5;
        private String aO6;
        private String aO7;
        private String aO8;
        private String aO9;
        private String a1O;
        private String a11;
        private String bO1;
        private String bO2;
        private String bO3;
        private String bO4;
    }
    public static class factureReport{

        /**
         * @return the tab
         */
        public JRBeanCollectionDataSource getTab() {
            return new JRBeanCollectionDataSource(tab);
        }

        /**
         * @param tab the tab to set
         */
        public void setTab(semina e) {
            fre += e.getCount()*e.getDays()*e.getPrice();
            this.tab.add(e);
        }

        /**
         * @return the name
         */
        public String getName() {
            return name;
        }

        /**
         * @param name the name to set
         */
        public void setName(String name) {
            this.name = name;
        }

        /**
         * @return the nif
         */
        public String getNif() {
            return nif;
        }

        /**
         * @param nif the nif to set
         */
        public void setNif(String nif) {
            this.nif = nif;
        }

        /**
         * @return the resi
         */
        public String getResi() {
            return resi;
        }

        /**
         * @param resi the resi to set
         */
        public void setResi(String resi) {
            this.resi = resi;
        }

        /**
         * @return the fact
         */
        public JRBeanCollectionDataSource getFact() {
            return new JRBeanCollectionDataSource(fact);
        }

        /**
         * @param fact the fact to set
         */
        public void setFact(factureItems ct) {
            fre += ct.getDays()*ct.getPrice();
            this.fact.add(ct);
        }

        /**
         * @return the french
         */
        public String getMont(){
            return "Montant : "+new Database().French_numbers(fre.toString())+mont;
        }
        private String mont;
        public void setMont(String m){
            if (m.equals("true")) {
                mont = " CASH";
            } else {
                mont = "";
            }
        }
        public String getFrench() {
            Dictionary d = new Dictionary();
            String rt = "Arthuros";
            try {
                rt = d.Frech(fre.toString());
            } catch (Exception e) {
                e.printStackTrace();
            }
            return rt.toLowerCase() + "francs burundais";
        }

        /**
         * @param french the french to set
         */
        public void setFrench(String french) {
            this.french = french;
        }

        /**
         * @return the factN
         */
        public String getFactN() {
            return factN;
        }

        /**
         * @param factN the factN to set
         */
        public void setFactN(String factN) {
            this.factN = factN;
        }

        /**
         * @return the server
         */
        public String getServer() {
            return server;
        }

        /**
         * @param server the server to set
         */
        public void setServer(String server) {
            this.server = server;
        }

        /**
         * @return the service
         */
        public String getService() {
            return service;
        }

        /**
         * @param service the service to set
         */
        public void setService(String service) {
            this.service = service;
        }

        /**
         * @return the dateTime
         */
        public String getDateTime() {
            return dateTime;
        }

        /**
         * @param dateTime the dateTime to set
         */
        public void setDateTime(String dateTime) {
            this.dateTime = dateTime;
        }
        Integer fre =0;
        private String name;
        private String nif;
        private String resi;
        private ArrayList<factureItems> fact = new ArrayList();
        private ArrayList<semina> tab =new ArrayList();
        private String french;
        private String factN;
        private String server;
        private String service;
        private String dateTime;
    }
    public static class seminaReport{

        /**
         * @return the name
         */
        public String getName() {
            return name;
        }

        /**
         * @param name the name to set
         */
        public void setName(String name) {
            this.name = name;
        }

        /**
         * @return the date
         */
        public String getDate() {
            return date;
        }

        /**
         * @param date the date to set
         */
        public void setDate(String date) {
            this.date = date;
        }

        /**
         * @return the fact
         */
        public JRBeanCollectionDataSource getFact() {
            return new JRBeanCollectionDataSource(fact);
        }

        /**
         * @param fact the fact to set
         */
        public void setFact(semina f) {
            this.fact.add(f);
        }
        private String name;
        private String date;
        private ArrayList<semina> fact = new ArrayList();
    }
    public static class semina{
        private Integer count;
        private Integer days;
        private Integer price;
        private String name;

        /**
         * @return the count
         */
        public Integer getCount() {
            return count;
        }

        /**
         * @param count the count to set
         */
        public void setCount(Integer count) {
            this.count = count;
        }

        /**
         * @return the days
         */
        public Integer getDays() {
            return days;
        }

        /**
         * @param days the days to set
         */
        public void setDays(Integer days) {
            this.days = days;
        }

        /**
         * @return the price
         */
        public Integer getPrice() {
            return price;
        }

        /**
         * @param price the price to set
         */
        public void setPrice(Integer price) {
            this.price = price;
        }

        /**
         * @return the name
         */
        public String getName() {
            return name;
        }

        /**
         * @param name the name to set
         */
        public void setName(String name) {
            this.name = name;
        }
    }
    public static class ORooms {

        /**
         * @return the name
         */
        public String getName() {
            return name;
        }

        /**
         * @param name the name to set
         */
        public void setName(String name) {
            this.name = name;
        }

        /**
         * @return the compprice
         */
        public Integer getCompprice() {
            return compprice;
        }

        /**
         * @param compprice the compprice to set
         */
        public void setCompprice(Integer compprice) {
            this.compprice = compprice;
        }

        /**
         * @return the othersprice
         */
        public Integer getOthersprice() {
            return othersprice;
        }

        /**
         * @param othersprice the othersprice to set
         */
        public void setOthersprice(Integer othersprice) {
            this.othersprice = othersprice;
        }
        private String name;
        private String comp;
        private Integer compprice;
        private Integer clients;
        private Integer othersprice;

        /**
         * @return the clients
         */
        public Integer getClients() {
            return clients;
        }

        /**
         * @param clients the clients to set
         */
        public void setClients(Integer clients) {
            this.clients = clients;
        }

        /**
         * @return the comp
         */
        public String getComp() {
            return comp;
        }

        /**
         * @param comp the comp to set
         */
        public void setComp(String comp) {
            this.comp = comp;
        }
    }
    public static class Totals {

        /**
         * @return the title
         */
        public String getTitle() {
            return title;
        }

        /**
         * @param title the title to set
         */
        public void setTitle(String title) {
            this.title = title;
        }

        /**
         * @return the money
         */
        public String getMoney() {
            return money;
        }

        /**
         * @param money the money to set
         */
        public void setMoney(String money) {
            this.money = money;
        }
        private String title;
        private String money;
    }
    public static class CompSumary {

        /**
         * @return the s1
         */
        public String getS1() {
            return s1;
        }

        /**
         * @param s1 the s1 to set
         */
        public void setS1(String s1) {
            this.s1 = s1;
        }

        /**
         * @return the s2
         */
        public String getS2() {
            return s2;
        }

        /**
         * @param s2 the s2 to set
         */
        public void setS2(String s2) {
            this.s2 = s2;
        }

        /**
         * @return the s3
         */
        public String getS3() {
            return s3;
        }

        /**
         * @param s3 the s3 to set
         */
        public void setS3(String s3) {
            this.s3 = s3;
        }
        private String s1 ="";
        private String s2="";
        private String s3="";

    }
    public static class PoliceFields{

        /**
         * @return the date
         */
        public String getDate() {
            return date;
        }

        /**
         * @param date the date to set
         */
        public void setDate(String date) {
            this.date = date;
        }

        /**
         * @return the details
         */
        public JRBeanCollectionDataSource getDetails() {
            return new JRBeanCollectionDataSource(details);
        }
        public ArrayList<Police> GetDetails(){
            return details;
        }
        /**
         * @param details the details to set
         */
        public void setDetails(Police pl) {
            this.details.add(pl);
        }
        private String date;
        private ArrayList<Police> details = new ArrayList();
        
    }
    public static class Police{
        private String date;
        private String name;
        private String age;
        private String sex;
        private String id;
        private String nat;
        private String fun;
        private String provn;
        private String room;

        /**
         * @return the date
         */
        public String getDate() {
            return date;
        }

        /**
         * @param date the date to set
         */
        public void setDate(String date) {
            this.date = date;
        }

        /**
         * @return the name
         */
        public String getName() {
            return name;
        }

        /**
         * @param name the name to set
         */
        public void setName(String name) {
            this.name = name;
        }

        /**
         * @return the age
         */
        public String getAge() {
            return age;
        }

        /**
         * @param age the age to set
         */
        public void setAge(String age) {
            this.age = age;
        }

        /**
         * @return the sex
         */
        public String getSex() {
            return sex;
        }

        /**
         * @param sex the sex to set
         */
        public void setSex(String sex) {
            this.sex = sex;
        }

        /**
         * @return the id
         */
        public String getId() {
            return id;
        }

        /**
         * @param id the id to set
         */
        public void setId(String id) {
            this.id = id;
        }

        /**
         * @return the nat
         */
        public String getNat() {
            return nat;
        }

        /**
         * @param nat the nat to set
         */
        public void setNat(String nat) {
            this.nat = nat;
        }

        /**
         * @return the fun
         */
        public String getFun() {
            return fun;
        }

        /**
         * @param fun the fun to set
         */
        public void setFun(String fun) {
            this.fun = fun;
        }

        /**
         * @return the provn
         */
        public String getProvn() {
            return provn;
        }

        /**
         * @param provn the provn to set
         */
        public void setProvn(String provn) {
            this.provn = provn;
        }

        /**
         * @return the room
         */
        public String getRoom() {
            return room;
        }

        /**
         * @param room the room to set
         */
        public void setRoom(String room) {
            this.room = room;
        }
        
        
    
    }
    public static class Facture{

        /**
         * @return the server
         */
        public String getServer() {
            return server;
        }

        /**
         * @param server the server to set
         */
        public void setServer(String server) {
            this.server = server;
        }

        /**
         * @return the service
         */
        public String getService() {
            return service;
        }

        /**
         * @param service the service to set
         */
        public void setService(String service) {
            this.service = service;
        }

        /**
         * @return the factN
         */
        public String getFactN() {
            return factN;
        }

        /**
         * @param factN the factN to set
         */
        public void setFactN(String factN) {
            this.factN = factN+"-"+LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy"));
        }

        /**
         * @return the name
         */
        public String getName() {
            return name;
        }

        /**
         * @param name the name to set
         */
        public void setName(String name) {
            this.name = name;
        }

        /**
         * @return the nif
         */
        public String getNif() {
            return nif;
        }

        /**
         * @param nif the nif to set
         */
        public void setNif(String nif) {
            this.nif = nif;
        }

        /**
         * @return the resi
         */
        public String getResi() {
            return resi;
        }

        /**
         * @param resi the resi to set
         */
        /**
         * @return the frech
         */
        public String getMont(){
            return "Montant : "+new Database().French_numbers(fre.toString())+mont;
        }
        private String mont;
        public void setMont(String m){
            if (m.equals("true")) {
                mont = " CASH";
            } else {
                mont = "";
            }
        }
        public String getFrench() {
            Dictionary d = new Dictionary();
            String rt = "Arthuros";
            try {
                rt = d.Frech(fre.toString());
            } catch (Exception e) {
                e.printStackTrace();
            }
            return rt.toLowerCase() + "francs burundais";
        }
        public void setResi(String r){
            resi = r;
        }
        /**
         * @param frech the frech to set
         */

        /**
         * @return the fact
         */
        public ArrayList<Room_record> GetFact() {
            return fact;
        }
        public JRBeanCollectionDataSource getFact() {
            return new JRBeanCollectionDataSource(fact);
        }
        /**
         * @param fact the fact to set
         */
        public void setFact(Room_record fact) {
            fre += fact.getTotal_cost();
            this.fact.add(fact);
        }
        private Integer fre =0;
        private String name;
        private String dateTime;
        public String getDateTime(){
            return dateTime;
        }
        public void setDateTime(String d){
            dateTime = d;
        }
        private String nif;
        private String server;
        private String service;
        private String resi;
        private ArrayList<Room_record> fact = new ArrayList();
        private String factN;
    }
    public static class DepenceGlobal{

        /**
         * @return the fromDate
         */
        public String getFromDate() {
            return fromDate;
        }

        /**
         * @param fromDate the fromDate to set
         */
        public void setFromDate(String fromDate) {
            this.fromDate = fromDate;
        }

        /**
         * @return the toDate
         */
        public String getToDate() {
            return toDate;
        }

        /**
         * @param toDate the toDate to set
         */
        public void setToDate(String toDate) {
            this.toDate = toDate;
        }

        /**
         * @return the type
         */
        public String getType() {
            return type;
        }

        /**
         * @param type the type to set
         */
        public void setType(String type) {
            this.type = type;
        }

        /**
         * @return the ciz
         */
        public String getCiz() {
            return ciz;
        }

        /**
         * @param ciz the ciz to set
         */
        public void setCiz(String ciz) {
            this.ciz = ciz;
        }

        /**
         * @return the monthSummary
         */
        public JRBeanCollectionDataSource getMonthSummary() {
            return new JRBeanCollectionDataSource (monthSummary);
        }

        /**
         * @param monthSummary the monthSummary to set
         */
        public void setMonthSummary(ArrayList<TrancheGlobal.Summary> e) {
            this.monthSummary = e ;
        }
        public void add(TrancheGlobal.Summary e){
            this.monthSummary.add(e);
        }
        public void addAll(ArrayList<TrancheGlobal.Summary> e){
            this.monthSummary.addAll(e);
        }
        /**
         * @return the month
         */
        public String getMonth() {
            return month;
        }

        /**
         * @param month the month to set
         */
        public void setMonth(String month) {
            this.month = month;
        }
        private String fromDate;
        private String toDate;
        private String type;
        private String ciz;
        private ArrayList<TrancheGlobal.Summary> monthSummary = new ArrayList();
        private String month;
    }
    public static class Summary {

        /**
         * @return the date
         */
        public String getDate() {
            return date;
        }

        /**
         * @param date the date to set
         */
        public void setDate(String date) {
            this.date = date;
        }

        /**
         * @return the t1
         */
        public String getT1() {
            return t1;
        }

        /**
         * @param t1 the t1 to set
         */
        public void setT1(String t1) {
            this.t1 = t1;
        }

        /**
         * @return the m1
         */
        public String getM1() {
            return m1;
        }

        /**
         * @param m1 the m1 to set
         */
        public void setM1(String m1) {
            this.m1 = m1;
        }

        /**
         * @return the c1
         */
        public String getC1() {
            return c1;
        }

        /**
         * @param c1 the c1 to set
         */
        public void setC1(String c1) {
            this.c1 = c1;
        }

        /**
         * @return the cm
         */
        public Integer getCm() {
            return cm;
        }

        /**
         * @param cm the cm to set
         */
        public void setCm(Integer cm) {
            this.cm = cm;
        }
        private String t1;
        private String m1;
        private String c1;
        private Integer cm;
        private String date;
    }
    /**
     * @return the trancheBand
     */
    public Boolean getTrancheBand() {
        return trancheBand;
    }

    /**
     * @param trancheBand the trancheBand to set
     */
    public void setTrancheBand(Boolean trancheBand) {
        this.trancheBand = trancheBand;
    }

    /**
     * @return the date
     */
    public String getDate() {
        return date;
    }

    /**
     * @param date the date to set
     */
    public void setDate(String date) {
        this.date = date;
    }

    /**
     * @return the trancheTitle
     */
    public Boolean getTrancheTitle() {
        return trancheTitle;
    }

    /**
     * @param trancheTitle the trancheTitle to set
     */
    public void setTrancheTitle(Boolean trancheTitle) {
        this.trancheTitle = trancheTitle;
    }

    public static class factureItems {

        /**
         * @return the room
         */
        public String getRoom() {
            return room;
        }

        /**
         * @param room the room to set
         */
        public void setRoom(String room) {
            this.room = room;
        }

        /**
         * @return the name
         */
        public String getName() {
            return name;
        }

        /**
         * @param name the name to set
         */
        public void setName(String name) {
            this.name = name;
        }

        /**
         * @return the datein
         */
        public String getDatein() {
            return datein;
        }

        /**
         * @param datein the datein to set
         */
        public void setDatein(String datein) {
            this.datein = datein;
        }

        /**
         * @return the dateout
         */
        public String getDateout() {
            return dateout;
        }

        /**
         * @param dateout the dateout to set
         */
        public void setDateout(String dateout) {
            this.dateout = dateout;
        }

        /**
         * @return the days
         */
        public Integer getDays() {
            return days;
        }

        /**
         * @param days the days to set
         */
        public void setDays(Integer days) {
            this.days = days;
        }

        /**
         * @return the price
         */
        public Integer getPrice() {
            return price;
        }

        /**
         * @param price the price to set
         */
        public void setPrice(Integer price) {
            this.price = price;
        }
        private String room;
        private String name;
        private String datein;
        private String dateout;
        private Integer days;
        private Integer price;
    }
    
}
