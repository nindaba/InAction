package jc;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;

public class clients_companies implements Initializable {
  @FXML
  private Label name;
  
  Boolean company;
  
  String compid;
  
  String clientid;
  
  Base base;
  
  public void initialize(URL url, ResourceBundle rb) {}
  
  public void init(Base bs, String i, String n, boolean b) {
    this.base = bs;
    this.company = Boolean.valueOf(b);
    this.name.setText(n);
    if (b) {
      this.compid = i;
    } else {
      this.clientid = i;
    } 
  }
  
  @FXML
  private void getNext(MouseEvent event) {
    if (this.company.booleanValue()) {
      this.base.getClients(this.compid);
    } else {
      this.base.confBooked(this.clientid);
    } 
  }
}
