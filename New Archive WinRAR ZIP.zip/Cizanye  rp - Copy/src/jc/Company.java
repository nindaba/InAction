package jc;

import com.jfoenix.controls.JFXCheckBox;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIconView;
import java.io.IOException;
import java.net.URL;
import java.util.Random;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;

public class Company implements Initializable {
  @FXML
  private Label name;
  
  @FXML
  private FontAwesomeIconView icon;
  
  @FXML
  private Label payed;
  
  @FXML
  private Label un_payed;
  
  @FXML
  private Label total;
  
  @FXML
  private JFXCheckBox select;
  
  Base base;
  
  String compid;
  
  public void initialize(URL url, ResourceBundle rb) {}
  
  public void init(Base bs, String c, String n, String p, String u, String t) {
    this.base = bs;
    this.name.setText(n);
    this.payed.setText(p);
    this.un_payed.setText(u);
    this.select.setVisible(!u.equals("0 FBU"));
    this.total.setText(t);
    this.compid = c;
    String[] color = { "-fx-fill: #008ca4", "-fx-fill:  #e4b426", "-fx-fill:  #00a735", "-fx-fill:  #ea5498", "-fx-fill:  #e85353", "-fx-fill:  #e56c52", "-fx-fill:  #e28a51" };
    this.icon.setStyle(color[(new Random()).nextInt(7)]);
  }
  
  @FXML
  private void getCompany(MouseEvent event) {
    try {
      FXMLLoader loader = new FXMLLoader(getClass().getResource("/fx/Company_header.fxml"));
      Parent root = loader.<Parent>load();
      Company_header c_h = loader.<Company_header>getController();
      String[] bt = new String[3];
      bt[0] = this.payed.getText();
      bt[1] = this.un_payed.getText();
      bt[2] = this.total.getText();
      c_h.init(this.name.getText(), this.payed.getText(), this.un_payed.getText(), this.total.getText());
      this.data.getCompany(this.base, this.compid, root, bt);
    } catch (IOException ex) {
      ex.printStackTrace();
    } 
  }
  
  Database data = new Database();
  
  @FXML
  private void add_to_selected_client(ActionEvent event) {
    if (this.select.isSelected())
      this.base.pay_selected.add("compid = " + this.compid); 
  }
}
