package jc;

import java.util.HashMap;
import java.util.Map;

public class Dictionary {
  Map<String, String> map = new HashMap<>();
  
  String s;
  
  public String Frech(String c) {
    this.map.put("00", "");
    this.map.put("0", "");
    this.map.put("1", "UN");
    this.map.put("2", "DUEX");
    this.map.put("3", "TROIS");
    this.map.put("4", "QUATRE");
    this.map.put("5", "CINQ");
    this.map.put("6", "SIX");
    this.map.put("7", "SEPT");
    this.map.put("8", "HUIT");
    this.map.put("9", "NEUF");
    this.map.put("11", "ONZE");
    this.map.put("12", "DOUZE");
    this.map.put("13", "TREIZE");
    this.map.put("14", "QUATORZE");
    this.map.put("15", "QUINZE");
    this.map.put("16", "SEIZE");
    this.map.put("17", "DIX-SEPT");
    this.map.put("18", "DIX-HUIT");
    this.map.put("19", "DIX-NEUF");
    this.map.put("20", "VINGT");
    this.map.put("30", "TRENTE");
    this.map.put("40", "QUARANTE");
    this.map.put("50", "CINQUANTE");
    this.map.put("60", "SOIXANTE");
    this.map.put("70", "SOIXANTE-DIX");
    this.map.put("80", "QUATRE-VINGTS");
    this.map.put("10", "DIX");
    this.map.put("90", "NONENT");
    this.s = c;
    this.numb = div(this.s.length(), "");
    check();
    int n = this.numb.length - 1;
    String number = "";
    for (int i = 0; i < this.numb.length; i++) {
      number = number + this.numb[i] + " " + this.p[n] + " ";
      n--;
    } 
    return number;
  }
  
  String[] numb = new String[4];
  
  String[] p = new String[] { "", "MILLE", "MILLION", "MILLIARD" };
  
  public String[] div(int l, String d) {
    String[] numb = new String[4];
    int b = l;
    int i = 0;
    while (b > 0) {
      if (b - 3 >= 0) {
        numb[i] = this.s.substring(b - 3, b);
      } else if (b - 2 >= 0) {
        numb[i] = this.s.substring(b - 2, b);
      } else if (b - 1 >= 0) {
        numb[i] = this.s.substring(b - 1, b);
      } 
      b -= 3;
      i++;
    } 
    return numb;
  }
  
  public void check() {
    String temp = "";
    String[] tp = new String[4];
    int c = 0;
    for (int m = 3; m >= 0; m--) {
      String b = this.numb[m];
      if (b != null) {
        tp[c] = getName(b);
        c++;
      } 
      temp = "";
    } 
    String[] f = new String[c];
    for (int o = 0; o < c; o++)
      f[o] = tp[o]; 
    this.numb = f;
  }
  
  public String getName(String b) {
    String temp = "";
    switch (b.length()) {
      case 3:
        if (!"000".equals(b.substring(0, 3))) {
          if (!"1".equals(b.substring(0, 1)) && !"0".equals(b.substring(0, 1))) {
            temp = (String)this.map.get(b.substring(0, 1)) + " CENT";
          } else if (!"0".equals(b.substring(0, 1))) {
            temp = "CENT";
          } 
          if (this.map.get(b.substring(1, 3)) != null) {
            temp = temp + " " + (String)this.map.get(b.substring(1, 3));
            break;
          } 
          if (!"0".equals(b.substring(1, 2))) {
            temp = temp + " " + (String)this.map.get(b.substring(1, 2) + "0") + "-";
            temp = temp + (String)this.map.get(b.substring(2, 3));
            break;
          } 
          temp = temp + " " + (String)this.map.get(b.substring(1, 2) + "0");
          temp = temp + (String)this.map.get(b.substring(2, 3));
        } 
        break;
      case 2:
        if (this.map.get(b.substring(0, 2)) != null) {
          temp = temp + " " + (String)this.map.get(b.substring(0, 2));
          break;
        } 
        temp = temp + " " + (String)this.map.get(b.substring(0, 1) + "0") + "-";
        temp = temp + (String)this.map.get(b.substring(1, 2));
        break;
      case 1:
        temp = temp + " " + (String)this.map.get(b.substring(0, 1));
        break;
    } 
    return temp;
  }
}
