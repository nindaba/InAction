package jc;

import com.jfoenix.controls.JFXCheckBox;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.shape.Line;

public class Client_records implements Initializable {
  @FXML
  private Label price;
  
  @FXML
  private Label from;
  
  @FXML
  private Label days;
  
  @FXML
  private Label total;
  
  @FXML
  private Label rroom_number;
  
  @FXML
  private Line line;
  
  @FXML
  private JFXCheckBox select;
  
  Base base;
  
  public void initialize(URL url, ResourceBundle rb) {}
  
  Database data = new Database();
  
  String bk;
  
  public void init(Room_record rc, Base b) {
    this.bk = rc.getBookid();
    this.base = b;
    this.price.setText(this.data.French_numbers(rc.getPrice().toString()));
    this.from.setText(rc.getDatein());
    this.days.setText(rc.getDays().toString());
    this.total.setText(this.data.French_numbers(rc.getTotal_cost().toString()));
    this.rroom_number.setText(rc.getRoom());
    if (rc.getPayed().equals("false")) {
      this.line.setStyle("-fx-stroke:#ff4848");
    } else {
      this.select.setVisible(false);
    } 
  }
  
  @FXML
  private void add_to_selected_client(ActionEvent event) {
    if (this.select.isSelected())
      this.base.pay_selected.add("bookid = " + this.bk); 
  }
}
