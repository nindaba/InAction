package jc;

import com.jfoenix.controls.JFXButton;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class Day_base implements Initializable {  
  Base base;
  
  LocalDate from;
  ArrayList<Parent> day = new ArrayList();
    @FXML
    private VBox Hiden_box;
    @FXML
    private JFXButton expand;
    @FXML
    private Label date;
    @FXML
    private JFXButton addr;
    @FXML
    private HBox shot_vbox;
    @FXML
    private GridPane GridPane;
  public void initialize(URL url, ResourceBundle rb) {}
  
  public void set(String h, String o, String p,String dtt, String t,ArrayList<Parent> d,String dt,ArrayList<Node> sht,ArrayList<Node> shd) {
      try {
          Label lb =new Label();
          lb.setStyle("-fx-text-fill:#bfc9bf");
          lb.setText("Hotel "+h);
          GridPane.add(lb, 0, 0);
          
          Label lb1 =new Label();
          lb1.setStyle("-fx-text-fill:#bfc9bf");
          lb1.setText("Autre "+o);
          GridPane.add(lb1, 0, 1);
          
          Label lb2 =new Label();
          lb2.setText("Cash "+dtt);
          lb2.setStyle("-fx-text-fill:#bfc9bf");
          GridPane.add(lb2, 0, 2);
          
          Label lb4 =new Label();
          lb4.setText("Dette "+p);
          lb4.setStyle("-fx-text-fill:#bfc9bf");
          GridPane.add(lb4, 0, 3);
          
          Label lb3 =new Label();
          lb3.setText("TOTAL "+t);
          lb3.setStyle("-fx-text-fill:#bfc9bf");
          GridPane.add(lb3, 0, 4);
          ORooms = shd;
          HRooms = sht;
          addr.setVisible(false);
          day = d;
          date.setText(dt);
          shot_vbox.getChildren().addAll(sht);
          FXMLLoader loader = null;
          if(shd.size()>0){
            loader = new FXMLLoader(getClass().getResource("/fx/show_others.fxml"));
            Parent root = loader.load();
            show_others cont = loader.getController();
            cont.setNum(shd.size(),this);
            shot_vbox.getChildren().add(root);
          }
          if(LocalDate.now().equals(LocalDate.parse(dt, DateTimeFormatter.ofPattern("dd/MM/yyyy"))))
              show_day();
      } catch (Exception ex) {
          ex.printStackTrace();
      }
  }
  
  @FXML
  private void Add_side_room(ActionEvent event) {
    this.base.add_side(this.from);
  }
  
  public void init(Base b, LocalDate f) {
    this.base = b;
    this.from = f;
  }
    @FXML
  public void show_day(){
     Hiden_box.getChildren().addAll(day);
     Node bs = Hiden_box.getChildren().get(0);
     Hiden_box.getChildren().remove(0);
     Hiden_box.getChildren().add(bs);
     expand.setVisible(false);
     addr.setVisible(true);
  }
ArrayList<Node> HRooms;
ArrayList<Node> ORooms;
Integer oth =0;
    public void show_Others() {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fx/show_others.fxml"));
        try {
            Parent root = loader.load();
            show_others cont = loader.getController();
            if(oth%2 == 0){
                shot_vbox.getChildren().clear();
                shot_vbox.getChildren().add(root);
                shot_vbox.getChildren().addAll(ORooms);
                cont.setNum(HRooms.size(),this);
            }
            else{
                shot_vbox.getChildren().clear();
                shot_vbox.getChildren().addAll(HRooms);
                shot_vbox.getChildren().add(root);   
                cont.setNum(ORooms.size(),this);
            }
            oth++;
        } catch (IOException iOException) {
            iOException.printStackTrace();
        }
    }
    public void addToGrid(Label lb,Integer Cl,Integer Rw){
        lb.setStyle("-fx-text-fill:#bfc9bf");
        GridPane.add(lb, Cl, Rw);
        
    }
    public void ReplaceToGrid(Label Ol,Label lb,Integer Cl,Integer Rw){
        GridPane.getChildren().remove(Ol);
        lb.setStyle("-fx-text-fill:#bfc9bf");
        GridPane.add(lb, Cl, Rw);
    }
}
