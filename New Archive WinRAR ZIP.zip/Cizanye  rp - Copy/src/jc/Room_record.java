package jc;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Room_record {

    /**
     * @return the nif
     */
    public String getNif() {
        return nif;
    }

    /**
     * @param nif the nif to set
     */
    public void setNif(String nif) {
        this.nif = nif;
    }

    /**
     * @return the res
     */
    public String getRes() {
        return res;
    }

    /**
     * @param res the res to set
     */
    public void setRes(String res) {
        this.res = res;
    }

    /**
     * @return the cash
     */
    public String getCash() {
        return cash;
    }
  private final String room;
  
  private final String name;
  private final String cash;
  private final String phone;
  
  private final String identity;
  
  private final String province;
  
  private final String company;
  
  private final Integer price;
  
  private final String roomid;
  
  private final String payed;
  private final Integer days;
  
  private final String bookid;
  
  private final String payer;
  
  private final String clientid;
  private final String CompFull;
  
  private final String Nationality;
  
  private final String Age;
  
  private final String Sex;
  
  private String datein;
  
  private String dateout;
  
  private String Udatein;
  private String nif;
  private String res;
  private String Udateout;
  private String compid;
  private final Integer total_cost;
  public String getCompid(){
      return compid;
  }
  Room_record(String bid, String rid, String n, String p, String i, String pr, String c, Integer pc, String pd, Integer d, String din, String dout, String rom, String id,String cf,String nat,String age,String sex,String ca,String com) {
    this.CompFull = cf;
    compid = com;
    this.Nationality = nat;
    this.Age =age;
    this.Sex =sex;
    this.clientid = id;
    this.room = rom;
    this.cash = ca;
    this.name = n;
    this.phone = p;
    this.identity = i;
    this.province = pr;
    this.company = c;
    this.price = pc;
    this.roomid = rid;
    this.payed = pd;
    this.days = d;
    this.bookid = bid;
    this.datein = din;
    this.dateout = dout;
    this.Udatein = din;
    this.Udateout = dout;
    this.total_cost = Integer.valueOf(this.days.intValue() * this.price.intValue());
    if (pd.equals("true")) {
      this.payer = "OUI";
    } else {
      this.payer = "NO";
    } 
  }
  
  public String getBookid() {
    return this.bookid;
  }
  
  public Integer getDays() {
    return this.days;
  }
  public String getRoom() {
    return this.room;
  }
  
  public String getName() {
    return this.name;
  }
  
  public String getPhone() {
    return this.phone;
  }
  
  public String getIdentity() {
    return this.identity;
  }
  public String getCompFull() {
    return this.CompFull;
  }
  
  public String getNationality() {
    return this.Nationality;
  }
  
  public String getAge() {
    return this.Age;
  }
  
  public String getSex() {
    return this.Sex;
  }
  
  public String getProvince() {
    return this.province;
  }
  
  public String getCompany() {
    return this.company;
  }
  
  public Integer getPrice() {
    return this.price;
  }
  
  public String getRoomid() {
    return this.roomid;
  }
  
  public String getPayed() {
    return this.payed;
  }
  
  public String getDatein() {
    return LocalDate.parse(this.datein).format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
  }
  
  public String getDateout() {
    return LocalDate.parse(this.dateout).format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
  }
  
  public Integer getTotal_cost() {
    return this.total_cost;
  }
  
  public String getPayer() {
    return this.payer;
  }
  
  public String getClientid() {
    return this.clientid;
  }
  
  public String getUdatein() {
    return this.Udatein;
  }
  
  public String getUdateout() {
    return this.Udateout;
  }
}
