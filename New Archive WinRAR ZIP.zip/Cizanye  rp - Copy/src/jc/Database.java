package jc;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

public class Database {
  Statement st;
  
  String Account_owner;
  
  Database() {
    try {
      Connection c = DriverManager.getConnection("jdbc:sqlite:data.db");
      this.st = c.createStatement();
    } catch (SQLException sQLException) {}
  }
  
  public String getPassword(String uname) {
    String Password = "Username_not_found";
    try {
      Boolean Pass_found = Boolean.valueOf(false);
      ResultSet User_names = this.st.executeQuery("select pass,name from login where uname ='" + uname + "'");
      while (User_names.next()) {
        Password = User_names.getString("pass");
        this.Account_owner = User_names.getString("name");
      } 
    } catch (SQLException ex) {
      Password = "Username_not_found";
    } 
    return Password;
  }
  
  public String turn_Online(String uname) {
    String name = new String();
    try {
      this.st.executeUpdate("update login set online ='true' where uname ='" + uname + "'");
    } catch (SQLException ex) {
      ex.printStackTrace();
    } 
    return this.Account_owner;
  }
  public Boolean Change_password(String name, String current_pass, String new_pass) {
    Boolean corect = Boolean.valueOf(false);
    try {
      ResultSet User_names = this.st.executeQuery("select pass from login where name ='" + name + "' and pass ='" + current_pass + "'");
      while (User_names.next())
        corect = Boolean.valueOf(true); 
      if (corect.booleanValue())
        this.st.executeUpdate("update login set pass ='" + new_pass + "' where name ='" + name + "' and pass ='" + current_pass + "'"); 
    } catch (SQLException ex) {
      ex.printStackTrace();
    } 
    return corect;
  }
  
  public Boolean Delete_password(String name, String current_pass, String new_pass) {
    Boolean corect = Boolean.valueOf(false);
    try {
      ResultSet User_names = this.st.executeQuery("select pass from login where name ='" + name + "' and pass ='" + current_pass + "'");
      while (User_names.next())
        corect = Boolean.valueOf(true); 
      if (corect.booleanValue())
        this.st.executeUpdate("delete from login where name ='" + name + "' and pass ='" + current_pass + "'"); 
    } catch (SQLException ex) {
      ex.printStackTrace();
    } 
    return corect;
  }
  
  public Boolean Create_account(String name,String service, String uname, String pass) {
    Boolean Exist = Boolean.valueOf(false);
    try {
      ResultSet User_names = this.st.executeQuery("select pass from login where uname ='" + uname + "'");
      while (User_names.next())
        Exist = Boolean.valueOf(true); 
      if (!Exist.booleanValue())
        this.st.executeUpdate("insert into login (name,uname,function,pass,online) values('" + name + "','" + uname + "','"+service+"','" + pass + "','false')"); 
    } catch (SQLException ex) {
      ex.printStackTrace();
    } 
    return Exist;
  }
  
  public Integer getDays(LocalDate from, LocalDate to) {
    Integer days = Integer.valueOf((int)ChronoUnit.DAYS.between(from, to));
    return days;
  }
  
  public String[] getAvailability(Base bs,LocalDate from, LocalDate to, String id) {
    String[] days = null;
    try {
      days = new String[4];
      days[0] = getDays(from, to).toString();
      days[1] = from.toString();
      ResultSet rows = this.st.executeQuery("select datein,dateout from booking"+bs.getHot()+" where dateout > '" + from + "'  and datein < '" + to + "' and roomid = " + id + " order by bookid");
      if (rows.next())
        if (LocalDate.parse(rows.getString("datein")).compareTo(from) >= 0) {
          days[0] = getDays(from, LocalDate.parse(rows.getString("datein"))).toString();
          days[1] = from.toString();
        } else if (to.compareTo(LocalDate.parse(rows.getString("dateout"))) >= 0) {
          days[0] = getDays(LocalDate.parse(rows.getString("dateout")), to).toString();
          days[1] = rows.getString("dateout");
        }  
      rows = this.st.executeQuery("select number,price from rooms"+bs.getHot()+" where roomid ='" + id + "'");
      while (rows.next()) {
        days[2] = rows.getString(1);
        days[3] = rows.getString(2);
      } 
    } catch (SQLException sQLException) {
      sQLException.printStackTrace();
    } 
    return days;
  }
  
  public VBox getCompanies(Base bs) {
    bs.clients_company_search.clear();
    VBox box = new VBox();
    try {
      ResultSet rows = this.st.executeQuery("select compid,name from company");
      while (rows.next()) {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fx/clients_companies.fxml"));
        Parent root = loader.<Parent>load();
        clients_companies cp = loader.<clients_companies>getController();
        cp.init(bs, rows.getString(1), rows.getString(2), true);
        bs.clients_company_search.put(rows.getString(2).toLowerCase(), root);
        box.getChildren().add(root);
      } 
    } catch (Exception e) {
      e.printStackTrace();
    } 
    return box;
  }
  
  public VBox getClients(Base bs, String id) {
    bs.clients_company_search.clear();
    VBox box = new VBox();
    try {
      ResultSet rows = this.st.executeQuery("select clientid,name from clients where compid =" + id + "");
      while (rows.next()) {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fx/clients_companies.fxml"));
        Parent root = loader.<Parent>load();
        clients_companies cp = loader.<clients_companies>getController();
        cp.init(bs, rows.getString(1), rows.getString(2), false);
        bs.clients_company_search.put(rows.getString(2).toLowerCase(), root);
        box.getChildren().add(root);
      } 
    } catch (Exception e) {
      e.printStackTrace();
    } 
    return box;
  }
  
  
  public Confirm_book getConf(Base bs,String compid, String clientid, String roomid, String date, String price, String nights) {
    Confirm_book book = null;
    try {
      String number = getNumber(bs,roomid);
      ResultSet rows = this.st.executeQuery("select cp.name,cl.name,cl.tel,cl.passnumber,cl.coming,cl.nationality as nat,cl.sex as sex,strftime('%Y','now')-strftime('%Y',age) as age, cp.fullname as cf from clients as cl,company as cp where cl.clientid = " + clientid + " and cp.compid = " + compid + "");
      while (rows.next())
        book = new Confirm_book(compid, clientid, roomid, rows.getString(1), rows.getString(2), rows.getString(3), rows.getString(4), rows.getString(5), number, price, date, LocalDate.parse(date).plusDays(Integer.parseInt(nights)).toString(), nights,rows.getString("nat"),rows.getString("age"),rows.getString("sex"),rows.getString("cf")); 
    } catch (Exception e) {
      e.printStackTrace();      
    } 
    return book;
  }
  
  public void book(Base bs,String clientid, String roomid, String compid, String date, String to, String price, String payed,String cash,String other) {
    try {
      this.st.executeUpdate("insert into booking"+bs.getHot()+" (clientid,datein,dateout,roomid,payed,price,compid,cash,otherprice) values(" + clientid + ",'" + date + "','" + to + "','" + roomid + "','" + payed + "'," + price + "," + compid + ",'" + cash + "'," + other + ")");
    } catch (SQLException ex) {
      ex.printStackTrace();
    } 
  }
  
  public Boolean chech_side(Base bs,String id, LocalDate from, LocalDate to) {
    Boolean valid = Boolean.valueOf(true);
    try {
      ResultSet rows = this.st.executeQuery("select bookid from booking"+bs.getHot()+" where dateout > '" + from + "'  and datein < '" + to + "' and roomid = '" + id + "'");
      if (rows.next())
        valid = Boolean.valueOf(false); 
    } catch (SQLException sQLException) {
      sQLException.printStackTrace();
    } 
    return valid;
  }
  
  public String getNumber(Base bs,String roomid) {
    String number = roomid;
    try {
      ResultSet rows = this.st.executeQuery("select number from rooms"+bs.getHot()+" where roomid in('" + roomid + "') ");
      while (rows.next())
        number = rows.getString(1); 
    } catch (Exception e) {
      e.printStackTrace();
    } 
    return number;
  }
  
  public String newCompany(String text,String sht,String nif,String res) {
    String compid = "no_id";
    try {
      ResultSet rows = this.st.executeQuery("select compid from company where name ='" + sht + "' or fullname ='" +text  + "'");
      while (rows.next())
        compid = rows.getString(1); 
      if (compid.equals("no_id")) {
        this.st.executeUpdate("insert into company(name,fullname,nif,resi) values('" + sht + "','" + text + "','" + nif + "','" + res + "')");
        rows = this.st.executeQuery("select last_insert_rowid()");
        while (rows.next())
          compid = rows.getString(1); 
        this.st.executeUpdate("insert into clients(compid,name,tel,passnumber,coming,nationality,sex,age) values('" + compid + "','------------------','----------------','------------------','------------------','-------------------','---',strftime('%Y-%m-%d','now'))");
      } 
    } catch (Exception e) {
      e.printStackTrace();
    } 
    return compid;
  }
  
  
  public String addClient(String compid, String name, String phone, String id, String prov,String nat,String sex,String age) {
    String clientd = "no_id";
    try {
      ResultSet rows = this.st.executeQuery("select clientid from clients where name ='" + name + "' and tel ='" + phone + "' and passnumber ='" + id + "' and coming='" + prov + "' and compid ='" + compid + "'");
      while (rows.next())
        clientd = rows.getString(1); 
      if (clientd.equals("no_id")) {
        this.st.executeUpdate("insert into clients(compid,name,tel,passnumber,coming,nationality,sex,age) values('" + compid + "','" + name + "','" + phone + "','" + id + "','" + prov + "','" + nat + "','" + sex + "','" + age + "')");
        rows = this.st.executeQuery("select last_insert_rowid()");
        while (rows.next())
          clientd = rows.getString(1); 
      } 
    } catch (Exception e) {
      e.printStackTrace();
    } 
    return clientd;
  }
  public void modifyClient(Base bs,String clientid,String compid, String name, String phone, String id, String prov,String nat,String sex,String age,String bookid) {
    try {
        String client="";
        ResultSet rows = this.st.executeQuery("select name from clients where clientid="+clientid+"");
        while (rows.next())
          client = rows.getString(1); 
        if (!client.startsWith("..") && !client.startsWith("--")) {
            this.st.executeUpdate("update clients set(compid,name,tel,passnumber,coming,nationality,sex,age) = ('" + compid + "','" + name + "','" + phone + "','" + id + "','" + prov + "','" + nat + "','" + sex + "','" + age + "') where clientid = " + clientid + "");
        } else {
            st.executeUpdate("insert into clients (compid,name,tel,passnumber,coming,nationality,sex,age) select compid,'" + name + "','" + phone + "','" + id + "','" + prov + "','" + nat + "','" + sex + "','" + age + "' from clients where clientid="+clientid+"");
            this.st.executeUpdate("update booking"+bs.getHot()+"  set clientid = (select last_insert_rowid()) where bookid="+bookid+"");
        }
    } catch (Exception e) {
      e.printStackTrace();
    } 
  }
  public void remove(Base bs,String ids) {
    try {
      this.st.executeUpdate("delete from booking"+bs.getHot()+" where bookid in(" + ids + ")");
    } catch (SQLException ex) {
      ex.printStackTrace();
    } 
  }
  
  public void setLocation(String id, String loc) {
    try {
      this.st.executeUpdate("update file_loc set loc='" + loc.replace("\\", "\\\\") + "' where id='" + id + "'");
    } catch (SQLException ex) {
      ex.printStackTrace();
    } 
  }
  
  public String getFact() {
    String n = null;
    try {
      ResultSet rows = this.st.executeQuery("select fact from facture");
      while (rows.next())
        n = rows.getString(1); 
      this.st.executeUpdate("update facture set fact =fact+1");
    } catch (SQLException ex) {
      ex.printStackTrace();
    } 
    return n;
  }
  
  public String getLocation(String id) {
    String location = null;
    try {
      ResultSet rows = this.st.executeQuery("select loc from file_loc where id='" + id + "'");
      while (rows.next())
        location = rows.getString(1); 
    } catch (SQLException ex) {
      ex.printStackTrace();
    } 
    return location;
  }
  
  public void room_tab_load(final Base base, final LocalDate from, final LocalDate to) {
    base.day_totals.clear();
    base.Day_array = new ArrayList<>();
    final VBox box = new VBox();
    final Integer dys = getDays(from, to);
    base.Selected_record.clear();
    base.Tabs.toFront();
    base.load.toFront();
    base.setDisable(Boolean.valueOf(true));
    Task load_days = new Task() {
        protected Object call() {
          Map<String, String> rooms = new HashMap<>();
          updateMessage("getting Ready");
          Day_record[] day = new Day_record[dys.intValue()];
          try {
            ResultSet rows = Database.this.st.executeQuery("select * from rooms"+base.getHot()+" order by number");
            while (rows.next())
              rooms.put(rows.getString("roomid"), rows.getString("number")); 
            ArrayList<Room_record> dat = new ArrayList<>();
            rows = Database.this.st.executeQuery("select * from rooms"+base.getHot()+" order by number");
            while (rows.next())
              dat.add(new Room_record("", rows.getString("roomid"), "", "", "", "", "", Integer.valueOf(0), "", Integer.valueOf(0), "", "", rows.getString("number"), "","","","","","","")); 
            Integer count = Integer.valueOf(0);
            Integer progress_count = Integer.valueOf(0);
            updateProgress(1L, 100L);
            updateMessage("1 of 2");
            for (int k = 0; k < dys.intValue(); k++) {
              day[k] = new Day_record(base, from.plusDays(k).toString(), from, to, (ArrayList<Room_record>)dat.clone());
              updateProgress(k, dys.intValue());             
            } 
            rows = Database.this.st.executeQuery("select count(bk.bookid) from booking"+base.getHot()+" as bk where dateout > '" + from + "'  and datein < '" + to + "'");
            while (rows.next())
              count = Integer.valueOf(rows.getInt(1)); 
            updateMessage("2 of 2");
            rows = Database.this.st.executeQuery("select bk.bookid as bkid,bk.roomid as id,cl.name as name,cl.tel as phone ,cl.passnumber as identity ,cl.coming as province,cp.name as company,bk.price as price,bk.dateout as dateout ,bk.datein as datein ,bk.payed as payed,julianday(bk.dateout)-julianday(bk.datein) ,cl.nationality as nat,cl.sex as sex,strftime('%Y','now')-strftime('%Y',age) as age, cp.fullname as cf ,bk.cash as cash,cp.nif as nif,cp.resi as res ,cl.clientid as clientid,julianday(datein)-julianday('"+from+"') as posi, julianday(dateout)-julianday('"+from+"') as endpos,cp.compid as compid from booking"+base.getHot()+" as bk,clients as cl,rooms"+base.getHot()+" as rm,company as cp  where bk.clientid = cl.clientid and bk.compid = cp.compid and dateout > '" + from + "'  and datein < '" + to + "'group by bk.bookid");
            while (rows.next()) {
              String room;
              Integer position, place = Integer.valueOf(0);
              updateProgress(progress_count.intValue(), count.intValue());
              Integer integer1 = progress_count, integer2 = progress_count = Integer.valueOf(progress_count.intValue() + 1);
              if (rooms.containsKey(rows.getString(2))) {
                room = rooms.get(rows.getString(2));
              } else {
                room = rows.getString(2);
              } 
              Room_record record = new Room_record(rows.getString(1), rows.getString(2), rows.getString(3), rows.getString(4), rows.getString(5), rows.getString(6), rows.getString(7), Integer.valueOf(rows.getInt(8)), rows.getString(11), Integer.valueOf(rows.getInt(12)), rows.getString("datein"), rows.getString("dateout"), room, rows.getString("clientid") ,rows.getString("cf"),rows.getString("nat"),rows.getString("age"),rows.getString("sex"),rows.getString("cash"),rows.getString("compid"));
              record.setNif(rows.getString("nif"));
              record.setRes(rows.getString("res"));
              if (LocalDate.parse(rows.getString("datein")).compareTo(from) <= 0) {
                position = Integer.valueOf(0);
              } else {
                position = rows.getInt("posi");
              } 
              while (position.intValue() < dys && place.intValue() < rows.getInt(12) && position < rows.getInt("endpos")) {
                day[position.intValue()].add_room(record);
                Integer integer3 = position, integer4 = position = Integer.valueOf(position.intValue() + 1);
                integer3 = place;
                integer4 = place = Integer.valueOf(place.intValue() + 1);
              } 
            } 
            for (Day_record d : day){
                try {
                    box.getChildren().add(d.getDay());                    
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            st.close();
            updateProgress(progress_count.intValue(), count.intValue());
            updateMessage("Fin");
          } catch (Exception _GEN_UCE_NAME_1) {
            _GEN_UCE_NAME_1.printStackTrace();
          } 
          Platform.runLater(new Runnable() {
                public void run() {
                  base.room_tab_box.getChildren().clear();
                  base.room_tab_box.getChildren().add(box);
                  base.setDisable(Boolean.valueOf(false));
                  base.Tabs.toFront();
                }
              });
          return Boolean.valueOf(true);
        }
      };
    base.parts.textProperty().unbind();
    base.parts.textProperty().bind(load_days.messageProperty());
    base.load_show.progressProperty().unbind();
    base.load_show.progressProperty().bind(load_days.progressProperty());
    TabThread = new Thread(load_days);
    TabThread.start();
  }
  
  public void client_tab_load(final Base base, final LocalDate from, final LocalDate tto) {
    base.pay_selected.clear();
    base.client_position = Integer.valueOf(0);
    base.clients_company_report_search[0].clear();
    base.Comp_pay.clear();
    base.Tabs.toFront();
    LocalDate to = tto.plusDays(1);
    base.load.toFront();
    base.setDisable(Boolean.valueOf(true));
    final VBox vbox = new VBox();
    final ArrayList<HBox> hbox = new ArrayList<>();
    Task load_days = new Task() {
        protected Object call() {
          Integer pr = Integer.valueOf(0);
          Integer up = Integer.valueOf(0);
          Integer tl = Integer.valueOf(0);
          Map<String, Company_holder> Companies = new HashMap<>();
          updateMessage("1 of 2");
          try {            
            ResultSet rows = Database.this.st.executeQuery("select bk.compid,cp.name as company,bk.price as price,bk.payed as payed ,bk.dateout as t,bk.datein as f from booking"+base.getHot()+" as bk,company as cp  where  bk.compid = cp.compid and dateout > '" + from + "'  and datein < '" + to + "'group by bk.bookid");
            while (rows.next()) {
              Integer p, u, Custom_days = Database.this.getDays(LocalDate.parse(rows.getString("f")), LocalDate.parse(rows.getString("t")));
              String first = rows.getString(1);
              String sec = rows.getString(2);
              Integer Left_days = Database.this.getDays(from, LocalDate.parse(rows.getString("f")));
              Integer Right_days = Database.this.getDays(LocalDate.parse(rows.getString("t")), to);
              if (Left_days.intValue() < 0)
                Custom_days = Integer.valueOf(Custom_days.intValue() + Left_days.intValue()); 
              if (Right_days.intValue() < 0)
                Custom_days = Integer.valueOf(Custom_days.intValue() + Right_days.intValue()); 
              String comp = rows.getString(2);
              if (rows.getString("payed").equals("true")) {
                p = Integer.valueOf(rows.getInt(3) * Custom_days.intValue());
                u = Integer.valueOf(0);
              } else {
                u = Integer.valueOf(rows.getInt(3) * Custom_days.intValue());
                p = Integer.valueOf(0);
              } 
              Integer t = Integer.valueOf(p.intValue() + u.intValue());
              pr = Integer.valueOf(pr.intValue() + p.intValue());
              up = Integer.valueOf(up.intValue() + u.intValue());
              tl = Integer.valueOf(tl.intValue() + t.intValue());
              if (!Companies.containsKey(comp))
                Companies.put(comp, new Company_holder(rows.getString(2))); 
              ((Company_holder)Companies.get(comp)).init(base, first, sec, p, u, t);
            } 
            updateProgress(2L, 3L);
            updateMessage("1 of 2");
            hbox.add(new HBox());
            Integer Three = Integer.valueOf(0);
            String keys = "";
            base.firstJr.clear();
            for (Map.Entry<String, Company_holder> entrySet : Companies.entrySet()) {
              String key = entrySet.getKey();
              keys = keys + key;
              Company_holder value = entrySet.getValue();
              base.firstJr.add(value.addJrList());
              Parent r = value.getCompany();
              ((HBox)hbox.get(hbox.size() - 1)).getChildren().add(r);
              Integer integer1 = Three, integer2 = Three = Integer.valueOf(Three.intValue() + 1);
              if (Three.intValue() == 3) {
                vbox.getChildren().add(hbox.get(hbox.size() - 1));
                base.clients_company_report_search[0].put(keys.toLowerCase(), hbox.get(hbox.size() - 1));
                hbox.add(new HBox());
                Three = Integer.valueOf(0);
                keys = "";
              } 
            } 
            if (Three.intValue() != 0) {
              vbox.getChildren().add(hbox.get(hbox.size() - 1));
              base.clients_company_report_search[0].put(keys.toLowerCase(), hbox.get(hbox.size() - 1));
            } 
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fx/Companies_base.fxml"));
            Parent root = loader.<Parent>load();
            Companies_base c_b = loader.<Companies_base>getController();
            String[] bt = new String[3];
            bt[0] = Database.this.French_numbers(pr.toString());
            bt[1] = Database.this.French_numbers(up.toString());
            bt[2] = Database.this.French_numbers(tl.toString());
            base.bottom.add(0, bt);
            c_b.init(bt[0], bt[1], bt[2]);
            vbox.getChildren().add(root);
            base.clients_company_report_search[0].put("nizi6.".toLowerCase(), root);
            updateMessage("Fin");
            st.close();
          } catch (Exception _GEN_UCE_NAME_1) {
            _GEN_UCE_NAME_1.printStackTrace();
            
          } 
          Platform.runLater(new Runnable() {
                public void run() {
                  base.client_tab_box.getChildren().clear();
                  base.setDisable(Boolean.valueOf(false));
                  base.Tabs.toFront();
                  base.client_tab_box.getChildren().add(vbox);
                  base.back_box.add(0, vbox);
                  base.PieShow();
                }
              });
          return Boolean.valueOf(true);
        }
      };
    base.parts.textProperty().unbind();
    base.parts.textProperty().bind(load_days.messageProperty());
    base.load_show.progressProperty().unbind();
    base.load_show.progressProperty().bind(load_days.progressProperty());
    TabThread = new Thread(load_days);
    TabThread.start();
  }
  Thread TabThread = new Thread(); 
  public void getCompany(final Base base, final String compid, Parent tit, String[] bt) {
    base.pay_selected.clear();
    base.secJr.clear();
    base.client_position = Integer.valueOf(1);
    base.bottom.add(1, bt);
    base.clients_company_report_search[1].clear();
    final VBox box = new VBox();
    box.getChildren().add(tit);
    base.clients_company_report_search[1].put("nizi6.".toLowerCase(), tit);
    final LocalDate from = (LocalDate)base.tab_from.getValue();
    final LocalDate to = (LocalDate)base.tab_to.getValue();
    base.Tabs.toFront();
    base.load.toFront();
    base.setDisable(Boolean.valueOf(true));
    final Map<String, String> rooms = new HashMap<>();
    Task load_days = new Task() {
        protected Object call() {
          updateMessage("getting Ready");
          try {
            ResultSet rows = Database.this.st.executeQuery("select * from rooms"+base.getHot()+" order by number");
            while (rows.next())
              rooms.put(rows.getString("roomid"), rows.getString("number")); 
            updateMessage("2 of 2");
            rows = Database.this.st.executeQuery("select bk.bookid as bkid,bk.roomid as id,cl.name as name,cl.tel as phone ,cl.passnumber as identity ,cl.coming as province,cp.name as company,bk.price as price,bk.dateout as dateout ,bk.datein as datein ,bk.payed as payed ,bk.dateout as t,bk.datein as f,bk.clientid as clid ,cl.nationality as nat,cl.sex as sex,strftime('%Y','now')-strftime('%Y',age) as age, cp.fullname as cf ,bk.cash as cash from booking"+base.getHot()+" as bk,clients as cl,rooms"+base.getHot()+" as rm,company as cp where bk.clientid = cl.clientid and bk.compid = cp.compid and cp.compid = " + compid + " and dateout > '" + from + "'  and datein < '" + to + "'group by bk.bookid");
            while (rows.next()) {
              String room;
              Integer Custom_days = Database.this.getDays(LocalDate.parse(rows.getString("f")), LocalDate.parse(rows.getString("t")));
              Integer Left_days = Database.this.getDays(from, LocalDate.parse(rows.getString("f")));
              Integer Right_days = Database.this.getDays(LocalDate.parse(rows.getString("t")), to);
              if (Left_days.intValue() < 0)
                Custom_days = Integer.valueOf(Custom_days.intValue() + Left_days.intValue()); 
              if (Right_days.intValue() < 0)
                Custom_days = Integer.valueOf(Custom_days.intValue() + Right_days.intValue()); 
              if (rooms.containsKey(rows.getString("id"))) {
                room = (String)rooms.get(rows.getString("id"));
              } else {
                room = rows.getString("id");
              } 
              base.Current_Comp = rows.getString("company");
              Room_record record = new Room_record(rows.getString(1), rows.getString(2), rows.getString(3), rows.getString(4), rows.getString(5), rows.getString(6), rows.getString(7), Integer.valueOf(rows.getInt(8)), rows.getString(11), Custom_days, rows.getString("datein"), rows.getString("dateout"), room, rows.getString("clid"),rows.getString("cf"),rows.getString("nat"),rows.getString("age"),rows.getString("sex"),rows.getString("cash"),"");
              FXMLLoader loader = new FXMLLoader(getClass().getResource("/fx/Client_details.fxml"));
              Parent root = loader.<Parent>load();
              Client_details c_l = loader.<Client_details>getController();
              c_l.init(base, record);
              base.secJr.add(record);
              base.clients_company_report_search[1].put(rows.getString("name").toLowerCase(), root);
              box.getChildren().add(root);
            } 
            updateProgress(1L, 1L);
            updateMessage("Fin");
          } catch (Exception _GEN_UCE_NAME_1) {
            _GEN_UCE_NAME_1.printStackTrace();
          } 
          Platform.runLater(new Runnable() {
                public void run() {
                  base.client_tab_box.getChildren().clear();
                  base.client_tab_box.getChildren().add(box);
                  base.setDisable(Boolean.valueOf(false));
                  base.Tabs.toFront();
                  base.back_box.add(1, box);
                }
              });
          return Boolean.valueOf(true);
        }
      };
    base.parts.textProperty().unbind();
    base.parts.textProperty().bind(load_days.messageProperty());
    base.load_show.progressProperty().unbind();
    base.load_show.progressProperty().bind(load_days.progressProperty());
    (new Thread(load_days)).start();
  }
  
  public String French_numbers(String number) {
    String new_number = " FBU";
    if (number.length() > 2) {
      new_number = number.substring(number.length() - 3, number.length()) + new_number;
    } else {
      new_number = number + new_number;
    } 
    Integer size = Integer.valueOf(number.length());
    Integer last3 = Integer.valueOf(size.intValue() - 3);
    while (last3.intValue() > 2) {
      new_number = number.substring(last3.intValue() - 3, last3.intValue()) + "," + new_number;
      last3 = Integer.valueOf(last3.intValue() - 3);
    } 
    if (last3.intValue() > 0)
      new_number = number.substring(0, last3.intValue()) + "," + new_number; 
    return new_number;
  }
  
  public void getThisClient(final Base base, final String clientid) {
    base.pay_selected.clear();
    base.thirdJr.clear();
    base.client_position = Integer.valueOf(2);
    base.clients_company_report_search[2].clear();
    final VBox box = new VBox();
    FXMLLoader loader = new FXMLLoader(getClass().getResource("/fx/Client_header.fxml"));
    Parent tit = null;
    try {
      tit = loader.<Parent>load();
    } catch (IOException ex) {
      ex.printStackTrace();
    } 
    base.clients_company_report_search[2].put("nizi6.".toLowerCase(), tit);
    final Client_header head = loader.<Client_header>getController();
    box.getChildren().add(tit);
    final LocalDate from = (LocalDate)base.tab_from.getValue();
    final LocalDate to = (LocalDate)base.tab_to.getValue();
    base.Tabs.toFront();
    base.load.toFront();
    base.setDisable(Boolean.valueOf(true));
    final Map<String, String> rooms = new HashMap<>();
    Task load_days = new Task() {
        protected Object call() {
          updateMessage("getting Ready");
          try {
            ResultSet rows = Database.this.st.executeQuery("select * from rooms"+base.getHot()+" order by number");
            while (rows.next())
              rooms.put(rows.getString("roomid"), rows.getString("number")); 
            updateMessage("2 of 2");
            rows = Database.this.st.executeQuery("select bk.bookid as bkid,bk.roomid as id,cl.name as name,cl.tel as phone ,cl.passnumber as identity ,cl.coming as province,cp.name as company,bk.price as price,bk.dateout as dateout ,bk.datein as datein ,bk.payed as payed ,bk.dateout as t, bk.datein as f,bk.clientid as clid ,cl.nationality as nat,cl.sex as sex,strftime('%Y','now')-strftime('%Y',age) as age, cp.fullname as cf,bk.cash as cash from booking"+base.getHot()+" as bk,clients as cl,rooms"+base.getHot()+" as rm,company as cp  where bk.clientid = cl.clientid and bk.compid = cp.compid and bk.clientid = " + clientid + " and dateout > '" + from + "'  and datein < '" + to + "'group by bk.bookid");
            Integer p = Integer.valueOf(0);
            Integer u = Integer.valueOf(0);
            String name = "";
            Integer t = Integer.valueOf(0);
            while (rows.next()) {
              String room;
              Integer Custom_days = Database.this.getDays(LocalDate.parse(rows.getString("f")), LocalDate.parse(rows.getString("t")));
              Integer Left_days = Database.this.getDays(from, LocalDate.parse(rows.getString("f")));
              Integer Right_days = Database.this.getDays(LocalDate.parse(rows.getString("t")), to);
              if (Left_days.intValue() < 0)
                Custom_days = Integer.valueOf(Custom_days.intValue() + Left_days.intValue()); 
              if (Right_days.intValue() < 0)
                Custom_days = Integer.valueOf(Custom_days.intValue() + Right_days.intValue()); 
              name = rows.getString("name");
              base.Current_Client = name;
              if (rooms.containsKey(rows.getString("id"))) {
                room = (String)rooms.get(rows.getString("id"));
              } else {
                room = rows.getString("id");
              } 
              Room_record record = new Room_record(rows.getString(1), rows.getString(2), rows.getString(3), rows.getString(4), rows.getString(5), rows.getString(6), rows.getString(7), Integer.valueOf(rows.getInt(8)), rows.getString(11), Custom_days, rows.getString("datein"), rows.getString("dateout"), room, rows.getString("clid"),rows.getString("cf"),rows.getString("nat"),rows.getString("age"),rows.getString("sex"),rows.getString("cash"),"");
              FXMLLoader loader = new FXMLLoader(getClass().getResource("/fx/Client_records.fxml"));
              Parent root = loader.<Parent>load();
              Client_records c_l = loader.<Client_records>getController();
              c_l.init(record, base);
              base.thirdJr.add(record);
              base.clients_company_report_search[2].put(room.toLowerCase(), root);
              box.getChildren().add(root);
              if (rows.getString("payed").equals("true")) {
                p = Integer.valueOf(p.intValue() + rows.getInt(8) * Custom_days.intValue());
                continue;
              } 
              u = Integer.valueOf(u.intValue() + rows.getInt(8) * Custom_days.intValue());
            } 
            t = Integer.valueOf(u.intValue() + p.intValue());
            String[] bt = new String[3];
            bt[0] = Database.this.French_numbers(p.toString());
            bt[1] = Database.this.French_numbers(u.toString());
            bt[2] = Database.this.French_numbers(t.toString());
            base.bottom.add(2, bt);
            head.init(name, bt[0], bt[1], bt[2]);
            updateProgress(1L, 1L);
            updateMessage("Fin");
          } catch (Exception _GEN_UCE_NAME_1) {
            _GEN_UCE_NAME_1.printStackTrace();
          } 
          Platform.runLater(new Runnable() {
                public void run() {
                  base.client_tab_box.getChildren().clear();
                  base.client_tab_box.getChildren().add(box);
                  base.setDisable(Boolean.valueOf(false));
                  base.Tabs.toFront();
                  base.back_box.add(2, box);
                }
              });
          return Boolean.valueOf(true);
        }
      };
    base.parts.textProperty().unbind();
    base.parts.textProperty().bind(load_days.messageProperty());
    base.load_show.progressProperty().unbind();
    base.load_show.progressProperty().bind(load_days.progressProperty());
    (new Thread(load_days)).start();
  }
  
  public Integer getAvailability_for_Change(Base base,LocalDate from, LocalDate to, String id) {
    Integer days = Integer.valueOf(1);
    try {
      Boolean r = Boolean.valueOf(false);
      ResultSet rows = this.st.executeQuery("select number,price from rooms"+base.getHot()+" where roomid ='" + id + "'");
      while (rows.next())
        r = Boolean.valueOf(true); 
      if (r.booleanValue()) {
        ResultSet row = this.st.executeQuery("select datein,dateout from booking"+base.getHot()+" where dateout > '" + from + "'  and datein < '" + to + "' and roomid = " + id + " order by bookid");
        while (row.next())
          days = -1; 
      } 
    } catch (SQLException sQLException) {
      sQLException.printStackTrace();
    } 
    return days;
  }
  
  public void changeDates(Base bs) {
    try {
      Boolean py = Boolean.valueOf(bs.Change_date_payed.isSelected());
      Boolean ch = Boolean.valueOf(bs.Change_date_cash.isSelected());
      this.st.executeUpdate("update booking"+bs.getHot()+" set datein='" + bs.Change_date_new_from.getValue() + "',dateout='" + bs.Change_date_new_to.getValue() + "',price = " + bs.Change_date_room_price.getText() + ", cash ='"+ch.toString()+"', payed='" + py.toString() + "' where bookid =" + bs.bookid + "");
    } catch (SQLException ex) {
      ex.printStackTrace();
    } 
  }
  
  public void pay(final Base b) {
    final LocalDate f = (LocalDate)b.tab_from.getValue();
    final LocalDate t = (LocalDate)b.tab_to.getValue();
    b.load.toFront();
    b.setDisable(Boolean.valueOf(true));
    Task task = new Task() {
        protected Object call() {
          for (String where : b.pay_selected) {
            try {
              ResultSet rows = Database.this.st.executeQuery("select bookid,clientid,datein,dateout,payed,price,compid,roomid from booking"+b.getHot()+" where dateout > '" + f + "'  and datein < '" + t + "' and " + where);
              ArrayList<String> first_q = new ArrayList<>();
              while (rows.next()) {
                Integer Custom_days = Database.this.getDays(LocalDate.parse(rows.getString(3)), LocalDate.parse(rows.getString(4)));
                Integer Left_days = Database.this.getDays(f, LocalDate.parse(rows.getString(3)));
                Integer Right_days = Database.this.getDays(LocalDate.parse(rows.getString(4)), t);
                if (Left_days.intValue() < 0 && Right_days.intValue() < 0) {
                  first_q.add("update booking"+b.getHot()+" set datein='" + f + "', dateout='" + t + "', payed='true' where " + where + "");
                  first_q.add("insert into booking"+b.getHot()+" (clientid,datein,dateout,payed,price,compid,roomid)Values(" + rows
                      .getString(2) + ",'" + rows.getString(3) + "','" + f + "','false'," + rows.getString(6) + "," + rows.getString(7) + ",'" + rows.getString(8) + "')");
                  first_q.add("insert into booking"+b.getHot()+" (clientid,datein,dateout,payed,price,compid,roomid)Values(" + rows
                      .getString(2) + ",'" + t + "','" + rows.getString(4) + "','false'," + rows.getString(6) + "," + rows.getString(7) + ",'" + rows.getString(8) + "')");
                  continue;
                } 
                if (Right_days.intValue() < 0) {
                  first_q.add("update booking"+b.getHot()+" set dateout='" + t + "',payed='true' where " + where + "");
                  first_q.add("insert into booking"+b.getHot()+" (clientid,datein,dateout,payed,price,compid,roomid)Values(" + rows
                      .getString(2) + ",'" + t + "','" + rows.getString(3) + "','false'," + rows.getString(6) + "," + rows.getString(7) + ",'" + rows.getString(8) + "')");
                  continue;
                } 
                if (Left_days.intValue() < 0) {
                  first_q.add("update booking"+b.getHot()+" set datein='" + f + "' ,payed='true'where " + where + "");
                  first_q.add("insert into booking"+b.getHot()+" (clientid,datein,dateout,payed,price,compid,roomid)Values(" + rows
                      .getString(2) + ",'" + rows.getString(3) + "','" + f + "','false'," + rows.getString(6) + "," + rows.getString(7) + ",'" + rows.getString(8) + "')");
                  continue;
                } 
                first_q.add("update booking"+b.getHot()+" set payed='true'where " + where + "");
              } 
              for (String query : first_q)
                Database.this.st.executeUpdate(query); 
              Platform.runLater(new Runnable() {
                    public void run() {
                      b.setDisable(Boolean.valueOf(false));
                      b.Tabs.toFront();
                      Database.this.client_tab_load(b, f, t);
                    }
                  });
            } catch (Exception v) {
              v.printStackTrace();
            } 
          } 
          return Boolean.valueOf(true);
        }
      };
    b.parts.textProperty().unbind();
    b.parts.textProperty().bind(task.messageProperty());
    b.load_show.progressProperty().unbind();
    b.load_show.progressProperty().bind(task.progressProperty());
    (new Thread(task)).start();
  }
    LocalDate ot;
    public ArrayList<TrancheGlobal> getTranche(Base bs,LocalDate from, LocalDate to,Boolean tb,Boolean mb,String num) {
        ArrayList<TrancheGlobal> TrancheArray = new ArrayList();
        to = to.plusDays(1);
        HashMap<Integer,Integer> oRow   = new HashMap();
        HashMap<Integer,HashMap> oAddress   = new HashMap();
        HashMap<Integer,Integer> Hotel  = new HashMap();
        HashMap<Integer,Integer> Others  = new HashMap();
        HashMap<Integer,Integer> Cash   = new HashMap();
        HashMap<Integer,Integer> Dettes = new HashMap();
        HashMap<Integer,Integer> Total  = new HashMap(); 
        HashMap<Integer,HashMap> CompAddress = new HashMap();
        HashMap<String,ArrayList> Address = new HashMap();
        ArrayList<TrancheGlobal.Summary> Tglobal = new ArrayList();
        HashMap<String,Integer> Address1 = new HashMap();
        TrancheGlobal.Summary ht = new TrancheGlobal.Summary();
        ht.setDate("");
        ht.setT1("HOTEL");
        ht.setCm(0);
        Address1.put("hotel", 0);
        Tglobal.add(ht);
        TrancheGlobal.Summary Ot1 = new TrancheGlobal.Summary();
        Ot1.setDate("");
        Ot1.setT1("AUTRE");
        Ot1.setCm(0);
        Address1.put("others", 1);
        Tglobal.add(Ot1);
        TrancheGlobal.Summary ct = new TrancheGlobal.Summary();
        ct.setDate("");
        ct.setT1("CASH");
        ct.setCm(0);
        Address1.put("cash", 2);
        Tglobal.add(ct);
        TrancheGlobal.Summary dt = new TrancheGlobal.Summary();
        dt.setDate("");
        dt.setT1("DETTES");
        dt.setCm(0);
        Address1.put("dette", 3);
        Tglobal.add(dt);
        Integer tot =0;
        final VBox box = new VBox();
        final Integer dys = getDays(from, to);
        Map<String, String> rooms = new HashMap<>();
        try {
          ArrayList<Integer[]> colrow = new ArrayList();
          ResultSet rows = Database.this.st.executeQuery("select * from rooms"+bs.getHot()+" order by number");
          while (rows.next())
            rooms.put(rows.getString("roomid"), rows.getString("number")); 
      
          for (int k = 0; k < dys.intValue(); k++) {
              Integer[] it ={1,0};
              colrow.add(k, it);
              TrancheGlobal tg = new TrancheGlobal();
                tg.setFromDate(from.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")).toString());
                tg.setToDate(ot.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")).toString());
                tg.setTrancheNumber(num);
                tg.setTrancheDateRange(from.format(DateTimeFormatter.ofPattern("dd")).toString()+"-"+to.minusDays(1).format(DateTimeFormatter.ofPattern("dd/MM/yyyy")).toString());
                tg.setTrancheBand(Boolean.TRUE);
                tg.setDate(from.plusDays(k).format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
              tg.setCizanyeRooms1(new TrancheGlobal.HRooms());
              
              ArrayList<TrancheGlobal.Totals> tt = new ArrayList();
              tg.setTotals(tt);
              if (k==dys-1) {
                  tg.setTrancheTitle(true);
                  TrancheArray.add(tg);
              }else if(k==0){
                  tg.setTrancheTitle(true);
                  tg.setTrancheBand(Boolean.FALSE);
                  TrancheArray.add(tg);
              }
                else{
                tg.setTrancheTitle(false);
                tg.setTrancheBand(Boolean.FALSE);
                TrancheArray.add(tg);
              }
            HashMap<String,Integer[]> cd = new HashMap();  
            oRow.put(k,0);
            oAddress.put(k,new HashMap());
            Hotel.put(k,0);
            Others.put(k,0);
            Cash.put(k,0);  
            Dettes.put(k,0);
            Total.put(k,0); 
            CompAddress.put(k, cd);
          } 
          rows = Database.this.st.executeQuery("select bk.bookid as bkid,bk.roomid as id,cl.name as name,cl.tel as phone ,cl.passnumber as identity ,cl.coming as province,cp.name as company,bk.price as price,bk.dateout as dateout ,bk.datein as datein ,bk.payed as payed,julianday(bk.dateout)-julianday(bk.datein) ,cl.nationality as nat,cl.sex as sex,cl.age as age, cp.fullname as cf,bk.cash as cash,bk.otherprice as other,julianday(datein)-julianday('"+from+"') as sposi,julianday(dateout)-julianday('"+from+"') as endpos ,julianday('"+to+"')-julianday('"+from+"')as dy from booking"+bs.getHot()+" as bk,clients as cl,rooms"+bs.getHot()+" as rm,company as cp  where bk.clientid = cl.clientid and bk.compid = cp.compid and dateout > '" + from + "'  and datein < '" + to + "'group by bk.bookid");
          while (rows.next()) {
            String room;
            Integer position, place = Integer.valueOf(0);
            LocalDate pdate =LocalDate.parse(rows.getString("datein"));
            if (pdate.compareTo(from) <= 0) {
              position = Integer.valueOf(0);
            } else {
              position = (rows.getInt("sposi"));
            } 

            while (position.intValue() < rows.getInt("dy") && place.intValue() < rows.getInt(12) && position< rows.getInt("endpos")) {
               
              if (rows.getInt("other") == 0) {
                  TrancheGlobal.Summary sm = Tglobal.get(Address1.get("hotel"));
                  sm.setCm(sm.getCm()+rows.getInt("price"));
                  Tglobal.set(Address1.get("hotel"),sm);
                }
              else{
                  TrancheGlobal.Summary sm = Tglobal.get(Address1.get("others"));
                  sm.setCm(sm.getCm()+rows.getInt("price"));
                  Tglobal.set(Address1.get("others"),sm);
                }
              if(rows.getString("cash").equals("true")){
                  TrancheGlobal.Summary sm = Tglobal.get(Address1.get("cash"));
                  sm.setCm(sm.getCm()+rows.getInt("price"));
                  Tglobal.set(Address1.get("cash"),sm);
              }else{
                    
              }
              if(rows.getString("payed").equals("false")){
                  TrancheGlobal.Summary sm = Tglobal.get(Address1.get("dette"));
                  sm.setCm(sm.getCm()+rows.getInt("price"));
                  Tglobal.set(Address1.get("dette"),sm);
                  if (!Address1.containsKey(rows.getString("cf"))) {
                      TrancheGlobal.Summary tt = new TrancheGlobal.Summary();
                      tt.setDate("");
                      tt.setT1("");
                      tt.setM1(rows.getString("cf"));
                      tt.setCm(rows.getInt("price"));
                      Address1.put(rows.getString("cf"), Address1.size());
                      Tglobal.add(tt);
                  } else {
                        TrancheGlobal.Summary tt = Tglobal.get(Address1.get(rows.getString("cf")));
                        tt.setCm(tt.getCm()+rows.getInt("price"));
                        Tglobal.set(Address1.get(rows.getString("cf")),tt);
                  }
              }
              tot += rows.getInt("price");
              
              
              
              
              TrancheGlobal tranche = TrancheArray.get(position.intValue());
              String compString;
              Integer[] nm = new Integer[2];
              HashMap<String,Integer[]> CD = CompAddress.get(position);
              
              if(CD.containsKey(rows.getString("cf"))){
                  nm = CD.get(rows.getString("cf"));
                  nm[0] = nm[0]+1;
                  nm[1] = nm[1]+ rows.getInt("price");
                  CD.replace(rows.getString("cf"), nm);
                  compString = nm[0]+" "+rows.getString("cf")+" "+French_numbers(nm[1].toString());
              }
              else{                        
                  nm[0] = 1;
                  nm[1] = rows.getInt("price");
                  CD.put(rows.getString("cf"), nm);
                  compString = rows.getString("cf")+" "+French_numbers(nm[1].toString());
              }
              if(Address.containsKey(rows.getString("cf")+position)){                  
                    ArrayList<Integer> ad = Address.get(rows.getString("cf")+position);
                    ArrayList<TrancheGlobal.CompSumary> ex = tranche.GetCompSumary();
                    if(ex.size() < ad.get(0)){
                        tranche.setCompMoney(new TrancheGlobal.CompSumary());
                        ex = tranche.GetCompSumary();
                    }
                    TrancheGlobal.CompSumary sm = ex.get(ad.get(0)-1);
                    if(null != ad.get(1))switch (ad.get(1)) {
                        case 1:
                            sm.setS1(compString);
                            break;
                        case 2:
                            sm.setS2(compString);
                            break;
                        case 3:
                            sm.setS3(compString);
                            break;
                        default:
                            break;
                    }

                  tranche.SetComp(ad.get(0)-1, sm);
              }else{
                    Integer[] colr = colrow.get(position);
                    if (colr[1] == 3) {
                        colr[0]++;
                        colr[1] = 1;
                    }else{
                        colr[1]++;
                    }
                    colrow.set(position, colr);
                    ArrayList<Integer> arl = new ArrayList();
                    arl.add(colr[0]);
                    arl.add(colr[1]);
                    Address.put(rows.getString("cf")+position, arl);
                    Integer[] ad = colr;
                    
                    ArrayList<TrancheGlobal.CompSumary> ex = tranche.GetCompSumary();
                    if(ex.size() < ad[0]){
                        tranche.setCompMoney(new TrancheGlobal.CompSumary());
                        ex = tranche.GetCompSumary();
                    }
                    TrancheGlobal.CompSumary sm = ex.get(ad[0]-1);
                    if(null != ad[1])switch (ad[1]) {
                        case 1:
                            sm.setS1(compString);
                            break;
                        case 2:
                            sm.setS2(compString);
                            break;
                        case 3:
                            sm.setS3(compString);
                            break;
                        default:
                            break;
                    }

                  tranche.SetComp(ad[0]-1, sm);
              }
                
              if(rows.getString("payed").equals("false")){
                  Dettes.replace(position,   Dettes.get(position) + rows.getInt("price"));
              }
              if(rows.getString("cash").equals("true")){
                  Cash.replace(position,   Cash.get(position) + rows.getInt("price"));
              }
              Total.replace(position, Total.get(position) + rows.getInt("price"));

              if (rooms.containsKey(rows.getString(2))) {
                  Hotel.replace(position,  Hotel.get(position) + rows.getInt("price"));
                  TrancheGlobal.HRooms cz = tranche.GetHRooms().get(0);

                  switch (rows.getString(2)){
                      case "1":
                          cz.setaO1(rows.getString("company"));
                          break;
                      case "2":
                          cz.setaO2(rows.getString("company"));
                          break;
                      case "3":
                          cz.setaO3(rows.getString("company"));
                          break;
                      case "4":
                          cz.setaO4(rows.getString("company"));
                          break;
                      case "5":
                          cz.setaO5(rows.getString("company"));
                          break;
                      case "6":
                          cz.setaO6(rows.getString("company"));
                          break;
                      case "7":
                          cz.setaO7(rows.getString("company"));
                          break;
                      case "8":
                          cz.setaO8(rows.getString("company"));
                          break;
                      case "9":
                          cz.setaO9(rows.getString("company"));
                          break;
                      case "10":
                          cz.setA1O(rows.getString("company"));
                          break;
                      case "11":
                          cz.setA11(rows.getString("company"));
                          break;
                      case "12":
                          cz.setbO1(rows.getString("company"));
                          break;
                      case "13":
                          cz.setbO2(rows.getString("company"));
                          break;
                      case "14":
                          cz.setbO3(rows.getString("company"));
                          break;
                      case "15":
                          cz.setbO4(rows.getString("company"));
                          break;

                  }
                  tranche.setCizanyeRooms(cz);
                } else {
                  Others.replace(position,  Others.get(position) + rows.getInt("price"));
                  TrancheGlobal.ORooms Ot; 
                  HashMap<String,Integer> adc = oAddress.get(position);
                  Integer otloc = oRow.get(position);
                  if(adc.containsKey(rows.getString("company")+rows.getString(2))){
                      Ot = tranche.GetORooms(adc.get(rows.getString("company")+rows.getString(2)));
                      otloc = adc.get(rows.getString("company")+rows.getString(2));
                      Ot.setClients(Ot.getClients()+1);
                      Ot.setCompprice(Ot.getCompprice()+rows.getInt("price"));
                      Ot.setOthersprice(Ot.getOthersprice()+rows.getInt("other"));
                  }
                  else{
                      adc.put(rows.getString("company")+rows.getString(2), oRow.get(position));
                      Ot = tranche.GetORooms(oRow.get(position));
                      Ot.setClients(1);
                      Ot.setName(rows.getString(2));
                      Ot.setCompprice(rows.getInt("price"));
                      Ot.setComp(rows.getString("company"));
                      Ot.setOthersprice(rows.getInt("other"));
                      oRow.replace(position,oRow.get(position)+1);
                  }
                  oAddress.replace(position, adc);
                  tranche.placeORooms(otloc, Ot);
                }
              ArrayList<TrancheGlobal.Totals> TT = new ArrayList();
              TrancheGlobal.Totals THotel = new TrancheGlobal.Totals();
              THotel.setTitle("Hotel");
              THotel.setMoney(French_numbers(Hotel.get(position).toString()));
              TrancheGlobal.Totals TAutre = new TrancheGlobal.Totals();
              TAutre.setTitle("Autre");
              TAutre.setMoney(French_numbers(Others.get(position).toString()));
              TrancheGlobal.Totals TCash = new TrancheGlobal.Totals();
              TCash.setTitle("Cash");
              TCash.setMoney(French_numbers(Cash.get(position).toString()));
              TrancheGlobal.Totals TDette = new TrancheGlobal.Totals();
              TDette.setTitle("Dettes");
              TDette.setMoney(French_numbers(Dettes.get(position).toString()));
              TrancheGlobal.Totals Ttotal = new TrancheGlobal.Totals();
              Ttotal.setTitle("TOTAL");
              Ttotal.setMoney(French_numbers(Total.get(position).toString()));
              
              TT.add(THotel);
              TT.add(TAutre);
              TT.add(TCash);
              TT.add(TDette);
              TT.add(Ttotal);
              tranche.setTotals(TT);
              TrancheArray.set(position, tranche);
              Integer integer3 = position, integer4 = position = Integer.valueOf(position.intValue() + 1);
              integer3 = place;
              integer4 = place = Integer.valueOf(place.intValue() + 1);
            }
            
          } 
            TrancheGlobal.Summary tt = new TrancheGlobal.Summary();
            tt.setDate("");
            tt.setT1("TOTAL");
            tt.setCm(tot);
            Address1.put("TOTAL", Address1.size());
            Tglobal.add(tt);
            TrancheGlobal tg = TrancheArray.get(TrancheArray.size()-1);
            TrancheGlobal.Summary empty = new TrancheGlobal.Summary();
            empty.setT1("");
            empty.setCm(0);
            Tglobal.add(empty);
            Tglobal.addAll(this.getDepenceTotal(from,to,bs));
            tg.setTrancheSummary(Tglobal);
            TrancheArray.set(TrancheArray.size()-1,tg);
        } catch (Exception _GEN_UCE_NAME_1) {
          _GEN_UCE_NAME_1.printStackTrace();
        } 
        return TrancheArray;
    }

    public ArrayList<TrancheGlobal> getTrancheGlobal(LocalDate Tf, LocalDate tl,Base bs) {
        LocalDate Tt;
        ot = tl;
        Integer fromCount = 1;
        ArrayList<TrancheGlobal> trancheglobal = new ArrayList();
        for (int i = ot.getMonthValue()-Tf.getMonthValue() ; i > -1 ; i--) {
            Tt = ot.minusMonths(i);
            if(i>0){
                Tt = Tt.withDayOfMonth(Tt.lengthOfMonth());
            }
            if(Tf.getDayOfMonth() < 11){
                if(Tt.getDayOfMonth() < 11){                    
                    trancheglobal.addAll(this.getTranche(bs,Tf, Tt,true,false,"PREMIERE"));
                }
                else{
                    trancheglobal.addAll(this.getTranche(bs,Tf,Tt.withDayOfMonth(10),true,false,"PREMIERE"));
                }
                Tf = Tf.withDayOfMonth(11);
            }
            if(Tf.getDayOfMonth()< 21){
                if(Tt.getDayOfMonth() <= 21){
                    trancheglobal.addAll(this.getTranche(bs,Tf, Tt,true,false,"2 EMME"));
                }
                else{
                    trancheglobal.addAll(this.getTranche(bs,Tf,Tt.withDayOfMonth(20),true,false,"2 EMME"));
                }
                Tf = Tf.withDayOfMonth(21);
            }
            if(Tf.getDayOfMonth()<= 31){
                trancheglobal.addAll(this.getTranche(bs,Tf, Tt,true,true,"3 EMME"));
                Tf = Tf.plusMonths(1).withDayOfMonth(1);
            }
        }
        return trancheglobal;
    }

    public void deleteDepence(String depid,Base bs) {
      try {
          st.executeUpdate("delete from Depence"+bs.getHot()+" where depid="+depid+"");
      } catch (SQLException ex) {
          ex.printStackTrace();
      }
    }
    public void InsetDepence(String text, String text0, String toString,Base bs,String gl,String ch,Boolean vers) {
        try {
          st.executeUpdate("insert into Depence"+bs.getHot()+"(description,amount,Date,global,cash,vers) values('"+text+"',"+text0+",'"+toString+"','"+gl+"','"+ch+"','"+vers+"')");
      } catch (SQLException ex) {
          ex.printStackTrace();
      }
    }

    public void getDepence(Base base,LocalDate value, LocalDate value0,Boolean table) {
        base.clearDBox();
        Boolean f = false;
        try{
            ResultSet rows = st.executeQuery("select * from Depence"+base.getHot()+" where date >= '"+value+"' and date <= '"+value0+"' and vers='"+table+"' order by date");
            while(rows.next()){
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/fx/depenceItem.fxml"));
                Node r  = loader.load();
                depenceItem c = loader.getController();
                c.init(base, rows.getString("depid"), rows.getString("description"), rows.getString("amount"), LocalDate.parse(rows.getString("date")).format(DateTimeFormatter.ofPattern("dd/MM/yyy")), r);
                base.setDBox(r);
                f =true;
            }
            if(!f){
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/fx/vide.fxml"));
                Node root = loader.load();
                vide vd = loader.getController();
                vd.init("Vide de " + value.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) + " a " + value0.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
                base.setDBox(root);
            }
        }
        catch(Exception v){
            v.printStackTrace();
        }
    }

    public ArrayList<TrancheGlobal.Summary> getDepencePrint(LocalDate Tf, LocalDate Tt,Base bs) {
        ArrayList<TrancheGlobal.Summary> rt = new ArrayList();
        Integer Total =0;
        try{
            ResultSet rows = st.executeQuery("select * from Depence"+bs.getHot()+" where date >= '"+Tf+"' and date <= '"+Tt+"' and global = 'false' and vers='false' order by date");
            while(rows.next()){
                TrancheGlobal.Summary sm = new TrancheGlobal.Summary();
                sm.setT1(rows.getString("description"));
                sm.setDate(LocalDate.parse(rows.getString("date")).format(DateTimeFormatter.ofPattern("dd/MM")));
                sm.setCm(rows.getInt("amount"));
                rt.add(sm);
                Total += rows.getInt("amount");
            }
            if (Total > 0) {
                TrancheGlobal.Summary sm = new TrancheGlobal.Summary();
                sm.setT1("DEPENSES TOTAL");
                sm.setDate("");
                sm.setCm(Total);
                rt.add(sm);
            }
        }
        catch(Exception v){
            v.printStackTrace();
        }
        return rt;
    }

    public ArrayList<TrancheGlobal.PoliceFields> getPolice(Base bs,LocalDate from, LocalDate to) {
        ArrayList<TrancheGlobal.PoliceFields> Fields = new ArrayList();
        to = to.plusDays(1);
        final Integer dys = getDays(from, to);
        Map<String, String> rooms = new HashMap<>();
        try {
            for (int k = 0; k < dys.intValue(); k++) {
                TrancheGlobal.PoliceFields fl = new TrancheGlobal.PoliceFields();
                fl.setDate(from.plusDays(k).format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
                Fields.add(fl);
            }
          ResultSet rows = Database.this.st.executeQuery("select * from rooms"+bs.getHot()+" order by number");
          while (rows.next())
            rooms.put(rows.getString("roomid"), rows.getString("number")); 

          rows = Database.this.st.executeQuery("select bk.roomid as id,bk.datein as datein ,cl.name as name,cl.passnumber as identity ,cl.coming as province,julianday(bk.dateout)-julianday(bk.datein) ,cl.nationality as nat,cl.sex as sex,strftime('%Y','now')-strftime('%Y',age) as age, cp.fullname as cf ,julianday(dateout)-julianday('"+from+"') as endpos from booking"+bs.getHot()+" as bk,clients as cl,rooms"+bs.getHot()+" as rm,company as cp  where bk.clientid = cl.clientid and bk.compid = cp.compid and dateout > '" + from + "'  and datein < '" + to + "'group by bk.bookid");
          while (rows.next()) {
            String room;
            Integer position, place = Integer.valueOf(0);
            LocalDate pdate =LocalDate.parse(rows.getString("datein"));
            if (pdate.compareTo(from) <= 0) {
              position = Integer.valueOf(0);
            } else {
              position = Database.this.getDays(from, LocalDate.parse(rows.getString("datein")));
            } 
            
            while (position.intValue() < Database.this.getDays(from, to).intValue() && place.intValue() < rows.getInt(6) && position < rows.getInt("endpos")) {

              if (rooms.containsKey(rows.getString(1)) && !rows.getString("age").startsWith(".")&& !rows.getString("province").startsWith(".") 
                      && !rows.getString("name").startsWith(".")&& !rows.getString("sex").startsWith(".")&& !rows.getString("nat").startsWith(".")
                      && !rows.getString("cf").startsWith(".")&& !rows.getString("identity").startsWith(".")
                      && !rows.getString("age").startsWith("-")&& !rows.getString("province").startsWith("-") 
                      && !rows.getString("name").startsWith("-")&& !rows.getString("sex").startsWith("-")&& !rows.getString("nat").startsWith("-")
                      && !rows.getString("cf").startsWith("-")&& !rows.getString("identity").startsWith("-")) {
                  TrancheGlobal.Police pol = new TrancheGlobal.Police();
                  pol.setRoom(rooms.get(rows.getString(1)));
                  pol.setAge(rows.getString("age"));
                  pol.setProvn(rows.getString("province"));
                  pol.setName(rows.getString("name"));
                  pol.setSex(rows.getString("sex"));
                  pol.setNat(rows.getString("nat"));
                  pol.setFun(rows.getString("cf"));
                  pol.setId(rows.getString("identity"));
                  TrancheGlobal.PoliceFields det = Fields.get(position);
                  det.setDetails(pol);
                  Fields.set(position, det);
                }

              Integer integer3 = position, integer4 = position = Integer.valueOf(position.intValue() + 1);
              integer3 = place;
              integer4 = place = Integer.valueOf(place.intValue() + 1);
              
              
            } 
          } 

        } catch (Exception _GEN_UCE_NAME_1) {
          _GEN_UCE_NAME_1.printStackTrace();
        } 
        return Fields;
    }
   public ArrayList<TrancheGlobal.Summary> GetGlobal(Base bs,LocalDate from, LocalDate to){
       to = to.plusDays(1);
        ArrayList<TrancheGlobal.Summary> Tglobal = new ArrayList();
        HashMap<String,Integer> Address = new HashMap();
        TrancheGlobal.Summary ht = new TrancheGlobal.Summary();
        ht.setDate("");
        ht.setT1("HOTEL");
        ht.setCm(0);
        Address.put("hotel", 0);
        Tglobal.add(ht);
        TrancheGlobal.Summary ot = new TrancheGlobal.Summary();
        ot.setDate("");
        ot.setT1("AUTRE");
        ot.setCm(0);
        Address.put("others", 1);
        Tglobal.add(ot);
        TrancheGlobal.Summary ct = new TrancheGlobal.Summary();
        ct.setDate("");
        ct.setT1("CASH");
        ct.setCm(0);
        Address.put("cash", 2);
        Tglobal.add(ct);
        TrancheGlobal.Summary dt = new TrancheGlobal.Summary();
        dt.setDate("");
        dt.setT1("DETTES");
        dt.setCm(0);
        Address.put("dette", 3);
        Tglobal.add(dt);
        Integer tot =0;
        try{
          ResultSet rows = Database.this.st.executeQuery("select julianday(bk.dateout)-julianday(bk.datein),bk.datein as datein,bk.otherprice,bk.price as price,bk.cash as cash ,bk.payed as payed,cp.fullname as cf , julianday(datein)-julianday('"+from+"') as sposi,julianday(dateout)-julianday('"+from+"') as endpos ,julianday('"+to+"')-julianday('"+from+"')as dy from booking"+bs.getHot()+" as bk,clients as cl,rooms"+bs.getHot()+" as rm,company as cp  where bk.clientid = cl.clientid and bk.compid = cp.compid and dateout > '" + from + "'  and datein < '" + to + "'group by bk.bookid");
          while (rows.next()) {
            String room;
            Integer position, place = Integer.valueOf(0);
            LocalDate pdate =LocalDate.parse(rows.getString("datein"));
            if (pdate.compareTo(from) <= 0) {
              position = Integer.valueOf(0);
            } else {
              position = (rows.getInt("sposi"));
            } 

            while (position.intValue() < rows.getInt("dy") && place.intValue() < rows.getInt("dy") && position< rows.getInt("endpos")) {
              if (rows.getInt(3) == 0) {
                  TrancheGlobal.Summary sm = Tglobal.get(Address.get("hotel"));
                  sm.setCm(sm.getCm()+rows.getInt("price"));
                  Tglobal.set(Address.get("hotel"),sm);
                }
              else{
                  TrancheGlobal.Summary sm = Tglobal.get(Address.get("others"));
                  sm.setCm(sm.getCm()+rows.getInt("price"));
                  Tglobal.set(Address.get("others"),sm);
                }
              if(rows.getString("cash").equals("true")){
                  TrancheGlobal.Summary sm = Tglobal.get(Address.get("cash"));
                  sm.setCm(sm.getCm()+rows.getInt("price"));
                  Tglobal.set(Address.get("cash"),sm);
              }else{
                    
              }
              if(rows.getString("payed").equals("false")){
                  TrancheGlobal.Summary sm = Tglobal.get(Address.get("dette"));
                  sm.setCm(sm.getCm()+rows.getInt("price"));
                  Tglobal.set(Address.get("dette"),sm);
                  if (!Address.containsKey(rows.getString("cf"))) {
                      TrancheGlobal.Summary tt = new TrancheGlobal.Summary();
                      tt.setDate("");
                      tt.setT1("");
                      tt.setM1(rows.getString("cf").toUpperCase());
                      tt.setCm(rows.getInt("price"));
                      Address.put(rows.getString("cf"), Address.size());
                      Tglobal.add(tt);
                  } else {
                        TrancheGlobal.Summary nm = Tglobal.get(Address.get(rows.getString("cf")));
                        nm.setCm(nm.getCm()+rows.getInt("price"));
                        Tglobal.set(Address.get(rows.getString("cf")),nm);
                  }
              }
              tot += rows.getInt("price");
              Integer integer3 = position, integer4 = position = Integer.valueOf(position.intValue() + 1);
              integer3 = place;
              integer4 = place = Integer.valueOf(place.intValue() + 1);
            } 
          } 
            TrancheGlobal.Summary tt = new TrancheGlobal.Summary();
            tt.setDate("");
            tt.setT1("SOMME TOTAL");
            tt.setCm(tot);
            Address.put("TOTAL", Address.size());
            Tglobal.add(tt);

        } catch (Exception _GEN_UCE_NAME_1) {
          _GEN_UCE_NAME_1.printStackTrace();
        } 
        return Tglobal;
   }

    public void LoadSemina(Base bs, LocalDate from, LocalDate to) {
        bs.Tabs.toFront();
        bs.setDisable(Boolean.TRUE);
        bs.load.toFront();
         Task task = new Task(){
             protected Object call(){
                 ArrayList<Node> roots = new ArrayList();
                 try{
                    ResultSet rows = st.executeQuery("select sm.compid as compid, sm.date as date ,cp.fullname as company, sum(sm.count* sm.days * sm.price) as total from Semina as sm , company as cp where cp.compid = sm.compid and sm.date between '"+from+"' and '"+to+"' group by sm.date|| ''|| sm.compid");
                    while(rows.next()){
                        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fx/seminarTitle.fxml"));
                        Node root = loader.load();
                        seminarTitle sT = loader.getController();
                        sT.setCompid(rows.getString(1));
                        sT.setName(rows.getString(3));
                        sT.setDate(rows.getString(2));
                        sT.setTotal(rows.getString("total"));
                        sT.setIndex(root);
                        sT.setBase(bs);
                        roots.add(root);
                        updateMessage(rows.getString(3));
                    }
                    st.close();
                }
                 
                catch(Exception x){
                    x.printStackTrace();
                }
                 Platform.runLater(new Runnable() {
                    public void run() {
                      bs.seminarBox.getChildren().clear();
                        if (roots.size()>0) {
                            bs.seminarBox.getChildren().addAll(roots);
                        }else{
                            try {
                                FXMLLoader loader = new FXMLLoader(getClass().getResource("/fx/vide.fxml"));
                                Node root = loader.load();
                                vide vd = loader.getController();
                                vd.init("Vide de " + from.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) + " a " + to.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
                                bs.seminarBox.getChildren().add(root);
                            } catch (IOException iOException) {
                                iOException.printStackTrace();
                            }
                        }
                      bs.setDisable(Boolean.valueOf(false));
                      bs.Tabs.toFront();
                    }
                  });
                 return true;
             }
         };
         bs.parts.textProperty().unbind();
         bs.parts.textProperty().bind(task.messageProperty());
         bs.load_show.progressProperty().unbind();
         bs.load_show.progressProperty().bind(task.progressProperty());
        TabThread = new Thread(task);
        TabThread.start();
    }

    public void removeSitem(String sId,String date,String comp) {
        try{
            st.executeUpdate("delete from semina where seid=" + sId + "");
        }
        catch(Exception x){
            x.printStackTrace();
        }
    }
    public void removeSeminaAll(String compid, String date) {
        try{
            st.executeUpdate("delete from semina where compid="+compid+" and date='"+date+"'");
        }
        catch(Exception x){
            x.printStackTrace();
        }
    }

    public void editSitem(String sId, String name, Integer count, Integer days, Integer price,String date,String compid) {
        try {
            if (sId.equals("0")) {
                st.executeUpdate("insert into semina(date,name,compid,count,days,price) values('"+date+"','"+name+"',"+compid+","+count+","+days+","+price+")");
            } else {
                st.executeUpdate("update semina set name ='"+name+"',count="+count+", days ="+days+",price = "+price+" where seid ="+sId+"");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }

    public HashMap getSItems(seminarTitle semi,String compid, String Odate) {
        HashMap<Integer,ArrayList> items = new HashMap();
        ArrayList<Node> iNodes = new ArrayList();
        ArrayList<seminarItem> print = new ArrayList();
        Boolean rc = false;
        try{
            String ldate = "";
            String lCompid ="";
            ResultSet rows = st.executeQuery("select sm.seid as sid,sm.name as name, sm.count* sm.days * sm.price as total,sm.count as count,sm.days as days,sm.price as price,sm.date as date,sm.compid as compid from Semina as sm , company as cp where cp.compid = "+compid+" and sm.compid ="+compid+" and sm.date ='"+Odate+"'");
            while(rows.next()){
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/fx/seminarItem.fxml"));
                Node root = loader.load();
                seminarItem sT = loader.getController();
                sT.setCompid(compid);
                sT.setSid(rows.getString("sid"));
                sT.setName(rows.getString(2));
                sT.setTotal(rows.getString("total"));
                sT.setNode(root);
                sT.setSeT(semi);
                ldate = rows.getString("date");
                lCompid = rows.getString("compid");
                sT.setDate(rows.getString("date"));
                sT.setPrice(rows.getString("price"));
                sT.setCount(rows.getString("count"));
                sT.setDays(rows.getString("days"));
                print.add(sT);
                iNodes.add(root);
                if(rows.getInt("price") > 0){
                    rc = true;
                }
            }
            if (rc) {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/fx/seminarItem.fxml"));
                Node root = loader.load();
                seminarItem sT = loader.getController();
                sT.setSeT(semi);
                sT.setCompid(lCompid);
                sT.setDate(ldate);
                iNodes.add(root);
            }
        }
        catch(Exception x){
            x.printStackTrace();
        }
        
        items.put(0, iNodes);
        items.put(1, print);
        return items;
    }

    public ObservableList<String> getCompaniesForSem() {
        ObservableList<String> olist = FXCollections.observableArrayList();
        try{
            ResultSet rows = st.executeQuery("select fullname from company");
            while(rows.next()){
                olist.add(rows.getString(1));
            }
        }
        catch(Exception x){
            x.printStackTrace();
        }
        return olist;
    }

    public void addSemina(Base bs,String value, LocalDate value0) {
        try{
            st.executeUpdate("insert into semina(date,compid) values('"+value0+"',(select compid from company where fullname = '"+value+"'))");
            bs.tab_load();
        }
        catch(Exception x){
            x.printStackTrace();
        }
    }

    public HashMap<String, String> getCDetails(String Compid) {
        HashMap<String, String> compH = new HashMap() ;
        try{
            ResultSet rows = st.executeQuery("select fullname,resi,nif from company where compid = "+Compid+"");
            while(rows.next()){
                compH.put("name", rows.getString(1));
                compH.put("nif", rows.getString(3));
                compH.put("resi", rows.getString(2));
            }
        }
        catch(Exception x){
            x.printStackTrace();
        }
        return compH;
    }
    public ArrayList<TrancheGlobal.seminaReport> getSReport(String from,String to){
        ArrayList<TrancheGlobal.seminaReport> rit = new ArrayList();
        HashMap<String,Integer> address = new HashMap();
        try{
            ResultSet rows = st.executeQuery("select sm.name as name,sm.date as date ,cp.fullname as company,sm.count as count,sm.days as days, sm.price as price from Semina as sm , company as cp where cp.compid = sm.compid and sm.date between '"+from+"' and '"+to+"' order by sm.date");
            while(rows.next()){
                if (rows.getInt("days")*rows.getInt("count")*rows.getInt("price")>0) {
                    if (!address.containsKey(rows.getString("company") + LocalDate.parse(rows.getString("date")).format(DateTimeFormatter.ofPattern("dd/MM/yyyy")))) {
                        TrancheGlobal.seminaReport sm = new TrancheGlobal.seminaReport();
                        sm.setName(rows.getString("company"));
                        sm.setDate(LocalDate.parse(rows.getString("date")).format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
                        TrancheGlobal.semina ts = new TrancheGlobal.semina();
                        ts.setCount(rows.getInt("count"));
                        ts.setDays(rows.getInt("days"));
                        ts.setPrice(rows.getInt("price"));
                        ts.setName(rows.getString("name"));
                        sm.setFact(ts);
                        address.put(rows.getString("company") + LocalDate.parse(rows.getString("date")).format(DateTimeFormatter.ofPattern("dd/MM/yyyy")), address.size());
                        rit.add(sm);
                    } else {
                        TrancheGlobal.seminaReport sm = rit.get(address.get(rows.getString("company") + LocalDate.parse(rows.getString("date")).format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))));
                        TrancheGlobal.semina ts = new TrancheGlobal.semina();
                        ts.setCount(rows.getInt("count"));
                        ts.setDays(rows.getInt("days"));
                        ts.setPrice(rows.getInt("price"));
                        ts.setName(rows.getString("name"));
                        sm.setFact(ts);
                        rit.set(address.get(rows.getString("company") + LocalDate.parse(rows.getString("date")).format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))), sm);
                    }
                }
                
            }
        }
        catch(Exception x){
            x.printStackTrace();
        }
        return rit;
        
    }
    public String getTotal(String from,String to){
        String Total= "";
         try{
            ResultSet rows = st.executeQuery("select sum(sm.count* sm.days * sm.price) as total from Semina as sm , company as cp where cp.compid = sm.compid and sm.date between '"+from+"' and '"+to+"'");
            while(rows.next()){
                Total = rows.getString(1);
            }
            }
            catch(Exception x){
                x.printStackTrace();
            }
        return this.French_numbers(Total);
    }

    public void setAccountOff() {
        try {
            st.executeQuery("update login set online ='false'");
        } catch (SQLException s) {
        }
    }
    public JRBeanCollectionDataSource getFactureReport(Base bs,String from,String to){
      ArrayList<TrancheGlobal.factureReport> AFR = new ArrayList();
      HashMap<String,Integer> Address = new HashMap();
        try {
            ResultSet rows = st.executeQuery("select bk.datein as datein,bk.dateout as dateout, julianday(bk.dateout)-julianday(bk.datein) as days,bk.price as price, bk.cash as cash,"
                    + "cl.name as client,"
                    + "cp.fullname as cname, cp.nif as nif ,cp.resi as resi,"
                    + "bf.fno as fno,bf.date as dt,bf.time as tm,"
                    + "lg.name as server ,lg.function as fonc "
                    + "from bookingFacture"+bs.getHot()+" as bf, bookHist"+bs.getHot()+" as bk, company as cp,clients as cl,login as lg "
                            + "where cp.compid = cl.compid  and cl.clientid = bk.clientid and bk.fno = bf.fno and lg.logid = bf.logid and bf.date between '"+from+"' and '"+to+"' order by bf.fno");
            while(rows.next()){
                TrancheGlobal.factureItems item = new TrancheGlobal.factureItems();
                item.setDatein(LocalDate.parse(rows.getString("datein")).format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
                item.setDateout(LocalDate.parse(rows.getString("dateout")).format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
                item.setName(rows.getString("client"));
                item.setPrice(rows.getInt("price"));
                item.setRoom(rows.getString("cash"));
                item.setDays(rows.getInt("days"));
                if(!Address.containsKey(rows.getString("fno"))){
                    TrancheGlobal.factureReport rep = new TrancheGlobal.factureReport();
                    rep.setFactN(rows.getString("fno"));
                    rep.setName(rows.getString("cname"));
                    rep.setResi(rows.getString("resi"));
                    rep.setNif(rows.getString("nif"));
                    rep.setServer(rows.getString("server"));
                    rep.setService(rows.getString("fonc"));
                    rep.setDateTime(LocalDate.parse(rows.getString("dt")).format(DateTimeFormatter.ofPattern("dd/MM/yyyy")).toString()+" "+rows.getString("tm"));
                    rep.setFact(item);
                    AFR.add(rep);
                    Address.put(rows.getString("fno"),Address.size()); 
                }else{
                    TrancheGlobal.factureReport rep = AFR.get(Address.get(rows.getString("fno")));
                    rep.setFact(item);
                    AFR.set(Address.get(rows.getString("fno")),rep);
                }
            }
        } catch (Exception xception) {
            xception.printStackTrace();
        }
        
      return new JRBeanCollectionDataSource(AFR);
    }
    public ArrayList<TrancheGlobal.factureReport> getSeminaFactureReport(LocalDate from,LocalDate to){
        ArrayList<TrancheGlobal.factureReport> AFR = new ArrayList();
      HashMap<String,Integer> Address = new HashMap();
        try {
            ResultSet rows = st.executeQuery("select sm.name as rubi,sm.count as count,sm.days as days,sm.price as price,"
                    + "sf.fno as fno,sf.date as dt,sf.time as tm,"
                    + "cp.fullname as cname, cp.nif as nif ,cp.resi as resi,"
                    + "lg.name as server ,lg.function as fonc "
                    + "from seminaFacture as sf ,seminafitems as sm ,company as cp ,login as lg "
                    + "where sf.compid = cp.compid and sf.fno = sm.fno and lg.logid = sf.logid  and sf.date between '"+from+"' and '"+to+"' order by sm.fno");
            while(rows.next()){
                TrancheGlobal.semina item = new TrancheGlobal.semina();
                item.setName(rows.getString("rubi"));
                item.setPrice(rows.getInt("price"));
                item.setCount(rows.getInt("count"));
                item.setDays(rows.getInt("days"));
                if(!Address.containsKey(rows.getString("fno"))){
                    TrancheGlobal.factureReport rep = new TrancheGlobal.factureReport();
                    rep.setFactN(rows.getString("fno"));
                    rep.setName(rows.getString("cname"));
                    rep.setResi(rows.getString("resi"));
                    rep.setNif(rows.getString("nif"));
                    rep.setServer(rows.getString("server"));
                    rep.setService(rows.getString("fonc"));
                    rep.setDateTime(LocalDate.parse(rows.getString("dt")).format(DateTimeFormatter.ofPattern("dd/MM/yyyy")).toString()+" "+rows.getString("tm"));
                    rep.setTab(item);
                    AFR.add(rep);
                    Address.put(rows.getString("fno"),Address.size());
                }else{
                    TrancheGlobal.factureReport rep = AFR.get(Address.get(rows.getString("fno")));
                    rep.setTab(item);
                    AFR.set(Address.get(rows.getString("fno")),rep);
                }
            }
        } catch (Exception xception) {
            xception.printStackTrace();
        }
      return AFR;
    }
    public void saveseminaF(String n,String compid,String date,ArrayList<seminarItem> sav){
        try{
            st.executeUpdate("insert into seminaFacture(fno,compid,date,time,datec,logid) values('"+n+"',"+compid+",'"+LocalDate.now()+"','"+date+"','"+date+"',(select logid from login where online='true'))");
            for (seminarItem i: sav) {
                st.executeUpdate("insert into seminafitems (fno,name,count,days,price) values('"+n+"','"+i.getName()+"',"+i.getCount()+","+i.getDays()+","+i.getPrice()+")");
            }
        }catch(Exception x){
            x.printStackTrace();
        }
    }
    public void saveClientF(Base bs,HashMap<String,Room_record> r){
        try{
            for (Map.Entry<String, Room_record> entry : r.entrySet()) {
                String key = entry.getKey();
                Room_record v = entry.getValue();
                st.executeUpdate("insert into bookHist" + bs.getHot() + " (fno,clientid,datein,dateout,price,cash) values('"+key+"',"+v.getClientid()+",'"+LocalDate.parse(v.getDatein(), DateTimeFormatter.ofPattern("dd/MM/yyyy"))+"','"+LocalDate.parse(v.getDateout(), DateTimeFormatter.ofPattern("dd/MM/yyyy"))+"',"+v.getPrice()+",'"+v.getCash()+"')");
                st.executeUpdate("insert into bookingFacture" + bs.getHot() + "(fno,date,time,logid) values('" +key +"','" + LocalDate.now() + "','" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm")) + "',(select logid from login where online='true'))");
            }
        }catch(Exception x){
            x.printStackTrace();
        }
    }

    public HashMap<String, String> getOnline() {
        HashMap<String, String> compH = new HashMap() ;
        try{
            ResultSet rows = st.executeQuery("select name,function from login where online='true'");
            while(rows.next()){
                compH.put("server", rows.getString(1));
                compH.put("service", rows.getString(2));

            }
        }
        catch(Exception x){
            x.printStackTrace();
        }
        return compH;
    }

    public String getTitleTotal(String date, String comp) {
        String tot="";
        try{
            ResultSet rows = st.executeQuery("select sum(sm.count* sm.days * sm.price) as total from semina as sm where sm.date='"+date+"' and sm.compid="+comp+"");
            while(rows.next()){
                tot = rows.getString("total");
            }
        }
        catch(Exception x){
            x.printStackTrace();
        }
        return tot;
    }
    public LocalDate getAge(String id) {
        String tot="";
        try{
            ResultSet rows = st.executeQuery("select age from clients where clientid="+id+"");
            while(rows.next()){
                tot = rows.getString("age");
            }
        }
        catch(Exception x){
            x.printStackTrace();
        }
        return LocalDate.parse(tot);
    }

    public ArrayList <TrancheGlobal.Summary> getDepenceTotal(LocalDate Tf, LocalDate Tt, Base bs) {
        ArrayList<TrancheGlobal.Summary> rt = new ArrayList();
        TrancheGlobal.Summary empty = new TrancheGlobal.Summary();
        empty.setT1("");
        empty.setCm(0);
        rt.add(empty);
        try {
            Integer tot =0;
            ResultSet rows = st.executeQuery("select sum(amount) from Depence" + bs.getHot() + " where date >= '" + Tf + "' and date <= '" + Tt + "' and cash='true' and global='false' and vers='false' order by date");
            while (rows.next()) {
                TrancheGlobal.Summary sm = new TrancheGlobal.Summary();
                sm.setT1("DEPENSES");
                sm.setDate("");
                sm.setCm(rows.getInt(1));
                rt.add(sm);
                tot += rows.getInt(1);
            }
            rt.add(empty);
            rows = st.executeQuery("select * from Depence"+bs.getHot()+" where date >= '"+Tf+"' and date <= '"+Tt+"' and cash='true' and global='true' and vers='false' order by date");
            while(rows.next()){
                TrancheGlobal.Summary sm = new TrancheGlobal.Summary();
                sm.setT1(rows.getString("description"));
                sm.setDate(LocalDate.parse(rows.getString("date")).format(DateTimeFormatter.ofPattern("dd/MM")));
                sm.setCm(rows.getInt("amount"));
                tot += rows.getInt("amount");
                rt.add(sm);
            }
            rt.add(empty);
            TrancheGlobal.Summary sm1 = new TrancheGlobal.Summary();
            sm1.setT1("AYAVUYE MUMA CASH");
            sm1.setDate("");
            sm1.setCm(tot);
            rt.add(sm1);
            Integer tt =0;
            rt.add(empty);
            rows = st.executeQuery("select * from Depence"+bs.getHot()+" where date >= '"+Tf+"' and date <= '"+Tt+"' and cash='false' and vers='false' order by date");
            while(rows.next()){
                TrancheGlobal.Summary sm = new TrancheGlobal.Summary();
                sm.setT1(rows.getString("description"));
                sm.setDate(LocalDate.parse(rows.getString("date")).format(DateTimeFormatter.ofPattern("dd/MM")));
                sm.setCm(rows.getInt("amount"));
                tt += rows.getInt("amount");
                rt.add(sm);
            }
            rt.add(empty);
            if (tt>0) {
                TrancheGlobal.Summary sm2 = new TrancheGlobal.Summary();
                sm2.setT1("AYATAVUYE MUMA CASH");
                sm2.setDate("");
                sm2.setCm(tt);
                rt.add(sm2);
            }
            tt =0;
            rows = st.executeQuery("select * from Depence"+bs.getHot()+" where date >= '"+Tf+"' and date <= '"+Tt+"' and vers='true' order by date");
            while(rows.next()){
                TrancheGlobal.Summary sm = new TrancheGlobal.Summary();
                sm.setT1(rows.getString("description"));
                sm.setDate(LocalDate.parse(rows.getString("date")).format(DateTimeFormatter.ofPattern("dd/MM")));
                sm.setCm(rows.getInt("amount"));
                tt += rows.getInt("amount");
                rt.add(sm);
            }
            rt.add(empty);
            if (tt>0) {
                TrancheGlobal.Summary sm2 = new TrancheGlobal.Summary();
                sm2.setT1("VERSSEMENT TOTAL");
                sm2.setDate("");
                sm2.setCm(tt);
                rt.add(sm2);
            }
        } catch (SQLException sQLException) {
            sQLException.printStackTrace();
        }
        return rt;
    }
    public ArrayList<TrancheGlobal.DepenceGlobal> getTrancheDepence(LocalDate Tf, LocalDate tl,Base bs) {
        LocalDate Tt;
        ot = tl;
        Integer fromCount = 1;
        ArrayList<TrancheGlobal.DepenceGlobal> trancheglobal = new ArrayList();
        for (Integer i = ot.getMonthValue()-Tf.getMonthValue() ; i > -1 ; i--) {
            Tt = ot.minusMonths(i);
            if(i>0){
                Tt = Tt.withDayOfMonth(Tt.lengthOfMonth());
            }
            if(Tf.getDayOfMonth() < 11){
                TrancheGlobal.DepenceGlobal dp = new TrancheGlobal.DepenceGlobal();
                dp.setCiz(bs.hotelCombo.getValue());
                dp.setType("Depenses");
                dp.setMonth(i.toString()+"one");
                if(Tt.getDayOfMonth() < 11){ 
                    dp.setFromDate(Tf.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
                    dp.setToDate(Tt.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
                    dp.setMonthSummary(this.getDepencePrint(Tf, Tt,bs));
                }
                else{
                    dp.setFromDate(Tf.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
                    dp.setToDate(Tt.withDayOfMonth(10).format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
                    dp.setMonthSummary(this.getDepencePrint(Tf,Tt.withDayOfMonth(10),bs));
                }
                trancheglobal.add(dp);
                Tf = Tf.withDayOfMonth(11);
            }
            if(Tf.getDayOfMonth()< 21){
                TrancheGlobal.DepenceGlobal dp = new TrancheGlobal.DepenceGlobal();
                dp.setCiz(bs.hotelCombo.getValue());
                dp.setType("Depenses");
                dp.setMonth(i.toString()+"two");
                if(Tt.getDayOfMonth() <= 21){
                    dp.setFromDate(Tf.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
                    dp.setToDate(Tt.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
                    dp.setMonthSummary(this.getDepencePrint(Tf, Tt,bs));
                }
                else{
                    dp.setFromDate(Tf.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
                    dp.setToDate(Tt.withDayOfMonth(20).format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
                    dp.setMonthSummary(this.getDepencePrint(Tf,Tt.withDayOfMonth(20),bs));
                }
                trancheglobal.add(dp);
                Tf = Tf.withDayOfMonth(21);
            }
            if(Tf.getDayOfMonth()<= 31){
                TrancheGlobal.DepenceGlobal dp = new TrancheGlobal.DepenceGlobal();
                dp.setCiz(bs.hotelCombo.getValue());
                dp.setType("Depenses");
                dp.setMonth(i.toString()+"three");
                dp.setFromDate(Tf.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
                dp.setToDate(Tt.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
                dp.setMonthSummary(this.getDepencePrint(Tf, Tt,bs));
                Tf = Tf.plusMonths(1).withDayOfMonth(1);
                trancheglobal.add(dp);
            }
        }
        return trancheglobal;
    }
    public ArrayList<TrancheGlobal.DepenceGlobal> getMonthGlobal(LocalDate Tf, LocalDate tl,Base bs) {
        LocalDate Tt;
        ot = tl;
        Integer fromCount = 1;
        ArrayList<TrancheGlobal.DepenceGlobal> trancheglobal = new ArrayList();
        for (Integer i = ot.getMonthValue()-Tf.getMonthValue() ; i > -1 ; i--) {
            Tt = ot.minusMonths(i);
            if(i>0){
                Tt = Tt.withDayOfMonth(Tt.lengthOfMonth());
            }
            TrancheGlobal.DepenceGlobal dp = new TrancheGlobal.DepenceGlobal();
            dp.setCiz(bs.hotelCombo.getValue());
            dp.setType("Global");
            dp.setMonth(i.toString()+"one");
            dp.setFromDate(Tf.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
            dp.setToDate(Tt.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
            dp.setMonthSummary(this.GetGlobal(bs,Tf, Tt));
            trancheglobal.add(dp);
            TrancheGlobal.Summary empty = new TrancheGlobal.Summary();
            empty.setT1("");
            empty.setCm(0);
            dp.add(empty);
            dp.addAll(getDepenceTotal(Tf, Tt,bs));
            Tf = Tf.plusMonths(1);
        }
        return trancheglobal;
    }
}
