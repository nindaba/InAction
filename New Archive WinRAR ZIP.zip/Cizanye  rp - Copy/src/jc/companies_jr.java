package jc;

public class companies_jr {
  private final String name;
  
  private final String payed;
  
  private final String unpayed;
  
  private final String total;
  
  companies_jr(String n, String p, String u, String t) {
    this.name = n;
    this.payed = p;
    this.unpayed = u;
    this.total = t;
  }
  
  public String getName() {
    return this.name;
  }
  
  public String getPayed() {
    return this.payed;
  }
  
  public String getUnpayed() {
    return this.unpayed;
  }
  
  public String getTotal() {
    return this.total;
  }
}
