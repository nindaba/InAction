package jc;

import java.util.List;

public class Day_export {
  private List<Room_record> day;
  
  public String date;
  
  Day_export(String d, List<Room_record> a) {
    this.day = a;
    this.date = d;
  }
  
  public void setDay(Room_record record) {
    try {
      Integer index = Integer.valueOf(Integer.parseInt(record.getRoomid()));
      synchronized (this.day) {
        this.day.remove(index.intValue() - 1);
        this.day.add(index.intValue() - 1, record);
      } 
    } catch (Exception x) {
      this.day.add(record);
    } 
  }
  
  public List<Room_record> getDay() {
    return this.day;
  }
  
  public String getDate() {
    return this.date;
  }
}
