package jc;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

public class Companies_base implements Initializable {
  @FXML
  private Label payed;
  
  @FXML
  private Label total;
  
  @FXML
  private Label un_payed;
  
  public void initialize(URL url, ResourceBundle rb) {}
  
  public void init(String p, String u, String t) {
    this.payed.setText(p);
    this.total.setText(t);
    this.un_payed.setText(u);
  }
}
