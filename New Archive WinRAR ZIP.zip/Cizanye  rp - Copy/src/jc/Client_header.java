package jc;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

public class Client_header implements Initializable {
  @FXML
  private Label client_name;
  
  @FXML
  private Label payed_cash;
  
  @FXML
  private Label un_payed_cash;
  
  @FXML
  private Label total_cash;
  
  public void initialize(URL url, ResourceBundle rb) {}
  
  public void init(String n, String p, String u, String t) {
    this.client_name.setText(n);
    this.payed_cash.setText(p);
    this.un_payed_cash.setText(u);
    this.total_cash.setText(t);
  }
}
