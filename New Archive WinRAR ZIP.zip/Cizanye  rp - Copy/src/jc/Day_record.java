 package jc;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

public class Day_record {
  Base bs;
  
  ArrayList<Parent> Day_vbox = new ArrayList();
  
  String date;
  
  ArrayList<Room_record> records;
  Integer h;
  
  Integer o;
  
  Integer p;
  
  Integer t;
  Integer csh;
  Day_base base;
  
  Parent base_root;
  
  Day_record(Base b, String dt, LocalDate from, LocalDate to, ArrayList<Room_record> jsdata) {
    this.records = jsdata;
    this.date = LocalDate.parse(dt).format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
    this.bs = b;
    Database data = new Database();
    try {
      FXMLLoader loader = new FXMLLoader(getClass().getResource("/fx/room_date.fxml"));
      Parent root = loader.<Parent>load();
      room_date cont = loader.<room_date>getController();
      cont.setDate(dt);
      this.Day_vbox.add(root);
      for (Integer i = Integer.valueOf(1); i.intValue() <= jsdata.size();i++) {
        Integer integer1, integer2;
        loader = new FXMLLoader(getClass().getResource("/fx/empty_room.fxml"));
        root = loader.<Parent>load();
        Empty_room cont1 = loader.<Empty_room>getController();
        String[] det = data.getAvailability(bs,LocalDate.parse(dt), to, i.toString());
        cont1.init(b, i.toString(), det);
        this.Day_vbox.add(root);
        loader = new FXMLLoader(getClass().getResource("/fx/room_shot.fxml"));
        root = loader.<Parent>load();
        room_short cont2 = loader.getController();
        cont2.init(det[2]);
        CompRoom.add(root);
        compRoom.add(cont2);
      } 
      loader = new FXMLLoader(getClass().getResource("/fx/Day_base.fxml"));
      this.base_root = loader.<Parent>load();
      this.base = loader.<Day_base>getController();
      this.base.init(b, LocalDate.parse(dt));
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    this.h = Integer.valueOf(0);
    this.o = Integer.valueOf(0);
    this.p = Integer.valueOf(0);
    this.t = Integer.valueOf(0);
    this.csh= Integer.valueOf(0);
  }
  HashMap<String,Integer> CompMoney = new HashMap();
  ArrayList<Node> CompRoom = new ArrayList();
  ArrayList<Node> CompRoomSide = new ArrayList();
  ArrayList<room_short> compRoom = new ArrayList();
  ArrayList<room_short> compRoomSide = new ArrayList();
  public void add_room(Room_record record) {
    try {
      FXMLLoader loader = new FXMLLoader(getClass().getResource("/fx/Client_in_room.fxml"));
      Parent root = loader.<Parent>load();
      Client_in_room cont = loader.<Client_in_room>getController();
      cont.init(record, this.bs);
      try {
        Integer index = Integer.valueOf(Integer.parseInt(record.getRoomid()));
        this.h = Integer.valueOf(this.h.intValue() + record.getPrice().intValue());
        this.Day_vbox.remove(Integer.parseInt(record.getRoomid()));
        this.Day_vbox.add(Integer.parseInt(record.getRoomid()), root);
        this.records.remove(index.intValue() - 1);
        
        this.records.add(index.intValue() - 1, record);
        if(compRoom.get(index.intValue() - 1).compare(record.getRoom()))
            compRoom.get(index.intValue() - 1).setComp(record.getCompany());
      } catch (Exception x) {
        this.o = Integer.valueOf(this.o.intValue() + record.getPrice().intValue());
        this.Day_vbox.add(root);
        this.records.add(record);
        loader = new FXMLLoader(getClass().getResource("/fx/room_shot.fxml"));
        root = loader.<Parent>load();
        room_short cont2 = loader.getController();
        cont2.init(record.getRoom());
        CompRoomSide.add(root);
        cont2.setComp(record.getCompany());        
        
      }
      if(MoneyComp.containsKey(record.getCompFull())){
          Label lb = new Label();
          ArrayList<Integer> lt = MoneyComp.get(record.getCompFull());
          Integer nt = lt.get(0)+1;
          Integer mn = lt.get(1)+record.getPrice();
          lt.clear();
          lt.add(nt);
          lt.add(mn);
          lb.setText(nt+" "+record.getCompFull()+" "+French_numbers(mn.toString()));
          ArrayList<Integer> ad = MoneyCompAddress.get(record.getCompFull());
          base.ReplaceToGrid(MoneyCompAddressByLabel.get(record.getCompFull()), lb,ad.get(0),ad.get(1));
          MoneyCompAddressByLabel.replace(record.getCompFull(), lb);
          MoneyComp.replace(record.getCompFull(), lt);
      }else{
          Label lb = new Label();
          ArrayList<Integer> lt = new ArrayList();
          ArrayList<Integer> ad = new ArrayList();
          ad.add(Column);
          ad.add(row);
          
          Integer nt = 1;
          Integer mn = record.getPrice();
          lt.add(nt);
          lt.add(mn);
          lb.setText(record.getCompFull()+" "+French_numbers(mn.toString()));
          base.addToGrid(lb, Column, row);
          MoneyComp.put(record.getCompFull(), lt);
          MoneyCompAddress.put(record.getCompFull(), ad);
          MoneyCompAddressByLabel.put(record.getCompFull(), lb);
          if (Column==5) {
              row++;
              Column = 0;
          }
          Column++;
      }
      if (record.getPayed().equals("false"))
        this.p = Integer.valueOf(this.p.intValue() + record.getPrice().intValue() ); 
      if (record.getCash().equals("true"))
        this.csh = Integer.valueOf(this.csh.intValue() + record.getPrice().intValue() ); 
      this.t = Integer.valueOf(this.o.intValue() + this.h.intValue());
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  HashMap<String,ArrayList> MoneyComp = new HashMap();
  HashMap<String,ArrayList> MoneyCompAddress = new HashMap();
  HashMap<String,Label> MoneyCompAddressByLabel = new HashMap();
  Integer Column=1;
  Integer row = 0;
  public Parent getDay() {
    Integer i = Integer.valueOf(0);
    Integer[] tt = new Integer[5];
    tt[0] = this.h;
    tt[1] = this.o;
    tt[2] = this.p;
    tt[4] = this.t;
    tt[3] = Integer.valueOf(this.t.intValue() - this.p.intValue());
    this.bs.addDay_export(this, this.date, tt, this.records);
    String ht = French_numbers(this.h.toString());
    String Ot = French_numbers(this.o.toString());
    String py = French_numbers(this.p.toString());
    String tot = French_numbers(this.t.toString());
    this.base.set(ht, Ot, py,French_numbers(this.csh.toString()), tot,this.Day_vbox,date,CompRoom,CompRoomSide);    
    return this.base_root;
  }
  
  public String French_numbers(String number) {
    String new_number = " FBU";
    if (number.length() > 2) {
      new_number = number.substring(number.length() - 3, number.length()) + new_number;
    } else {
      new_number = number + new_number;
    } 
    Integer size = Integer.valueOf(number.length());
    Integer last3 = Integer.valueOf(size.intValue() - 3);
    while (last3.intValue() > 2) {
      new_number = number.substring(last3.intValue() - 3, last3.intValue()) + "," + new_number;
      last3 = Integer.valueOf(last3.intValue() - 3);
    } 
    if (last3.intValue() > 0)
      new_number = number.substring(0, last3.intValue()) + "," + new_number; 
    return new_number;
  }
}
