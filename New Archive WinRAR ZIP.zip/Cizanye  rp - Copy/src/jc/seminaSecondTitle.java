/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jc;

import java.net.URL;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

/**
 * FXML Controller class
 *
 * @author Bosco
 */
public class seminaSecondTitle implements Initializable {

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @return the nif
     */
    public String getNif() {
        return nif;
    }

    /**
     * @return the resi
     */
    public String getResi() {
        return resi;
    }

    /**
     * @return the server
     */
    public String getServer() {
        return server;
    }

    /**
     * @return the service
     */
    public String getService() {
        return service;
    }

    /**
     * @return the date
     */
    public String getDate() {
        return date;
    }

    /**
     * @return the french
     */
    public String getFrench() {
        return french;
    }

    /**
     * @return the base
     */
    public Base getBase() {
        return base;
    }

    /**
     * @return the fact
     */
    public String getFactN() {
        return factN;
    }

    /**
     * @return the dateTime
     */
    public String getDateTime() {
        return LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyy HH:mm")).toString();
    }

    @FXML
    private Label depenceDescription1;
    @FXML
    private Label depenceDate11;
    @FXML
    private Label depenceMoney11;
    @FXML
    private Label depenceDescription11;
    @FXML
    private Label depenceDescription111;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    ArrayList<seminarItem> items = new ArrayList();
    @FXML
    private void print(ActionEvent event) {
        HashMap<String,String> cd = new Database().getCDetails(Compid);
        name = cd.get("name");
        nif = cd.get("nif");
        resi = cd.get("resi");
        french = new Dictionary().Frech(total).toLowerCase()+"fancs burundais";
        HashMap<String,String> xd = new Database().getOnline();
        server = xd.get("server");
        service = xd.get("service");
        factN = new Database().getFact()+"-"+LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy"));
        tab = new JRBeanCollectionDataSource(items);
        base.printSeminar(this,items);
    }
    private String name;
    private String nif;
    private String resi;
    private String server;
    private String service;
    private String date;
    private String french;
    private Base base;
    private String factN;
    private String dateTime;
    public String Compid;
    JRBeanCollectionDataSource tab;
    public JRBeanCollectionDataSource getTab(){
        return tab;
    }
    public void setItems(ArrayList<seminarItem> s,String co,Base bs,String to,String dt){
        items = s;
        date = dt;
        Compid = co;
        base = bs;
        total = to;
    }
    String total;
}
