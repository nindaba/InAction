package jc;

import com.jfoenix.controls.JFXCheckBox;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.shape.Line;

public class Client_details implements Initializable {
  @FXML
  private Label name;
  
  @FXML
  private Label price;
  
  @FXML
  private Label from;
  
  @FXML
  private Label days;
  
  @FXML
  private Label total_cost;
  
  String clientid;
  
  @FXML
  private Line line;
  
  LocalDate fro;
  
  LocalDate to;
  
  @FXML
  private JFXCheckBox select;
  
  String bk;
  
  Base base;
  
  public void initialize(URL url, ResourceBundle rb) {}
  
  public void init(Base bs, Room_record rc) {
    this.bk = rc.getBookid();
    this.name.setText(rc.getName());
    this.price.setText(this.data.French_numbers(rc.getPrice().toString()));
    this.from.setText(rc.getDatein());
    this.days.setText(rc.getDays().toString());
    this.total_cost.setText(this.data.French_numbers(rc.getTotal_cost().toString()));
    if (rc.getPayed().equals("false")) {
      this.line.setStyle("-fx-stroke:#ff4848");
    } else {
      this.select.setVisible(false);
    } 
    this.base = bs;
    this.clientid = rc.getClientid();
  }
  
  @FXML
  private void getThiClient(MouseEvent event) {
    this.data.getThisClient(this.base, this.clientid);
  }
  
  Database data = new Database();
  
  @FXML
  private void add_to_selected_client(ActionEvent event) {
    if (this.select.isSelected())
      this.base.pay_selected.add("bookid = " + this.bk); 
  }
}
