/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jc;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.shape.Line;

/**
 * FXML Controller class
 *
 * @author Bosco
 */
public class seminarItem implements Initializable {

    @FXML
    private Line line211;
    @FXML
    private JFXButton save;
    @FXML
    private JFXTextField price;
    private String compid;
    public void setCompid(String i){
        compid = i;
    }
    public String getCompid(){
        return compid;
    }
    private String date;
    public void setDate(String i){
        date = i;
    }
    public String getDate(){
        return date;
    }
    private String sId ="0";
    public void setSid(String i){
        sId = i;
    }
    public String getSid(){
        return sId;
    }
    public Integer getPrice(){
        Integer n = 0;
        try {
            price.setStyle("-fx-text-fill: #dad7d7;-fx-prompt-text-fill: #dad7d7");
            n = Integer.parseInt(price.getText());
        } catch (NumberFormatException numberFormatException) {
            price.setStyle("-fx-text-fill: #f18080;-fx-prompt-text-fill: #f18080");
        }
        return n;
    }
    public void setPrice(String p){
        price.setText(p);
    }
    @FXML
    private JFXTextField days;
    public Integer getDays(){
        Integer n = 0;
        try {
            days.setStyle("-fx-text-fill: #dad7d7;-fx-prompt-text-fill: #dad7d7");
            n = Integer.parseInt(days.getText());
        } catch (NumberFormatException numberFormatException) {
            days.setStyle("-fx-text-fill: #f18080;-fx-prompt-text-fill: #f18080");
        }
        return n;
    }
    public void setDays(String d){
        days.setText(d);
    }
    @FXML
    private JFXTextField count;
    public Integer getCount(){
        Integer n = 0;
        try {
            count.setStyle("-fx-text-fill: #dad7d7;-fx-prompt-text-fill: #dad7d7");
            n = Integer.parseInt(count.getText());
        } catch (NumberFormatException numberFormatException) {
            count.setStyle("-fx-text-fill: #f18080;-fx-prompt-text-fill: #f18080");
        }
        return n;
    }
    public void setCount(String s){
        count.setText(s);
    }
    @FXML
    private JFXTextField name;
    public String getName(){
        if(name.getText().equals("") && name.getText().equals("rubrique")){
            To =0;
            name.setStyle("-fx-text-fill: #f18080;-fx-prompt-text-fill: #f18080");
        }else{
            To =1;
            name.setStyle("-fx-text-fill: #dad7d7;-fx-prompt-text-fill: #dad7d7");
        }
        return name.getText();
    }
    public void setName(String m){
        name.setText(m);
    }
    @FXML
    private Label total;
    public void setTotal(String t){
        total.setText(t);
    }
    private Node node;
    public void setNode(Node no){
        node = no;
    }
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void remove(ActionEvent event) {
        if (!sId.equals("0") && !this.getName().equals("rubrique")) {
            new Database().removeSitem(sId,date,compid);
            titl.removeI(node);
        }
    }

    @FXML
    private void save(ActionEvent event) {
        getName();
        if (To > 0) {
            System.out.println(this.getName());
            new Database().editSitem(sId, this.getName(), this.getCount(), this.getDays(), this.getPrice(),date,compid);
            titl.getItems();
        }
    }
    seminarTitle titl ;
    public void setSeT(seminarTitle semi) {
        titl = semi;
    }
    Integer To =1;
    @FXML
    private void cllaculate(KeyEvent event) {
        To = this.getCount()*this.getDays()*this.getPrice();
        this.setTotal(new Database().French_numbers(To.toString()));
    }

    @FXML
    private void removeRebri(MouseEvent event) {
        if(name.getText().equals("rubrique")){
            name.setText("");
        }
    }
    
}
