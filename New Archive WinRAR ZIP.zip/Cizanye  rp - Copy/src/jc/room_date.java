package jc;

import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

public class room_date implements Initializable {
  @FXML
  private Label date;
  
  public void initialize(URL url, ResourceBundle rb) {}
  
  public void setDate(String dt) {
    this.date.setText(LocalDate.parse(dt).format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
  }
}
