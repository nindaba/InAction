/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jc;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.shape.Line;

/**
 * FXML Controller class
 *
 * @author Bosco
 */
public class depenceItem implements Initializable {

    @FXML
    private Line line2;
    @FXML
    private Label depenceDescription;
    @FXML
    private Label depenceDate;
    @FXML
    private Label depenceMoney;
    String depid;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    } 
    Node root;
    Base base;
    public void init(Base bs,String id,String desc,String m,String dt,Node rt){
        root =rt;
        depenceDescription.setText(desc);
        depenceDate.setText(dt);
        depenceMoney.setText(m);
        base = bs;
        depid = id;
    }
    Database data = new Database();
    @FXML
    private void depenceRemove(ActionEvent event) {
        data.deleteDepence(depid,base);
        base.removeDepence(root);
    }
    
}
